import yourgameshortname.main
def main():
    yourgameshortname.main.main()
    
if __name__ == "__main__":
    yourgameshortname.main.main()
