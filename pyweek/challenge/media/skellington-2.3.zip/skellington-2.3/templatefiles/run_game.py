import yourgameshortname.__main__
if __name__ == "__main__":
    yourgameshortname.__main__.main()
