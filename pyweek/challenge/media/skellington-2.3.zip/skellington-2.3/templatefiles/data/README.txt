Place your game's data files in here (images, fonts, map files, sounds,
etc).
