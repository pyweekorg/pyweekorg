import yourgameshortname.main
if __name__ == "__main__":
    yourgameshortname.main.main()

# vim: set filetype=python sts=4 sw=4 noet si :
