if __name__ == "__main__":
    import main
    main.main()

# vim: set filetype=python sts=4 sw=4 noet si :
