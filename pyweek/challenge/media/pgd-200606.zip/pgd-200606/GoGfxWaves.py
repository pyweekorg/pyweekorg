#!/usr/bin/python

import pygame
import time
import math
import random
import os
import getopt
import sys

pygame.init()  

def usage():
  print """
USAGE

python %s -r 800x600 -c [(0,0,0),(255,255,255),(255,0,0),(0,255,0)] -l logo,png

 -r, --res : You can set the desired resolution here. Default is maximum.

 -c, --colors : A python list of RGB values, without spaces. The first
                color is the background color, the other are wave colors.

 -l, --logo : This should be the filename for the logo.

 -t, --looptime : You can set the time between wasve randomisation in seconds.

 -f, --fadetime : You can set the time the fade out takes in seconds.

 -s, --speedup : You can scale the speed here. '2.0' is two times faster. 
""" % sys.argv[0]

try :
  opts, args = getopt.getopt(sys.argv[1:], 'r:c:l:t:f:s:' , ['res','colors','logo','looptime','fadetime','speedup'])
except getopt.GetoptError, e :
  usage()
  print e
  sys.exit(2)

# default settings  
colors = [(40, 63, 115, 0),(43, 91, 131, 128),(120, 170, 211, 128),(54, 109, 166, 128),(132, 177, 215, 128),]

import uu
import StringIO
#logo_txt = 'begin 666 -\nMB5!.1PT*&@H    -24A$4@  !     , " ,   "-9.4_    "7!(67,   L3\nM   +$P$ FIP8   *36E#0U!0:&]T;W-H;W @24-#(\'!R;V9I;&4  \'C:G5-W\nM6)/W%C[?]V4/5D+8\\+&7;($ (B.L",@06:(0D@!AA! 20,6%B I6%!41G$A5\nMQ(+5"DB=B.*@*+AG08J(6HM57#CN\']RGM7UZ[^WM^]?[O.><Y_S.><\\/@!$2\nM)I\'FHFH .5*%/#K8\'X]/2,3)O8 "%4C@!" 0YLO"9P7%  #P WEX?G2P/_P!\nMKV\\  @!PU2XD$L?A_X.Z4"97 ""1 . B$N<+ 9!2 ,@N5,@4 ,@8 +!3LV0*\nM )0  &QY?$(B *H- .ST23X% -BID]P7 -BB\'*D( (T! )DH1R0"0+L 8%6!\nM4BP"P,( H*Q (BX$P*X!@%FV,D<"@+T% \':.6) /0&  @)E"+,P (#@" $,>\nM$\\T#($P#H##2O^"I7W"%N$@! ,#+E<V72](S%+B5T!IW\\O#@XB\'BPFRQ0F$7\nM*1!F">0BG)>;(Q-(YP-,S@P  !KYT<\'^.#^0Y^;DX>9FYVSO],6B_FOP;R(^\nM(?\'?_KR, @0 $$[/[]I?Y>76 W#\' ;!UOVNI6P#:5@!HW_E=,]L)H%H*T\'KY\nMBWDX_$ >GJ%0R#P=\' H+"^TE8J&],..+/O\\SX6_@BW[V_$ >_MMZ\\ !QFD"9\nMK<"C@_UQ86YVKE*.Y\\L$0C%N]^<C_L>%?_V.*=\'B-+%<+!6*\\5B)N% B3<=Y\nMN5*11"\')E>(2Z7\\R\\1^6_0F3=PT K(9/P$ZV![7+;,!^[@$"BPY8TG8 0\'[S\nM+8P:"Y$ $&<T,GGW  "3O_F/0"L! ,V7I.,  +SH&%RHE!=,Q@@  $2@@2JP\nM00<,P12LP Z<P1V\\P!<"809$0 PDP#P00@;D@!P*H1B601E4P#K8!+6P QJ@\nM$9KA$+3!,3@-Y^ 27(\'K<!<&8!B>PAB\\A@D$0<@($V$A.H@18H[8(LX(%YF.\nM!")A2#22@*0@Z8@442+%R\'*D JE":I%=2"/R+7(4.8U<0/J0V\\@@,HK\\BKQ\'\nM,92!LE$#U )U0+FH\'QJ*QJ!ST70T#UV EJ)KT1JT\'CV MJ*GT4OH=70 ?8J.\nM8X#1,0YFC-EA7(R\'16")6!HFQQ9CY5@U5H\\U8QU8-W85&\\">8>\\() *+@!/L\nM"%Z$$,)L@I"01UA,6$.H)>PCM!*Z"%<)@X0QPB<BDZA/M"5Z$OG$>&(ZL9!8\nM1JPF[B$>(9XE7B<.$U^32"0.R9+D3@HA)9 R20M):TC;2"VD4Z0^TA!IG$PF\nMZY!MR=[D"+* K""7D;>0#Y!/DOO)P^2W%#K%B.),":(D4J24$DHU93_E!*6?\nM,D*9H*I1S:F>U BJB#J?6DEMH\'90+U.\'J1,T=9HES9L60\\ND+:/5T)II9VGW\nM:"_I=+H)W8,>19?0E])KZ ?IY^F#]\'<,#88-@\\=(8B@9:QE[&:<8MQDOF4RF\nM!=.7F<A4,-<R&YEGF ^8;U58*O8J?!61RA*5.I56E7Z5YZI457-5/]5YJ@M4\nMJU4/JUY6?:9&5;-0XZD)U!:KU:D=5;NI-J[.4G=2CU#/45^COE_]@OIC#;*&\nMA4:@ADBC5&.WQAF-(1;&,F7Q6$+6<E8#ZRQKF$UB6[+Y[$QV!?L;=B][3%-#\nM<ZIFK&:19IWF<<T!#L:QX/ YV9Q*SB\'.#<Y[+0,M/RVQUFJM9JU^K3?:>MJ^\nMVF+M<NT6[>O:[W5PG4"=+)WU.FTZ]W4)NC:Z4;J%NMMUS^H^TV/K>>D)]<KU\nM#NG=T4?U;?2C]1?J[];OT1\\W,#0(-I 9;#$X8_#,D&/H:YAIN-\'PA.&H$<MH\nMNI\'$:*/12:,GN";NAV?C-7@7/F:L;QQBK#3>9=QK/&%B:3+;I,2DQ>2^*<V4\nM:YIFNM&TTW3,S,@LW*S8K,GLCCG5G&N>8;[9O-O\\C86E19S%2HLVB\\>6VI9\\\nMRP6639;WK)A6/E9Y5O56UZQ)UESK+.MMUE=L4!M7FPR;.IO+MJBMFZW$=IMM\nMWQ3B%(\\ITBGU4V[:,>S\\[ KLFNP&[3GV8?8E]FWVSQW,\'!(=UCMT.WQR=\'7,\nM=FQPO.NDX33#J<2IP^E79QMGH7.=\\S47IDN0RQ*7=I<74VVGBJ=NGWK+E>4:\nM[KK2M=/UHYN[F]RMV6W4W<P]Q7VK^TTNFQO)7<,][T\'T\\/=8XG\',XYVGFZ?"\nM\\Y#G+UYV7EE>^[T>3[.<)I[6,&W(V\\1;X+W+>V Z/CUE^L[I S[&/@*?>I^\'\nMOJ:^(M\\]OB-^UGZ9?@?\\GOL[^LO]C_B_X7GR%O%.!6 !P0\'E ;V!&H&S VL#\nM\'P29!*4\'-06-!;L&+PP^%4(,"0U9\'W*3;\\ 7\\AOY8S/<9RR:T17*")T56AOZ\nM,,PF3![6$8Z&SPC?$\'YOIOE,Z<RV"(C@1VR(N!]I&9D7^7T4*2HRJB[J4;13\nM=\'%T]RS6K.19^V>]CO&/J8RY.]MJMG)V9ZQJ;%)L8^R;N("XJKB!>(?X1?&7\nM$G03) GMB>3$V,0]B>-S N=LFC.<Y)I4EG1CKN7<HKD7YNG.RYYW/%DU69!\\\nM.(68$I>R/^6#($)0+QA/Y:=N31T3\\H2;A4]%OJ*-HE&QM[A*/)+FG5:5]CC=\nM.WU#^FB&3T9UQC,)3U(K>9$9DKDC\\TU61-;>K,_9<=DM.92<E)RC4@UIEK0K\nMUS"W*+=/9BLKDPWD>>9MRAN3A\\KWY"/Y<_/;%6R%3-&CM%*N4 X63"^H*WA;\nM&%MXN$B]2%K4,]]F_NKY(PN"%GR]D+!0N+"SV+AX6?\'@(K]%NQ8CBU,7=RXQ\nM75*Z9\'AI\\-)]RVC+LI;]4.)84E7R:GG<\\HY2@]*EI4,K@E<TE:F4R<MNKO1:\nMN6,5895D5>]JE]5;5G\\J%Y5?K\'"LJ*[XL$:XYN)73E_5?/5Y;=K:WDJWRNWK\nM2.NDZVZL]UF_KTJ]:D\'5T(;P#:T;\\8WE&U]M2MYTH7IJ]8[-M,W*S0,U837M\nM6\\RVK-ORH3:C]GJ=?UW+5OVMJ[>^V2;:UK_==WOS#H,=%3O>[Y3LO+4K>%=K\nMO45]]6[2[H+=CQIB&[J_YG[=N$=W3\\6>CWNE>P?V1>_K:G1O;-ROO[^R"6U2\nM-HT>2#IPY9N ;]J;[9IWM7!:*@["0>7!)]^F?\'OC4.BASL/<P\\W?F7^W]0CK\nM2\'DKTCJ_=:PMHVV@/:&][^B,HYT=7AU\'OK?_?N\\QXV-UQS6/5YZ@G2@]\\?GD\nM@I/CIV2GGIU./SW4F=QY]TS\\F6M=45V]9T//GC\\7=.Y,MU_WR?/>YX]=\\+QP\nM]"+W8MLEMTNM/:X]1WYP_>%(KUMOZV7WR^U7/*YT]$WK.]\'OTW_Z:L#5<]?X\nMURY=GWF][\\;L&[=N)MT<N"6Z]?AV]NT7=PKN3-Q=>H]XK_R^VOWJ!_H/ZG^T\nM_K%EP&W@^&# 8,_#60_O#@F\'GOZ4_].\'X=)\'S$?5(T8CC8^=\'Q\\;#1J]\\F3.\nMD^&GLJ<3S\\I^5O]YZW.KY]_]XOM+SUC\\V/ +^8O/OZYYJ?-R[ZNIKSK\'(\\<?\nMO,YY/?&F_*W.VWWON.^ZW\\>]\'YDH_$#^4//1^F/\'I]!/]S[G?/[\\+_>$\\_LE\nMTI\\S    !&=!34$  +&.?/M1DP   "!C2%)-  !Z)0  @(,  /G_  " Z0  \nM=3   .I@   ZF   %V^27\\5&   # %!,5$7_8P    "H5EEF\'R4B$!)))2LC\nM%!A%*C,2!PLV\'2D+!@D% @0"  (7#A=&/48   8   ,\'!Q<! PT!! <&"0L(\nM%!D" P,)#PT T0  R0  Q0  P0  O@  O0  N@  N0  M@  L@  K0  H@  \nMG   DP  B   >0  9P  5@  1P  /   ,@  )P  \'   %0  #@  !P   P  \nM 0 !I@$+M0L/EP\\3L!,5CA4)N04)KP8.JPD+LP,H,B0Z2RL\'" 0Y/Q\\%!0,8\nM&!-$0!-^:#D3$ HT*QM;1"DP(A-Y5S*3;#]*."1@44&/7BZN<SD# @%4/26Q\nM9!^;8S Z)A.88S.C:SA\\4RR&6C!S32E),AQG1R@Z*!<J\'A,D&A\'_= *+21.6\nM5R.+42&Z;2ZN:C*H9C&T<3:C93&H:3-7-QP2# >-8#G_;P#_;0#_;0+_;@3Y\nM;07V;@?>9@[#9B"Y82#<=BC-;27#:R6\\9R>P826B62/$;BQD.1?\'<BZT:B\\R\nM\'0T."04=$PL^+![_:P#_: #_9@ 1!P#^: \'_:0/_; ?U:0SE9 WJ:!#M;!/<\nM9!+F:A348Q3M<1A7*0GA:QG19!C#7A?=;!NH4Q;N=B\'\'8QRQ5QG8;2#4;2+,\nM;BI]1!S#<C>Q93(I& S_80#_90#_8@#[7P#T7@#G6@#;50";/ !R+ !F)P#^\nM8P\'\'30&*-0\'^9 +\\9 +\\8P+Y8@*V1P+[90.G0@)/( \'\\9 3X9 0X%@\']907Q\nM8 7^:0?X9P?U9 ?04@9$&P+N8PCS90GO90KI7PK]9@O:6@KN9@S^; Z^4@MY\nM,PBP2PSV:A5J+PKJ:QP8"P-_.Q*B8#@W(Q8H#P#X80OQ8A#L8Q/I8Q?\\;1O<\nM8QW]<".]:3?E8AW76ARJ21GS;B;E:BKA:S#3:C3!83+&9C9&)A8)!0.:6CC/\nM6B3/8BX[\' VV5ROF<#FU32!D*Q.F32>)/R&W6C)6*QF?42__9#,% @&312IM\nM.BEZ13B)13>..R[6:%PY\'!E?,2U0+RP# 0\'___^3U&:[   ! \'123E/_____\nM____________________________________________________________\nM____________________________________________________________\nM____________________________________________________________\nM____________________________________________________________\nM____________________________________________________________\nM__________________________________\\ 4_<\')0  $SU)1$%4>-KLW6F4\nM5.6=P.%_W>JF-[I;"- =!)$HBH H,";N,1,B;@BX\'(P"B8D&$AV,B8Z>$5"6\nMS*B,DTU/U$S$@$E44$\',:!#C%A<T@J*0"(H+BXV K+UWUYT/S1HQ@\\:X9)[G\nM4]>MN_2I<][??6_=JNY,&L#_5XF7  0 $ !    !  0 $ !    !  0 $ ! \nM   !  0 $ !    !  0 $ !    !  0 $ !    !  0 $ !    !  0 $ ! \nM   !  0 $ !    !  $ !  0 $    $ !  0 $    $ !  0 $    $ !  0\nM $    $ !  0 $    $ !  0 $    $ !  0 $    $ !  0 $    $ !  0\nM $    $  0 $ !  0    0 $ !  0    0 $ !  0    0 $ !  0    0 $\nM !  0    0 $ !  0    0 $ !  0    0 $ !  0    0 $ !  0    0 !\nM  0 $ !    !  0 $ !    !  0 $ !    !  0 $ !    !  0 $ !    !\nM  0 $ !    !  0 $ !    !  0 $ !    !  0 $ !    !  $ !  0 $  \nM  $ !  0 $    $ !  0 $    $ !  0 $    $ !  0 $    $ !  0 $  \nM  $ !  0 $    $ !  0 $    $ !  0 $    $  0 $ !  0    0 $ !  \nM0    0 $ !  0    0 $ !  0    0 $ !  0    0 $ !  0    0 $ !  \nM0    0 $ !  0    0 $ !  0    0 !  0 $ !    !  0 $ !    !  0 \nM$ !    !  0 $ !    !  0 $ !    !  0 $ !    !  0 $ !    !  0 \nM$ !    !  0 $ !  $  O 0@ (    ( "  @ (    ( "  @ (    ( "  @\nM (    ( "  @ (    ( "  @ (    ( "  @ (    ( "  @ (    ( "  @\nM (    ( "  ( "  @    @ ( "  @    @ ( "  @    @ ( "  @    @ (\nM "  @    @ ( "  @    @ ( "  @    @ ( "  @    @ ( "  @    @ (\nM  @ ( "    "  @ ( "    "  @ ( "    "  @ ( "    "  @ ( "    "\nM  @ ( "    "  @ ( "    "  @ ( "    "  @ ( "    "  @ "  @ (  \nM  ( "  @ (    ( "  @ (    ( "  @ (    ( "  @ (    ( "  @ (  \nM  ( "  @ (    ( "  @ (    ( "  @ (    ( "  ( "  @    @ ( "  \nM@    @ ( "  @    @ ( "  @    @ ( "  @    @ ( "  @    @ ( "  \nM@    @ ( "  @    @ ( "  @    @ (  @ ( "    "  @ ( "    "  @ \nM( "    "  @ ( "    "  @ ( "    "  @ ( "    "  @ ( "    "  @ \nM( "    "  @ ( "    "  @ "  @ (    ( "  @ (    ( "  @ (    ( \nM"  @ (    ( "  @ (    ( "  @ (    ( "  @ (    ( "  @ (    ( \nM"  @ (    (  N E  $ !  0 $    $ !  0 $    $ !  0 $    $ !  0\nM $    $ !  0 $    $ !  0 $    $ !  0 $    $ !  0 $    $ !  0\nM $  0    0 $ !  0    0 $ !  0    0 $ !  0    0 $ !  0    0 $\nM !  0    0 $ !  0    0 $ !  0    0 $ !  0    0 $ !  0 !    !\nM  0 $ !    !  0 $ !    !  0 $ !    !  0 $ !    !  0 $ !    !\nM  0 $ !    !  0 $ !    !  0 $ !    !  0 $ !  $    $ !  0 $  \nM  $ !  0 $    $ !  0 $    $ !  0 $    $ !  0 $    $ !  0 $  \nM  $ !  0 $    $ !  0 $    $ !  0 $  0    0 $ !  0    0 $ !  \nM0    0 $ !  0    0 $ !  0    0 $ !  0    0 $ !  0    0 $ !  \nM0    0 $ !  0    0 $ !  0 !    !  0 $ !    !  0 $ !    !  0 \nM$ !    !  0 $ !    !  0 $ !    !  0 $ !    ! #X<>5X"^,<ZC^?>\nMQY:9U*L\'G^[1/Z"P^*U\'8L77*_:;\\\'X+( #P:3[OKYA4<=CRAH9%525[Y8Y^\nM^+:(LZYM];F:/6Z 2P#X%,_ZWUG3[LT!ZT9-.ZQI\\^#I_;\\3 ]H>677(QFO&\nM)\'N8  & 3]_8/S4BBBY;-K#QT<$1MT0,CXB)?3]7\'T<T]CLP]^I^,>[5)/<^\nM.@)\\\\D=^DB21)!%G_6Q&%&W>9]B2QL$1$?&\'UW\\Z+=+G-T2\'/[4^\\+JU2?&P\nM?2I.2Y*=-DOZ)F8 \\*F<Z.>V_M#WE,P3JT96E9^0F_\'[:\'KQP"-;5KIGGXYO\nM_W\'_*+HYHG=-NU\'3TZ^7=SYR5;>FO"07ASZ?\'-0]TC2MW?T!O D(G_#K_&VF\nM/!Z?7;ZVX\\&UGZV:TU1^P^V7M"R>N6+N397W\'_"YQZZ??MR1E3./&?]<FZX1\nMTP]JNW=$[YJBIII,FHGFHB4Y,P#X= S\\K>?\\%9>6W33E?PX9N&Y-EX//NW\'T\nMK3\'MBP]6C(YX;/X=164=MJ[=YJ8\'9L53=T9U)N+M@]X9\'QTK(Z)V_J,G_S9J\nM,M6UF<A$FK8.EP#P*3GK)Q$K)MU8?FGC\\K*97WOIYC23?*W/,T-OC>$M*ZU-\nM5[PXL??6+=9WCHCGLW\'B:5\'0+_=<=MVS$7%_V8*:F@.B)I<FF4A;)=%TR"&Y\nM5@O>]1D! 8!/T/ _=53%T^?F%>3.\'#BA[?WMYC]_YW=7#HF(B)_LO-H#=TZY\nM[PM;8Q"#7_]YQ+WKAP]I$YG6R]YJ2<CBO9ZXM^; NC231*1->26MJIO+WR[I\nMD>8.79C[*U<9P,<T]I,D24INKV\\X[?\'?S]\\P=]A-_S\'[UJ+5ZR9LV-W*C<-.\nM\'K[]P;JU9U5OV5P6Z92[.B37\'_>=THBY:Z;_KFOWQJ9,DLTU9]J4Y[8T5%<U\nMUQ?5U53W[)>8 < G;-(?,?*F-OUKS[D[_G!,^TW/\'Q,1-T37N^.KWYKQ[DV&\nMW\'/WW3L>+2X^>E%]\\SO1X<ZNJXMK*P];&;/^_$;]WG6U2293E(NDH%5#8UTV\nM/Y=7ORJ;J4DC=OJ(@ # QS;JV[_3F$1$-(\\_XNC2W*#+ZS<,BN@RY]O+ZJ:.\nMB(A8W\'_NZ"6[V?K$71YMFPOLNV3>OU[Z7$7VS\'AKW>W1O;$@DRE8U"LOD];6\nMI9E<FJ392"/2U\'L \\+&/_S;K(W)U^5<M*&[*G-\'^UQUC^9 \'QT;$U\'&W1N?I\nMKT9$1$7GIVOV?*>CXNXXJ_724T9/[\'M2W_GY>4F2I+W3@L:ZNFR2)DUI9)MR\nMN6S!8@& C_\',GTLB.^#;FQ<_/7==?N.4TN8O5)\\8WUT5\'5:/C8B8-_36B,*M\nMY_0K7E\\P8M<=3\'TF.G0=_I[[KSWFF*4157WF1K:A.<TUUK0J:&Y((DV:DDR:\nM)(69HNPN-P($ #[:B?^D!<4U]9>_>-HQDR+Z#QS;\\G&^7O-^U*&Q94A6;/CS\nM:YO&1D0\\\\INKYS3NNH?9KWRIZ8#"]S["T2_\'\'3\'VFKPIY^8:-^=\'FI^K3B(3\nM:7.2UW9+DA1F7]CU1J  P$=RO1\\14P;5MMEX_+).]?W\'\'#MP:$2,JDW:1D3$\nMS,??_-Y#8R(B8F31NMR2<1$1L:#-VL8QN^YKR<R%F\\XY[CT/-;U/8?[(ADE]\nMEMX72:NVC5NR:9K-IKEH3HHSU2]\'SY?^<@,!@(]@[$<4-Y]YQ^GKCVI\\>_E5\nMS_WHY*.C?I_R@FL6M6Z*B(EC7WNC\\Q%;U^NQ8Y.+W[6_25T6;HK]^[_G\\4J*\nM]XYXKO#X.*/O_(@#2NO3;$-#DDO+TI(%$;$H8I=[  ( ?\\^Q?^J5;S=OR2MX\nM\\XE?MW^KKGKR_L=%Q VS_O,+CT2\\N?R7"W_297C$U+Z\'/#QCQI[M=)^&31&K\nMW_L+/"=-V5P:_6Z;?N9GUD1$<9*))--F?283Q9D^"R(B#LJE!8>F+P@ _%W\'\nM_KA!K7\\UMNJ=I_Z49J*B=&U\\Y;+RS.3)$1$U[6[[QHR( =O6?K.XL#ZSAWL>\nM,:OUEKAQS?0SW_W4Y:]<^,YIT6M)1,RZ(,I_V.^@IMJT,+N@1VU1)JFOR17V\nM61#1HZ8Y-N?G\'=R\\6 #@[S?G/W:?RF3-R_O>/",FIC\'VB1\\4_/<58[<^57_>\nM 0LK=CZK-V:>[+"G^]_X1C;_]XMW,_[C[9XW?SOBUI$1D9<?K1L+<EORFW.9\nM7B]%1(^T*5.7ZY5Y,2FH;BIH:+\\^VRVS1 #@0S6X=.N9O+BFX^8VE0/Z;HRX\nMMGM-_K()M<=<<,NVM<;,?7/OMCN?U=^J\'OG0KCN:-J]B[\'M, 2:>L67AO^V\\\nM9-MLH\'+9;\\Z>V[_RV:$WYU;VC*[3SWBQO+ZYOJ%-STBS30T-27,N"F-AWU;9\nMNL95T2HOTW-1A+\\\' !_:B7_%Z*[=#GVMN\'55YW\\N67UMRPA^<OR<:#OXYKQQ\nM*W[1LN;$L3,\'[[KMGS_3T.FV<W9>LBCOA4%+#MZC R\\NW?3R:1$1<=%10T\\:\nM,\'I:U8D;-I\\8$:]-OK)_38?,RJ9<0;:PH+:V,=O4L?ZE7$1TCYKTLYF->8MS\nMX<M \\&&-_W%7[7?PFFE+7GCR["TG?#?7I>7TW&E.Q-%7/IHWX4L1$;%TV;]^\nMJ]_,73<NK.^TZSB<UKKST/*7I^[!<:_]QG6UI;TG141$<S8^O_S:X9?V.OK$\nMB)C:?-W>D30FG;JT:DB;&_+;15YV4\\M-P"6%Q<793#;?)0#\\S>.^^:UUAT0,\nMJIWVS4775VY=?F*TO^J:B(@X\\_7V:^+>O3M^[=5SYQP?,>WQX]LLO?C"\'>_A\nM/58_K\\O<RR/R)^XTY7]][OU1_^57=BSXRSG#-G-O__F%)9UNKXJ(B(K.>S6_\nMW\'\';4V_LU2TRF4WKV[3J_&;:>DMA%*<56UJ>RD72:W.N8($ P-_HV#N;VO_B\nM_A\\=T:X^[;3JHEF#MBW??L&?WM&C<>6SFW[<\\?2"B\'B]KG-T&EJYXQV 6](3\nM7BV8-*1RE\\_V59T\\-6+8]KL$/UQ:]="7=W?PAZ8UE=7<>-\\=7[D^(N*=2S8D\nM/1NV/5?0&+F^16G]YN8.D4;[ZJ;2!3LVS,7VOQHN /!!S_\\;1NV;_YW2/K-/\nMC_,O++DQ8G#$2[><<\'Q$1$RJ2BOW\'1Y=)W3,?_CRJ1,*AS4^]L?>]PR,B)_-\nM7+AM%Q=^_<NGYBH_7QCU.[\\7E\\E&Q*_7C6YY=,_!\'4?L_A>8_]:<B+:SN[5\\\nM,V#(RAC??D[^LH@.R9B7OG]9Q/Q(^D1-0]H4+VR.R.WV<E\\ X .._],VC"\\M\nMJ%@X,/MJ7)ANOG+\\T .>?;RLKB@B9I4\\]\\65S>WNFC8\\QHV+B!&7]KQO7;+A\nMR$S;+<VY5>=NWT=%FV1%\\?"KNT7SNIWV/.2VD=<U_7#;J&]W4/D;_[7;WZ!7\nMV9R(WNWW;7E4G3GUWJJ";WYIO[4=9\\_JG6X_U1]8$K7_]\'#D=OD.P/:?W06 \nM#QB D;%FX*AL3<PHJ&^J&O+0W?\';ZL\'E=;TBNWKCS\\]?,W_C"\\\\^W6/_LF=R\nMR]/(\'K"XOO*&\\8V\'%]1O.FG\'/F:ONN2PL\\^;>%2[R963=RQ]_)YS&IJ6G]WR\nM8&JG\'S^X_MI=;@I^K\\<K5T=$Q"^?NBG>:%49DPL*OQ4QZ[>K[XV(LDV[CO$D\nM_MH_"Q0 ^( !V%G9Q:=^_Y&(F/*[]8>OGES:LG#<VU>,SMMX];+FDGE=5G;M\nM/N;Y\'YP7$3%[X-TK"NO_)2(N?NZ189VO>:C;!3_YP[N_X3NS=.6(B/C5L&.[\nM#WLT71UIIL.X^XN?N?2GYYU?WWOL_<7/9 M.:;>I]8,ESR^HZ[.QL/N(L6MO\nMW\'[>W]-_#B@ \\$$3D-N>@MQ[W$_OL_6MM_(UZ= C%I0W\')%Y,K.QVPD+\'XC3\nMC_II1?>.-TS^?NEA+WVU8\\&B_\'D%V0LB8F9IT=-YA4OS_WW2B$LNFI=7N#1_\nMT;VG//"[ULN;2[(=>I^3YO5[]*Y65^8_\'45YZXH&I3\'OBK*1=T:<D\\EF-_4<\nM\'_\'^_CNX ,!\',4DHNFSE&W/.S":9_=/[RCK4SXKE^:MGCXF(.*OAPL_<]6)^\nM)ME8UBF_*MF0S:S/B^;V^P[I%X7\'YNVU[O#Q$=&N>7U$1$EUQ%GESRR(**F.\nMLLA>]-3AYW?:>H118SJ][^$O /#1M*!\\X_^]TH#V5;=VBI;K^/YS_^+)W&X^\nMMK=CI[D=_T5, . 3.AO(;?]YQWMTV\\;N3M<1.P9[;N=KC>T;?\'@$ %RE  ( \n>"  @ , _N/\\= \'\'!:XQHPP/      $E%3D2N0F""\n \nend\n'
#logo_uuenc = StringIO.StringIO(logo_txt)
#logo_uudec = StringIO.StringIO()
#uu.decode(logo_uuenc, logo_uudec)
#logo_file = StringIO.StringIO(logo_uudec.getvalue())

loopsecs = 60.0
fadesecs = 10.0
speedup = 1.0
res = pygame.display.list_modes()[0]
if res == -1 :
  res = (240, 300) # PocketPC fallback

for o, a in opts :
  if o in ('-r', '--res') :
    width, height = map(int, a.split('x'))
    res = (width, height)
  if o in ('-c', '--colors') :
    colors = eval(a)
  if o in ('-l', '--logo') :
    logofile = a
  if o in ('-t', '--looptime') :
    loopsecs = float(a)
  if o in ('-f', '--fadetime') :
    fadesecs = float(a)
  if o in ('-s', '--speedup') :
    speedup = float(a)
    
try :
    raise "Images disabled for pygame.draw challenge!"
#  image = pygame.image.load(logo_file)
#  image = pygame.transform.scale(image, res)
except:# pygame.error, e :
  image = None

stretch = 4
starty = int(res[1]*0.75)
h = (res[1]-starty)

screen = pygame.display.set_mode(res, pygame.FULLSCREEN)
pygame.mouse.set_visible(0)


class waveimage:

  def __init__(self, size, color, num=4):
    self.size = size
    self.color = color
    self.surface = pygame.Surface(size, pygame.SRCALPHA, 32)
    self.speed = max(random.random(), 0.1)
    
    n = max(int(random.random() * num),1)
    w = self.size[0]
    h = 0
    while h < 0.1 :
      r0 = random.random()
      r1 = random.random()
      a0 = min(r0,r1)
      a1 = max(r0,r1)
      h = a1-a0
    
    for x in range(size[0]) :
      t = x*2*math.pi*n/w
      s = math.sin(t)
      a = a0 + (1.0+s)/2.0 * (a1-a0) 
      y = size[1]*a
      pygame.draw.line(self.surface, color, (x,size[1]), (x,y))


  def get_surface(self):
    return self.surface

  def get_size(self):
    return self.size
    
  def get_speed(self):
    return self.speed
    
def fadefunct(t, loopsecs=60.0, fadesecs=10.0):
  t /= 1000.0 # Seconds
  t %= loopsecs
  if t < fadesecs :
    return ((fadesecs-t) / fadesecs) ** 2
  if t > (loopsecs - fadesecs) :
    return ((t - loopsecs + fadesecs) / fadesecs) ** 2  
  return 0
  
def paint(waves):
  screen.fill(colors[0])
  
  ticks = time.time()*1000.0
  #ticks = pygame.time.get_ticks()
  fade = fadefunct(ticks, loopsecs, fadesecs)
    
  for wave in waves :
    x = int(ticks * wave.get_speed() / 20 * speedup)
    x %= res[0]*stretch
    
    screen.blit(wave.get_surface(),(x,starty+fade*h))
    screen.blit(wave.get_surface(),(x-res[0]*stretch, starty+fade*h))
 
  if image and fade > 0 :
    image.set_alpha(fade*255)
    screen.blit(image, (0, 0))
    
  pygame.display.update()
  return fade
  
  
random.seed(int((time.time()+fadesecs)/loopsecs))
waves = []
for color in colors[1:] :
  waves.append(waveimage( (res[0]*stretch, h), color))
    
old = True
finished = False

while not finished:

  for e in pygame.event.get():
    if e.type in (pygame.QUIT, pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN, ) :
      finished = 1
      break

  fade = paint(waves)

  if fade < 0.1 :
    old = True
    
  if fade >= 0.9 and old :
    random.seed(int((time.time()+fadesecs)/loopsecs))
    waves = []
    for color in colors[1:] :
      waves.append(waveimage( (res[0]*stretch, h), color))
    old = False    

pygame.display.quit()


