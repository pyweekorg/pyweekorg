Submissions for the pygame.draw challenge:

  http://media.pyweek.org/static/pygame.draw-0606.html

These entries generally require:

  Python 2.4+
  PyGame 1.7+

and NOTHING ELSE.

trizone.py      -- Jure Vrscaj
goop.py         -- Toby Sargeant
pyscribbles.py  -- Jes Pumphrey
philhassey.py   -- Phil Hassey
Go4Col.py       -- Georg Bernhard
GoCube.py       -- Georg Bernhard
GoFloat.py      -- Georg Bernhard
GoGfxWaves.py   -- Georg Bernhard
GoGrav.py       -- Georg Bernhard
minigolf.py     -- Erik HK
AssuredDestruction.py -- Erik Johnson
FysPhun.py      -- Alex P-B
gravity.py      -- Seth Yastrov
alocador.py     -- Team PyAr
hazzard_sector.py -- Kenneth Backus
TrashVacHeroX.py -- Donal Heidenblad
bobs_excuse_to_KILL.py -- Thiago Chaves
quest.py        -- Greg Ewing
tanvaders.py    -- Richard Jones

