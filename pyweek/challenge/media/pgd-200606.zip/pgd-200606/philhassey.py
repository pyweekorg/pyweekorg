COPY = "(c) 2006 phil hassey - gpl"
import array, wave, cStringIO, random, base64, math, zlib
import pygame
from pygame.locals import *
MIX_FREQ = 22050
FPS = 40
SW,SH = 640,432
TW,TH = 16,16
WIDTH,HEIGHT = 40,24
TMP,BKGR,WALL,BLOCK,PLAYER,B,SUPER_B,E1,E2,CRAZY_B = -1,0,1,2,3,4,5,6,7,8
POINTS = {B:25,SUPER_B:75,CRAZY_B:125,E1:50,E2:50}
LEVELS = [[3,0,0],[6,0,0],[6,1,0],[6,2,0]]
LEVELS.extend([[6+(v+2)/3,3+(v+1)/3,v/3] for v in xrange(0,95)])

def ft(f,l): return [float(f*v)/MIX_FREQ for v in xrange(0,int(l*MIX_FREQ))]
def t_sin(t): return [math.sin(v*math.pi*2.0) for v in t]
def t_square(t): return [float(1-int((v%1.0)/0.5)*2) for v in t]
def t_rand(t): return [float(random.randrange(-1000,1000))/1000.0 for v in t]
def t_saw(t): return [((v+0.5)%1.0)*2.0-1.0 for v in t]
def t_tri(t): return [abs(((v-0.25)%1.0)-0.5)*4.0-1.0 for v in t]
def sa(si,a,d,s,r):
	a,d,r = int(a*MIX_FREQ),int(d*MIX_FREQ),int(r*MIX_FREQ)
	so,l,n = [],len(si),0.0
	ms = si; so.extend([ms[n]*n/a for n in xrange(0,a)])
	ds = 1.0-s
	ms = ms[a:]; so.extend([ms[n]*(1.0-ds*n/d) for n in xrange(0,d)])
	ms = ms[d:]; so.extend([v*s for v in ms[:len(ms)-r]])
	ms = ms[-r:]; so.extend([ms[n]*s*(r-n)/r for n in xrange(0,r)])
	return so
def ts_fm(t,s,m): return [t[n]+s[n]*m for n in xrange(0,len(t))]
class _sound:
	def set_volume(u,v): pass
	def play(u): pass
def snd_gen_basic(f,l,
		m_wave,m_fmul,m_a,m_d,m_s,m_r,m_level,
		c_wave,c_fmul,c_a,c_d,c_s,c_r,c_level):
	waves = [t_sin,t_square,t_saw,t_tri,t_rand]
	m = sa(waves[m_wave](ft(f*m_fmul,l)),m_a,m_d,m_s,m_r)
	return [v*c_level for v in sa(waves[c_wave](ts_fm(ft(f*c_fmul,l),m,m_level)), c_a,c_d,c_s,c_r)]
def smp_to_snd(so):
	if not pygame.mixer.get_init(): return _sound()
	samples = [int(v*32767) for v in so]
	stream = cStringIO.StringIO()
	f = wave.open(stream,'w')
	f.setnchannels(1)
	f.setsampwidth(2)
	f.setframerate(MIX_FREQ)
	f.writeframes(array.array('h',samples).tostring())
	f.close()
	stream.seek(0)
	return pygame.mixer.Sound(stream)
def txt2freq(n):
	freqs = [440.00,493.92,261.64,293.68,329.64,349.24,392.00]
	let,axe,okt = n.upper()
	freq = freqs[ord(let)-ord('A')]
	if axe == "\x23": freq *= (2**(1.0/12.0))
	freq *= 2**(int(okt)-4)
	return freq
def tune_render(game):
	stream = cStringIO.StringIO()
	f = wave.open(stream,"w")
	f.setnchannels(1)
	f.setsampwidth(2)
	f.setframerate(MIX_FREQ)
	notes = {}
	mul = 32767/4
	chunk = int(0.1*MIX_FREQ)
	so = [0 for n in xrange(0,chunk*4)]
	cnt = 5
	for _p in PATTS:
		game.count(str(cnt))
		cnt -= 1
		for _r in xrange(0,128):
			for _i,_t in _p:
				_n = TDATA[_r][_t]
				if _n != '':
					key = _i,_n
					if key not in notes:
						notes[key] = snd = snd_gen_basic(txt2freq(_n),*INS[_i][1:])
						for n in xrange(0,len(snd)): snd[n] = int(snd[n]*mul)
					snd = notes[key]
					for n in xrange(0,len(snd)): so[n] += snd[n]
			f.writeframes(array.array('h',so[0:chunk]).tostring())
			so = so[chunk:]
			so.extend([0 for n in xrange(0,chunk)])
	f.close()
	stream.seek(0)
	return pygame.mixer.Sound(stream)

TILES_IMG = """iVBORw0KGgoAAAANSUhEUgAAAJAAAAAQCAMAAADOKAZSAAAAk1BMVEWYAAAGCBwdCCAbFgM4DA0WGFAiLwoBOzFqExRbEluSERFYMQe0BwYAXko+ObAVdxeUIJa2CbrcGBcAe2JIRNKBUAKaSAPkAOWqTwAAknZaUP+HbAJUV/8HrA0wki63ZirhS0sE2Q54cv/kQuC9gQfhT+GzmAXlenrhbeBF3ULig+Owsq7Zxyjk1QCU5ZL7/fkAAQCPeg2PAAAAAXRSTlMAQObYZgAAAu9JREFUSMeNlotagkAQhREwhUBAU6TEG2Kh2c77P11nZhZv0afnq9nWdtm/mbNDDt1pPqfVajWft2Nx0aQoYnJEWOhc1O69nnsvN0v+FR3psv96cgaakeC0YxErTBwzjwWi/lufrnjCMRT5Le1LudlsyjKh54CCIGMFbkDH3h+g2YyUR8eZwsSWZ0DKs9heiGgYjUVRqL9NNs1PAz1FRMdjled5VVVgOnZk6F4WJ1YuAaL++3a7aInIj4xZQ8YIEXiMYSBjypLaejrnot7NAVQbczh8IVZdQBf36HjDI0CcHwCBqCfPHxsi8/nJMcIDXjb8E3gQSw8fpPjTXSIpCp/3utvvXm3EPMh5ZV1zzNxOoBsXTSyPVg0eUh4AaY5oKEBIEAOFROU1UAKe/OtQZyQxwHbv+/t02nl7jq+YZwJUVQKUdgHdumjS8oi3Y7I8DCRENB6vLyULPSqbH2MaKRlshMx81WwQjeR4Owb61rgXoAOKBSFm2WMP2esl3i6KAbnv2zPQYtEToM+1KgxDn4GaVjAR5QccVmcSkQBJzelkI87P6wOzVrKqA+iuDc0nmppC8zQgckdvrBELLqJovF7fAG3OPMslZ6hmklRiIBlikqnEDwGqW6A07QC6a0PziTTEia3bgD10BmJXXwGFw5A91DRwg3wlDBRUdZUGblaDhz3kc62m/h5x5XHJKgCRMcTYnUDXbUj6kDpaot4yC6S3DE3RAg2H4RBAQsRaJlwySgHiUiCRz5vu9lPcso8PvWUpiHR92gn0pw8pjr1ntg8JkPYhtKFxpPkZ+iHv4GLxmCRJ49HDPuRmVaUTdOzua9/6R2Ixue9DSjRqOzUaNQQcJMiXxogclcsleJ5r1QEToWTIT0pOJ5D6R+MNjwVyev2Re3mV+koUomAyXzJQAgMtn3u9cudMuV4BOZ1A6h/rongAMQoivu0Rvd7VWeSHQtS+3slLgFQm3lM8XLU0s328A+iROp/Y8e/Hf2sf7f8F5tPtMJAr4yUAAAAASUVORK5CYII="""
FONTIMG = """iVBORw0KGgoAAAANSUhEUgAAAMAAAAAwAQMAAAB9gOddAAAABlBMVEUAAAD///+l2Z/dAAAB5klEQVQ4y53TsW7bMBAA0DNchB0O4ppBcH/BQBYNAtxPSf5AQPdQRYYsRvxLZ2jwQpi/QKNrB3bjQJi9k2JZajwEJQhb5oOOvuMRNsqbXTSHZLaIsO4Q5GcL/BWySzLtO8gzATxt12SREOgC1mI3A/wIeAuyi7x01r7bJYa8Fdj3kHwh8MulAqp8BHtEYjg5DDw18KfGOjj47f4b+uwcb4Zap+ASgyR4OkSpgeMSoFZxgL4kr/FZRa6Ht5aO/dIwJI5OI0iQYXA9OpQxAM0BRoCb8PRWLkfg6HkXB9io+O26+bbMh1QUeLLWvITnyzoErD3VWuOPN/uHKHyEh8KGf8FOYNw86ORd4iptuFBE1wSDiv4QuUorLhTRtSSG1uY1dCqYXWIbt4Ds13zsnZbu4mhXoEdun3tOnggfuE+mANQDfB7MPhkXc4tGTffwTf6ZuNszlfllAnsfAtQa6o5kfhLsLcheUuNaZarzFAwF7iCt+XrVPGE6lg5Q/ijSdJVTUq5FfQYoPXz9PsIKoFjw1bkDqBq4fxz7ZyUv8U1jaCqxy5FgD4WAL8XGs1KRQcMZFsy+vJ7VOyQBniMMofhCSahlq8ZQw+b9Y1MpWLYT4Aj9Y9XcwaKlWYIcSnOCXwDaeUl6mJXkL1K+ideEVtW4AAAAAElFTkSuQmCC"""
HELP = """eNqFkUsOgjAUReddxR3qhCiEmDgsRbqNWhswUUv4GHH1loItKEZGPQ33817BcFSibmqswhilPt/MUQlZrAmAbYCEglH0XxjA0AiRBUoIUtRtqSpns1u0AaWD0No4iAYgFkxUOt5bmoDNGo9OvASk/2tWSIob1KO86JPa/y/DGHM50/wZMLD/ZXonggwqz81W4s2P5WbT5Wafy8UgL0QjC+i7mao5X/0cOMDPYbL8HOBGzSEr8ezc02x/PjGftuDfLWY+/UbrqxIVOt2+uxhR4rtwmvgunL4ARwODxw=="""
INS = [
[32.4,0.18,1,3,0.03,0.0,1.0,0.09,4.7,1,1,0.01,0.12,0.54,0.03,1.0],
[396.9,0.26,3,4,0.09,0.0,1.0,0.0,0.9,0,1,0.01,0.03,0.83,0.12,1.0],
[10.0,0.17,0,4,0.04,0.04,0.1,0.06,10.0,0,1,0.0,0.0,1.0,0.09,1.0],
[828.1,0.45,0,5,0.1,0.0,1.0,0.22,5.6,0,1,0.01,0.08,0.56,0.22,1.0],
[250.0,0.2,2,0.5,0.0,0.0,1.0,0.2,0.8,1,0.5,0.0,0.0,1.0,0.05,0.3],
[48.4,0.2,2,0.5,0.0,0.0,1.0,0.0,0.4,0,0.5,0.02,0.04,0.71,0.08,0.7],
[250.0,0.1,4,1,0.0,0.0,1.0,0.0,9.9,0,1,0.0,0.02,0.14,0.06,0.5],
[250.0,0.1,2,2,0.0,0.0,1.0,0.0,0.8,3,0.5,0.02,0.04,0.7,0.04,0.5],
]
IEXPLODE, IHATCH, ISMASH, ISCREAM = 0,1,2,3
IM,IB,IH,IS = 4,5,6,7
TUNE = """eNrtVbsOwyAM3PkNZpY+Z4OBn+LjC4jQ4LqBsjViQNgKx/lirLPqFqy6BqPucX8E3eYi5EjHVSPRALqnyY0B836MsQRjWYxP9FskyL1DSsZ4jvUY+ZseHxe0ecFAxQBT2/92JqnFcgbjF5/3mrPqnWwxTvYxSHhwgseyGCc3PTE6UWfONjN6ojYgGD+hxw3oIZq/9PSzP/R1grpUvfQf2KJnj+kC6AjgBAlf2HtszBqbZTXLapbVnNZqcMJqRmrTEy+AWg2wmGOrSTxQcmBedLrHtJOSeXoYypOmoochkxKQ5dm7zVO8AFmXnfA="""
TDATA = [[v for v in line.split("|")] for line in zlib.decompress(base64.b64decode(TUNE)).split("\n")]
PATTS = [
	( (IM,0), (IB,1), ),
	( (IM,4), (IB,5), (IH,6), ),
	( (IM,0), (IB,1), (IH,2), (IS,3), ),
	( (IM,4), (IH,6), (IS,7), ),
	( (IH,2), (IS,3), ),
	( (IB,5), (IS,7), ),
	]

def rr(a,b,step=1): return random.randrange(a,b,step)
def rand(): return rr(0,65536)
def sign(v):
	if v < 0: return -1
	if v > 0: return 1
	return 0
class Player:
	def __init__(u,x,y,live):
		u.x,u.y,u.live = x,y,live
		u.frame = 0
class L:
	def __init__(u,game):
		u.g = game
	def init(u):
		layer = u.layer = [[0 for x in xrange(0,WIDTH)] for y in range(0,HEIGHT)]
		beasts = u.beasts = []
		for y in range(0,HEIGHT):
			for x in range(0,WIDTH):
				layer[y][x] = BKGR
				if rand()%40 < 12:
					layer[y][x] = BLOCK
				if rand()%1000 < 8:
					layer[y][x] = WALL
		for x in range(0,WIDTH):
			layer[0][x] = WALL
			layer[HEIGHT-1][x] = WALL
		for y in range(0,HEIGHT):
			layer[y][0] = WALL
			layer[y][WIDTH-1] = WALL
		x,y = WIDTH/2,HEIGHT/2
		for yy in (-1,0,1):
			for xx in (-1,0,1):
				layer[y+yy][x+xx] = TMP
		u.player = Player(x,y,1)
		l = LEVELS[u.g.level_n]
		for i in range(0,l[0]):
			beasts.append(u.add(B))
		for i in range(0,l[1]):
			beasts.append(u.add(SUPER_B))
		for i in range(0,l[2]):
			beasts.append(u.add(E1))
		for y in range(0,HEIGHT):
			for x in range(0,WIDTH):
				if layer[y][x] == TMP:
					layer[y][x] = BKGR
		img = u.g.image
		tiles = u.tiles = []
		for x in xrange(0,img.get_width(),TW):
			tiles.append(img.subsurface(x,0,TW,TH))
		u.frame = 0
		u.first = 1
	def paint(u,z):
		z.fill((0,0,0xaa))
		s = z.subsurface(0,16,TW*WIDTH,TH*HEIGHT)
		layer = u.layer
		tiles = u.tiles
		for y in xrange(0,HEIGHT):
			for x in xrange(0,WIDTH):
				s.blit(tiles[layer[y][x]],(x*TW,y*TH))
		px,py = u.player.x,u.player.y
		for x,y in u.beasts:
			v = layer[y][x]
			if v not in (B,SUPER_B,CRAZY_B): continue
			dx,dy = px-x,py-y
			if abs(dx) > 2*abs(dy): dy = 0
			if abs(dy) > 2*abs(dx): dx = 0
			dx,dy = sign(dx),sign(dy)
			s.fill((255,255,255),(x*TW+4,y*TH+4,2,2))
			s.fill((255,255,255),(x*TW+10,y*TH+4,2,2))
			s.fill((0,0,0),(x*TW+4+dx,y*TH+4+dy,2,2))
			s.fill((0,0,0),(x*TW+10+dx,y*TH+4+dy,2,2))
		if u.player.live:
			s.blit(tiles[PLAYER],(u.player.x*TW,u.player.y*TH))
		fnt = u.g.font
		for x,y,text in [(0,0,'score: %05d   --= beast =--   level: %02d'%(max(0,u.g.score),u.g.level_n+1)),(0,SH-32,"f1 - help  f2 - music  pgup/pgdn - level"),(8,SH-16,"pyweek 64k - "+COPY)]:
			z.blit(u.g.font.render(text),(x,y))
		pygame.display.flip()
		if u.first:
			u.first = 0
			return Pause(u.g,"get ready!",u)
	def add(u,i):
		c = TMP
		while c != BKGR:
			x,y = rr(1,WIDTH),rr(1,HEIGHT)
			c = u.layer[y][x]
		u.layer[y][x] = i
		return x,y
	def event(u,e):
		if e.type is KEYDOWN:
			if e.key in (K_UP,K_DOWN,K_LEFT,K_RIGHT):
				u.player.frame = 0
		if e.type is KEYDOWN and e.key == K_ESCAPE:
			return Prompt(u.g,"quit? y/n",Quit(u.g),u)
	def repaint(u):
		u._paint = 1
	def loop(u):
		if u.player.live == 0:
			u.g.sfx[ISCREAM].play()
			return Prompt(u.g,"try again? y/n",Reset(u.g,u.g.level_n,L(u.g)),Quit(u.g))
		if not len(u.beasts):
			u.g.level_n = min(len(LEVELS)-1,u.g.level_n+1)
			return Pause(u.g,'good job!',L(u.g))
		if u.player.frame%4 == 0:
			u.loop_player()
			u.repaint()
		u.beasts_clean()
		if u.frame%32 == 0:
			u.loop_beasts()
			u.repaint()
		u.beasts_clean()
		u.frame += 1
		u.player.frame += 1
		if (u.frame%120) == 0:
			u.g.score -= 1
	def loop_player(u):
		p = u.player
		x,y = p.x,p.y
		if u.layer[y][x] != BKGR: p.live = 0
		if not p.live: return
		keys = pygame.key.get_pressed()
		dx = -keys[K_LEFT] + keys[K_RIGHT]
		dy = -keys[K_UP] + keys[K_DOWN]
		if (dx,dy) == (0,0): return
		x,y = x+dx,y+dy
		v = u.layer[y][x]
		if v in (WALL,E1,E2):
			return
		elif v in (B,SUPER_B,CRAZY_B):
			p.live = 0
			return
		elif v in (BKGR,):
			p.x,p.y = x,y
			return
		elif v in (BLOCK,):
			if u.push(x,y,dx,dy,1):
				p.x,p.y = x,y
				return
	def move(u,ox,oy,nx,ny):
		v = u.layer[oy][ox]
		u.layer[oy][ox] = BKGR
		u.layer[ny][nx] = v
	def beasts_clean(u):
		while u.beasts.count(None): u.beasts.remove(None)
	def loop_beasts(u):
		layer = u.layer
		beasts = u.beasts
		px,py = u.player.x,u.player.y
		n = 0
		for x,y in beasts[:]:
			ox,oy = x,y
			v = layer[y][x]
			if (x,y) == (px,py): u.player.live = 0
			if v == B:
				if rr(0,2) == 0: dx,dy = rr(-1,2),rr(-1,2)
				else: dx,dy = sign(px-x),sign(py-y)
				x,y = x+dx,y+dy
				if layer[y][x] == BKGR:
					u.move(ox,oy,x,y)
					beasts[n] = x,y
			elif v == SUPER_B:
				if u.is_surrounded(x,y) and (rand()%10) == 0:
					u.g.sfx[IEXPLODE].play()
					beasts[n] = None
					layer[y][x] = BKGR
					for dy in (-1,0,1):
						for dx in (-1,0,1):
							if (dx,dy) != (0,0) and layer[y+dy][x+dx] == BLOCK:
								layer[y+dy][x+dx] = B
								beasts.append((x+dx,y+dy))
				else:
					if rr(0,2) == 0: dx,dy = rr(-1,2),rr(-1,2)
					else: dx,dy = sign(px-x),sign(py-y)
					x,y = x+dx,y+dy
					if layer[y][x] == BKGR:
						u.move(ox,oy,x,y)
						beasts[n] = x,y
			elif v == E1:
				if rand()%15 == 0:
					u.g.sfx[IHATCH].play()
					layer[y][x] = E2
			elif v == E2:
				if rand()%15 == 0:
					u.g.sfx[IHATCH].play()
					layer[y][x] = CRAZY_B
			elif v == CRAZY_B:
				if rr(0,2) == 0: dx,dy = rr(-1,2),rr(-1,2)
				else: dx,dy = sign(px-x),sign(py-y)
				x,y = x+dx,y+dy
				if u.push(x,y,dx,dy):
					u.move(ox,oy,x,y)
					beasts[n] = x,y
			n += 1
	def is_surrounded(u,x,y):
		for dy in (-1,0,1):
			for dx in (-1,0,1):
				if (dx,dy) != (0,0):
					if u.layer[y+dy][x+dx] == BKGR: return 0
		return 1
	def push(u,x,y,dx,dy,m=0):
		if (dx,dy) == (0,0): return 0
		ox,oy = x,y
		layer = u.layer
		beasts = u.beasts
		while layer[y][x] == BLOCK:
			x,y = x+dx,y+dy
		n = layer[y][x]
		if n == WALL: return 0
		elif n in (B,E1,E2,CRAZY_B):
			if layer[y+dy][x+dx] == BKGR: return 0
		elif n == SUPER_B:
			if not u.is_surrounded(x,y): return 0
		layer[oy][ox] = BKGR
		layer[y][x] = BLOCK
		if n in (B,SUPER_B,E1,E2,CRAZY_B):
			u.g.sfx[ISMASH].play()
			layer[y][x] = BLOCK
			u.beasts[u.beasts.index((x,y))] = None
			u.g.score += POINTS[n]*m
		return 1

class ImageFont:
	def __init__(u,image,size,hints):
		x,y = 0,0
		tw,th = u.scale = size
		chars = u.chars = {}
		for c in hints:
			img = image.subsurface(x,y,tw,th)
			chars[c] = img
			x += tw
			if x >= image.get_width(): x,y = 0,y+th
	def render(u,text):
		tw,th = u.scale
		size = len(text)*tw,th
		s = pygame.Surface(size).convert_alpha()
		s.fill((0,0,0,0))
		x = 0
		for c in text:
			if c in u.chars:
				s.blit(u.chars[c],(x,0))
				x += tw
		return s

class Help:
	def __init__(u,game,next):
		u.g,u.next = game,next
	def paint(u,z):
		u.bkgr = z.convert()
		z.fill((0,0,0xaa))
		img = u.g.fnt2.render("help")
		z.blit(img,((SW-img.get_width())/2,4))
		y = 44
		for text in zlib.decompress(base64.b64decode(HELP)).split("\n"):
			img = u.g.font.render(text)
			z.blit(img,(16,y))
			y += 16
		pygame.display.flip()
	def event(u,e):
		if e.type is KEYDOWN and e.key == K_RETURN:
			pygame.display.get_surface().blit(u.bkgr,(0,0))
			return u.next
class Quit:
	def __init__(u,game):
		u.g = game
	def init(u):
		u.g.quit = 1
class Reset:
	def __init__(u,game,level_n,next):
		u.g,u.level_n,u.next = game,level_n,next
	def init(u):
		u.g.level_n = u.level_n
		u.g.score = 0
		return u.next
class Prompt:
	def __init__(u,game,text,yes,no):
		u.g,u.text,u.yes,u.no = game,text,yes,no
	def paint(u,z):
		u.bkgr = z.convert()
		img = u.g.fnt2.render(u.text)
		x,y = (SW-img.get_width())/2,(SH-img.get_height())/2
		z.blit(img,(x,y))
		pygame.display.flip()
	def event(u,e):
		z = pygame.display.get_surface()
		if e.type is KEYDOWN and e.key == K_y:
			z.blit(u.bkgr,(0,0))
			return u.yes
		if e.type is KEYDOWN and e.key == K_n:
			z.blit(u.bkgr,(0,0))
			return u.no
class Pause:
	def __init__(u,game,text,next):
		u.g,u.text,u.next = game,text,next
	def paint(u,z):
		u.bkgr = z.convert()
		img = u.g.fnt2.render(u.text)
		x,y = (SW-img.get_width())/2,(SH-img.get_height())/2
		z.blit(img,(x,y))
		pygame.display.flip()
	def event(u,e):
		if e.type is KEYDOWN and e.key == K_RETURN:
			pygame.display.get_surface().blit(u.bkgr,(0,0))
			return u.next

class Game:
	def fnc(u,f,v=None):
		s = u.state
		if not hasattr(s,f): return 0
		f = getattr(s,f)
		if v != None: r = f(v)
		else: r = f()
		if r != None:
			u.state = r
			u.state._paint = 1
			return 1
		return 0
	def run(u,state,z=None):
		u.quit = 0
		u.state = state
		if z != None: u.z = z
		u.init()
		while not u.quit:
			u.loop()
	def loop(u):
		s = u.state
		if not hasattr(s,'_init') or s._init:
			s._init = 0
			if u.fnc('init'): return
		else:
			if u.fnc('loop'): return
		if not hasattr(s,'_paint') or s._paint:
			s._paint = 0
			if u.fnc('paint',u.z): return
		else:
			if u.fnc('update',u.z): return
		for e in pygame.event.get():
			if not u.event(e):
				if u.fnc('event',e): return
		u.tick()
		return
	def init(u):
		u.full = 0
		u.level_n = 0
		u.score = 0
		u.quit = 0
		u.mute = 0
		z = u.z = pygame.display.set_mode((SW,SH))
		pygame.display.set_caption("beast - alt-enter: full s"+"creen")
		pygame.mouse.set_visible(0)
		try:
			pygame.mixer.init(MIX_FREQ, -16, 0, 1024)
		except: pass
		hints = """abcdefghijklmno_pqrstuvwxyz_ABCD0123456789__EFGH:-()!?.<>/\+=__ """
		img = pygame.image.load(cStringIO.StringIO(base64.b64decode(FONTIMG))).convert()
		img2 = pygame.Surface((img.get_width()*16/12,img.get_height()*16/12)).convert()
		for y in xrange(0,img.get_height(),12):
			for x in xrange(0,img.get_width(),12):
				img2.blit(img.subsurface(x,y,12,12),(x*16/12+2,y*16/12+2))
		img = img2
		c = [ (min(255,0xaa+v*16),min(255,0x55+v*12),v*16) for v in xrange(0,16)]
		orig = img.convert()
		img = img.convert_alpha()
		img.fill((0,0,0,0))
		for y in xrange(1,img.get_height()-1):
			for x in xrange(1,img.get_width()-1):
				ok = 0
				for dx,dy in [(-1,-1),(0,-1),(1,-1),(-1,0),(0,0),(1,0),(-1,1),(0,1),(1,1)]:
					if orig.get_at((x+dx,y+dy))[0]: ok = 1
				if ok and orig.get_at((x,y))[0]:
					img.set_at((x,y),c[y%16])
				elif ok:
					img.set_at((x,y),(0,0,0))
		u.image = pygame.image.load(cStringIO.StringIO(base64.b64decode(TILES_IMG))).convert_alpha()
		img.blit(u.image.subsurface(16,0,64,16),(192,16))
		img.blit(u.image.subsurface(80,0,64,16),(192,32))
		u.image = u.image.convert()
		u.font = ImageFont(img,(16,16),hints)
		u.fnt2 = ImageFont(pygame.transform.scale(img,(512,128)),(32,32),hints)
		u.fnt3 = ImageFont(pygame.transform.scale(img,(256*6,64*6)),(16*6,16*6),hints)
		u.count('')
		u.sfx = [smp_to_snd(snd_gen_basic(*INS[n])) for n in xrange(0,4)]
		for snd in u.sfx:
			snd.set_volume(0.35)
		pygame.time.wait(0)
		u.nt = pygame.time.get_ticks()
		u.frame = 0
		u.music = None
		if pygame.mixer.get_init():
			u.music = tune_render(u)
			u.music.play(-1)
		u.count('')
		tmp = z.convert()
		m = 60
		for n in xrange(0,m):
			z.blit(pygame.transform.scale(tmp.subsurface(n*SW/2/m,n*SH/2/m,SW-n*SW/m,SH-n*SH/m),(SW,SH)),(0,0))
			pygame.display.flip()
			u.tick()
		for e in pygame.event.get():
			pass
	def count(u,v):
		z = u.z
		z.fill((0,0,0xaa))
		img = u.fnt3.render("beast")
		z.blit(img,((SW-img.get_width())/2,(SH-img.get_height())/2))
		img = u.fnt3.render(v)
		z.blit(img,((SW-img.get_width())/2,(SH/2+(SH/2-img.get_height())/2)))
		img = u.font.render("please wait...")
		z.blit(img,((SW-img.get_width())/2,SH-img.get_height()-4))
		pygame.display.flip()
	def tick(u):
		ct = pygame.time.get_ticks()
		if ct < u.nt:
			pygame.time.wait(u.nt-ct)
			u.nt+=1000/FPS
		else: u.nt = ct+1000/FPS
		u.frame += 1
	def event(u,e):
		if e.type is QUIT:
			u.quit = 1
			return 1
		if e.type is KEYDOWN and e.key == K_RETURN and (pygame.key.get_mods()&(KMOD_LALT|KMOD_RALT))!=0:
			u.full ^= 1
			tmp = u.z.convert()
			u.z = pygame.display.set_mode((SW,SH),u.full*FULLSCREEN)
			u.z.blit(tmp,(0,0))
			pygame.display.flip()
			return 1
		if e.type is KEYDOWN and e.key == K_F2:
			u.mute ^= 1
			if u.music:
				u.music.set_volume(1-u.mute)
			return 1
		if e.type is KEYDOWN and e.key == K_PAGEUP:
			u.state = Reset(u,min(len(LEVELS)-1,u.level_n + 1),L(u))
			return 1
		if e.type is KEYDOWN and e.key == K_PAGEDOWN:
			u.state = Reset(u,max(0,u.level_n - 1),L(u))
			return 1
		if e.type is KEYDOWN and e.key == K_F1 and u.state.__class__ != Help:
			u.state = Help(u,u.state)
			return 1
g = Game()
g.run(Help(g,L(g)))

