#!/usr/bin/python

#
# wuerfel faltung
#

# List objects are unhashable.


import pygame
import copy
import sys
import heapq
import pygame

COL_FG1 = (200,200,200)
COL_FG2 = (128,128,128)
COL_LINE = (255,64,64)
COL_TEXT = (245,245,245)
COL_BG = (255,255,255)

SCREENREC = [800, 600]

pygame.init()

display = pygame.display.set_mode(SCREENREC, pygame.FULLSCREEN)
pygame.mouse.set_visible(False)
display.convert_alpha()
display.fill(COL_BG)
pygame.display.flip()

fontsize = 30
maxlines = int(SCREENREC[1]/fontsize)+1
font = pygame.font.SysFont(None, fontsize)
textsurf = pygame.Surface(display.get_size())

wx = 9
wy = 9
wz = 9
wd = 3

perspzx = 2.5
perspzy = 4

ORIGIN = [SCREENREC[0]/2-(3*wx),SCREENREC[1]/2-(3*wy)]

def linear(a,b,p):
    if p < 0:
        return a
    elif p > 1:
        return b
    else:
        return a+(b-a)*p

def project(x,y,z):
    
    x,y = y,x
    
    rx = ORIGIN[0]+x+(z/perspzx)
    ry = ORIGIN[1]+y+(z/perspzy)
    return [rx, ry]

def drawcube(display, coord):
    
    x,y,z = coord
    
    x *= (wx*2)
    y *= (wy*2)
    z *= (wz*2)
    
    a = project(x-wx+wd,y-wy+wd,z-wz+wd)
    b = project(x+wx-wd,y-wy+wd,z-wz+wd)
    c = project(x+wx-wd,y+wy-wd,z-wz+wd)
    d = project(x-wx+wd,y+wy-wd,z-wz+wd)
    e = project(x-wx+wd,y-wy+wd,z+wz-wd)
    f = project(x+wx-wd,y-wy+wd,z+wz-wd)
    g = project(x+wx-wd,y+wy-wd,z+wz-wd)
    h = project(x-wx+wd,y+wy-wd,z+wz-wd)
    
    p = coord[2]/6.0
    cr = linear(COL_FG1[0], COL_FG2[0], p)
    cg = linear(COL_FG1[1], COL_FG2[1], p)
    cb = linear(COL_FG1[2], COL_FG2[2], p)
    
    col = [cr,cg,cb]
    
    pygame.draw.line(display, col, a,b )
    pygame.draw.line(display, col, b,c )
    pygame.draw.line(display, col, c,d )
    pygame.draw.line(display, col, d,a )
    
    pygame.draw.line(display, col, a,e )
    pygame.draw.line(display, col, b,f )
    pygame.draw.line(display, col, c,g )
    pygame.draw.line(display, col, d,h )

    pygame.draw.line(display, col, e,f )
    pygame.draw.line(display, col, f,g )
    pygame.draw.line(display, col, g,h )
    pygame.draw.line(display, col, h,e )

def drawline(surface, coords_a, coords_b):
    
    ax,ay,az = coords_a
    bx,by,bz = coords_b
    
    ax *= (wx*2)
    ay *= (wy*2)
    az *= (wz*2)
    bx *= (wx*2)
    by *= (wy*2)
    bz *= (wz*2)
    
    a = project(ax,ay,az)
    b = project(bx,by,bz)
    
    pygame.draw.line(surface, COL_LINE, a,b, 3 )


def drawcubes(coords, text=None, surface=None, blank=True):
    
    if blank:
        surface.fill(COL_BG)
    
    for coord in coords:
        drawcube(surface, coord)

    for i in range(len(coords)-1):
        drawline(surface, coords[i], coords[i+1])

    if text:
        out = font.render(text, True, COL_TEXT)
        surface.blit(out,[0,0])
        
    display.blit(surface, [0,0])
    pygame.display.flip()
    

DEBUG = 1
MAX_STORAGE_SIZE = 200000

rot = [{'000': '000',
        '+00': '+00',
        '0+0': '00+',
        '00+': '0-0',
        '-00': '-00',
        '0-0': '00-',
        '00-': '0+0'},
       {'000': '000',
        '+00': '00+',
        '0+0': '0+0',
        '00+': '-00',
        '-00': '00-',
        '0-0': '0-0',
        '00-': '+00'},

       {'000': '000',
        '+00': '0-0',
        '0+0': '+00',
        '00+': '00+',
        '-00': '0+0',
        '0-0': '-00',
        '00-': '00-'}]



#       {'000': '000',
#        '+00': '00+',
#        '0+0': '-00',
#        '00+': '00+',
#        '-00': '0-0',
#        '0-0': '+00',
#        '00-': '00-'}]

axes = ['000', #1
        '000', #2
#        '+00', #3
        '000', #3 # better
        '000', #4
        '0+0', #5
        '000', #6
        '+00', #7
        '000', #8
        '0+0', #9
        '+00', #10
        '0+0', #11
        '+00', #12
        '000', #13
        '0+0', #14
        '000', #15
        '+00', #16
        '0+0', #17
        '+00', #18
        '000', #19
        '0+0', #20
        '+00', #21
        '000', #22
        '0+0', #23
        '+00', #24
        '0+0', #25
        '000', #26
        '000', #27
        ]
        
trans = ['+00', #1
         '+00', #2
         '0+0', #3
         '0+0', #4
         '-00', #5
         '-00', #6
         '0+0', #7
         '0+0', #8
         '+00', #9
         '0+0', #10
         '+00', #11
         '0+0', #12
         '0+0', #13
         '-00', #14
         '-00', #15
         '0+0', #16
         '+00', #17
         '0+0', #18
         '0+0', #19
         '+00', #20
         '0+0', #21
         '0+0', #22
         '-00', #23
         '0+0', #24
         '+00', #25
         '+00', #26
         '+00', #27
         ]
        
def unfold(trans):

    space = []
    x = y = z = 1
    space.append([x,y,z])
    
    for i in trans:
        dx = dy = dz = 0
        if   i == '+00':
            dx = +1
        elif i == '-00':
            dx = -1
        elif i == '0+0':
            dy = +1
        elif i == '0-0':
            dy = -1
        elif i == '00+':
            dz = +1
        elif i == '00-':
            dz = -1
        x += dx
        y += dy
        z += dz
        
        try :
            dummy = space.index([x,y,z])
            return None # Impossible folding
        except ValueError:
            space.append([x,y,z])

    return space[:-1]


def rotate(axes, trans, number):
    
    axis = axes[number] # e.g. 0+0
    
    if axis == '000':
        return axes, trans
    
    if axis == '+00' or axis == '-00':
        aind = 0
    elif axis == '0+0' or axis == '0-0':
        aind = 1
    elif axis == '00+' or axis == '00-':
        aind = 2
        
    naxes = copy.copy(axes)
    ntrans = copy.copy(trans)
    
    end = len(axes)
    for i in range(number, end):
        naxes[i] = rot[aind][naxes[i]]
        ntrans[i] = rot[aind][ntrans[i]]
        
    return naxes, ntrans


def hashstring(space):
    strhash = ""
    for coords in space:
       for coord in coords:
           strhash += "%02d/" % coord
    return strhash
    

def estimate(space):
    
    estimation = 0
    
    xx = []
    yy = []
    zz = []
    
    for coords in space:
        x,y,z = coords
        xx.append(x)
        yy.append(y)
        zz.append(z)
        
    minx = min(xx)
    maxx = max(xx)
    distx = 1+abs(maxx-minx)
    miny = min(yy)
    maxy = max(yy)
    disty = 1+abs(maxy-miny)    
    minz = min(zz)
    maxz = max(zz)
    distz = 1+abs(maxz-minz)

    estimation = distx*disty*distz - 3**3
    #estimation += distx+disty+distz - 3*3
    return estimation

storage = []
heapq.heapify(storage)
mem = {}

cube = unfold(trans)
estimation = estimate(cube)
hashstr = hashstring(cube)

heapq.heappush(storage, [estimation, cube, axes, trans, hashstr])
mem[hashstr] = True

def recurse(storage, mem):
    
    estimation, cube, axes, trans, hashstr = heapq.heappop(storage)
    
    out = ""
    blah = copy.copy(axes)
    blah.reverse()
    for ax in blah:
        out += ax + '/'
    surf = writeline(textsurf, "%d/%d:%s" % (estimation, len(storage), out))#, cube, axes, trans, hashstr))
    drawcubes(cube, '', surf, False)
    
    
    if estimation == 0:
        #print axes, trans
        heapq.heappush(storage, [estimation, cube, axes, trans, hashstr])
        return -1
        
    for i in range(len(axes)-1,-1,-1):
        naxes, ntrans = rotate(axes, trans, i)
        
        if naxes == axes and ntrans == trans:
#            print "no change"
            continue
        
        ncube = unfold(ntrans)
        if not ncube:
#            print "no valid cube"
            continue
        nhashstr = hashstring(ncube)
        try:
            dummy = mem[nhashstr]
        except KeyError:
            estimation = estimate(ncube)
            heapq.heappush(storage, [estimation, ncube, naxes, ntrans, nhashstr])
            mem[nhashstr] = True

    return len(storage)


lines = []
#maxlines = 40
def writeline(surface, line):
    global lines
    lines.append(line)
    if len(lines) > maxlines:
        lines = lines[-maxlines:]
    surface.fill(COL_BG)
    
    y = SCREENREC[1]
    for line in lines:
        out = font.render(line, True, COL_TEXT)
        surface.blit(out,[0,y])
        y -= fontsize
    
    return surface
    
    
storagesize = 1
while storagesize:

    storagesize = recurse(storage, mem)

    for e in pygame.event.get():
        if e.type in (pygame.QUIT, pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN, ):
            sys.exit(0)
                
    if storagesize > MAX_STORAGE_SIZE:
        if DEBUG > 0:
            print "dropping states"
            print "before:", min(storage)[0], max(storage)[0]        
        nstorage = []
        heapq.heapify(nstorage)
        for i in range(storagesize/2):
            element = heapq.heappop(storage)
            heapq.heappush(nstorage, element)

        if DEBUG > 1:
            for i in range(storagesize/2):
                estimation, cube, axes, trans, hashstr = heapq.heappop(storage)
                drawcubes(cube, 'PURGING!', display)

        del storage
        storage = nstorage
        if DEBUG > 0:
            print "after", min(storage)[0], max(storage)[0]
    elif storagesize < 0:
        break
        
estimation, cube, axes, trans, hashstr = heapq.heappop(storage)
drawcubes(cube, '', display)

while 1:
    for e in pygame.event.get():
        if e.type in (pygame.QUIT, pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
            sys.exit(0)
