#!/usr/bin/python

"""

Assured Destruction

A turn based strategy game.

Somewhat incomplete unfortunately.  No AI is the biggest lack, so it's 2 player hot seat only.

If you can't seem to do anything, wait a few turns until you have more cash.



Erik Johnson
http://disruption.ca
Written for the summer 2006 pygame.draw challenge.


If you would like a license to do something with this code, Send me an email.
The contact info is on my web page.


"""


debug = True

import pygame
import math
import random

from pygame.locals import *


ipshell = None
if debug:
    try:
        from IPython.Shell import IPShellEmbed
        ipshell = IPShellEmbed() 
    except:
        pass

def init(w=800,h=600):
    pygame.init()
    pygame.display.set_mode((w,h),0,32)


def fillIn(rect, terrain, heightRange, variance,dilution):
    if rect[2] <= 1:
        return
    else:
    
        c1 = terrain[rect[0]][rect[1]]
        c2 = terrain[rect[0]+rect[2]][rect[1]]
        c3 = terrain[rect[0]+rect[2]][rect[1]+rect[3]]
        c4 = terrain[rect[0]][rect[1]+rect[3]]
        
        leftEdge = (c1 + c4) /2 + random.random() * variance - variance/2.0
        if terrain[rect[0]][rect[1]+rect[3]/2] == -1:
            terrain[rect[0]][rect[1]+rect[3]/2] = leftEdge
        
        rightEdge = (c2 + c3) /2 + random.random() * variance - variance/2.0
        if terrain[rect[0]+rect[2]][rect[1]+rect[3]/2] == -1:
            terrain[rect[0]+rect[2]][rect[1]+rect[3]/2] = rightEdge
        
        topEdge = (c1 + c2) / 2 + random.random() * variance - variance/2.0
        if terrain[rect[0]+rect[2]/2][rect[1]] == -1:
            terrain[rect[0]+rect[2]/2][rect[1]] = topEdge
        
        bottomEdge = (c3 + c4) / 2 + random.random() * variance - variance/2.0
        if terrain[rect[0]+rect[2]/2][rect[1]+rect[3]] == -1:
            terrain[rect[0]+rect[2]/2][rect[1]+rect[3]] = bottomEdge
        
        midpoint = (leftEdge + rightEdge) /2 + random.random() * variance - variance/2.0
        if terrain[rect[0] + rect[2]/2][rect[1] + rect[3]/2] == -1:
            terrain[rect[0] + rect[2]/2][rect[1] + rect[3]/2] = midpoint
        
        newVar = variance * dilution
        
        if rect[2] % 2 != 0:
            for i in range(2):
                for j in range(2):
                    if terrain[rect[0] + rect[2]/2+i][rect[1] + rect[3]/2+j] == -1:
                        terrain[rect[0] + rect[2]/2+i][rect[1] + rect[3]/2+j] = midpoint
            if terrain[rect[0]][rect[1]+rect[3]/2+1] == -1:
                terrain[rect[0]][rect[1]+rect[3]/2+1] = leftEdge
            if terrain[rect[0]+rect[2]][rect[1]+rect[3]/2+1] == -1:
                terrain[rect[0]+rect[2]][rect[1]+rect[3]/2+1] = rightEdge
            if terrain[rect[0]+rect[2]/2+1][rect[1]] == -1:
                terrain[rect[0]+rect[2]/2+1][rect[1]] = topEdge
            if terrain[rect[0]+rect[2]/2+1][rect[1]+rect[3]] == -1:
                terrain[rect[0]+rect[2]/2+1][rect[1]+rect[3]] = bottomEdge

            fillIn((rect[0]           ,rect[1]            ,rect[2]/2, rect[3]/2),terrain,heightRange,newVar,dilution)
            fillIn((rect[0]+rect[2]/2+1 ,rect[1]            ,rect[2]/2,rect[3]/2),terrain,heightRange,newVar,dilution)
            fillIn((rect[0]+rect[2]/2+1 ,rect[1]+rect[3]/2 +1,rect[2]/2,rect[3]/2),terrain,heightRange,newVar,dilution)
            fillIn((rect[0]           ,rect[1]+rect[3]/2 +1,rect[2]/2,rect[3]/2),terrain,heightRange,newVar,dilution)
            
        else:
            fillIn((rect[0]           ,rect[1]            ,rect[2]/2, rect[3]/2),terrain,heightRange,newVar,dilution)
            fillIn((rect[0]+rect[2]/2 ,rect[1]            ,rect[2]/2,rect[3]/2),terrain,heightRange,newVar,dilution)
            fillIn((rect[0]+rect[2]/2 ,rect[1]+rect[3]/2 ,rect[2]/2,rect[3]/2),terrain,heightRange,newVar,dilution)
            fillIn((rect[0]           ,rect[1]+rect[3]/2 ,rect[2]/2,rect[3]/2),terrain,heightRange,newVar,dilution)
        
        


def genTerrain(w,h,seedList=None):
    heightRange = 255
    variance = 12
    dilution = 0.90

    terrain = []
    for i in range(w):
        terrain.append([])
    for a in terrain:
        for i in range(h):
            a.append(-1)
    

    terrain[0][0] = random.randrange(heightRange)
    terrain[w-1][0] = random.randrange(heightRange)
    terrain[w-1][h-1] = random.randrange(heightRange)
    terrain[0][h-1] = random.randrange(heightRange)
        
    if seedList:    
        for seed in seedList:
            for i in range(2):
                for j in range(2):
                    if seed[0]+i < w and seed[1]+j < h:
                        terrain[seed[0]+i][seed[1]+j] = seed[2]
    
    fillIn((0,0, w-1,h-1), terrain, heightRange, variance,dilution)
    
    return terrain

def subset(x,y,matrix):
    newMatrix = []
    diffX = len(matrix) - x
    diffY = len(matrix[0]) - y
    for i in range(x):
        newMatrix.append([])
    for i in range(x):
        for j in range(y):
            newMatrix[i].append(matrix[i+diffX/2][j+diffY/2])
    
    return newMatrix


def getIslandList(w,h):
    water = 65 # %
    land = 20
    mountain = 15
    detail = 8
    list = [(0,0,0),(0,w-1,0),(w-1,h-1,0),(w-1,0,0)]
    
    for i in range(1,detail-1):
        for j in range(1,detail-1):
            height = 0
            randnum = random.randrange(100)
            if randnum < water:
                height = random.randrange(60)
            elif randnum < water + land:
                height = random.randrange(120) + 60
            else:
                height = random.randrange(70) + 180
            list.append(((w/detail)*i-1, (h/detail)*j-1, height))
         
    
    return list


def makeCrater(terrain,crater,x,y,radius,players):
    blastVariance = 8
    water = False
    
    edgeSize = 8 # %
    edgeProb = 70 # %
    
    blastHeight = terrain[x][y]
    if blastHeight < landKey[landTypes['shallow']][0] - 5:
        blastHeight = landKey[landTypes['shallow']][0] - 5
        
    for p in players:        
        for silo in p.silos:
            dist = ((x-silo.location[0])**2 + (y-silo.location[1])**2)**0.5
            if dist < radius:
                silo.dead = True
                if silo.status == 'full':
                    p.weapons -= 1
                    
        p.silos = filter(lambda x: not x.dead, p.silos)
    
    for i in range(radius*2):
        for j in range(radius*2):
            dist = ((i-radius)**2 + (j-radius)**2)**0.5
            if dist < radius and (x-radius)+i > 0 and (x-radius)+i < len(terrain) and y-radius+j >= 0 and y-radius+j < len(terrain[0]):
                if dist > radius - radius * edgeSize/100.0 and random.random() > edgeProb/100.0:
                    continue
                    
                for player in players:
                    if player.city[(x-radius)+i][(y-radius)+j] != -1:
                        player.population -= player.city[(x-radius)+i][(y-radius)+j] * 100
                        player.cellCount -= 1
                        player.city[(x-radius)+i][(y-radius)+j] = -1
                        player.surf.fill((0,0,0),(((x-radius)+i)*2,((y-radius)+j)*2,2,2))
                    
                blastForce = (radius - dist) * 2
                if terrain[(x-radius)+i][(y-radius)+j] > landKey[landTypes['shallow']][0] and crater[(x-radius)+i][(y-radius)+j] == -1:
                    crater[(x-radius)+i][(y-radius)+j] = -2
                if terrain[(x-radius)+i][(y-radius)+j] > blastHeight - blastForce:
                    """if terrain[(x-radius)+i][(y-radius)+j] > blastHeight + blastForce:
                        terrain[(x-radius)+i][(y-radius)+j] -= (blastForce + random.random()*blastVariance - blastVariance/2)*3
                    else:"""
                    terrain[(x-radius)+i][(y-radius)+j] = blastHeight - blastForce + random.random()*blastVariance - blastVariance/2
                    if terrain[(x-radius)+i][(y-radius)+j] > landKey[landTypes['shallow']][0]:
                        crater[(x-radius)+i][(y-radius)+j] = blastForce/radius * 255 #terrain[(x-radius)+i][(y-radius)+j]
                    else:
                        crater[(x-radius)+i][(y-radius)+j] = -1
                #terrain[(x-radius)+i][(y-radius)+j] -= (radius - dist) * 2
    return terrain

def renderCities(display,players):
    for player in players:
        display.blit(player.surf, (0,0))


def renderTerrain(terrain,crater,display,subRect=None):
    if not subRect:
        xstart = 0
        ystart = 0
        xend = len(terrain)
        yend = len(terrain[0])
    else:
        xstart, ystart, xend, yend = subRect
        xend += xstart
        yend += ystart
        if xstart < 0:
            xstart = 0
        if ystart < 0:
            ystart = 0
        if xend > len(terrain):
            xend = len(terrain)
        if yend > len(terrain[0]):
            yend = len(terrain[0])

    for i in range(xstart,xend):
        for j in range (ystart,yend):
            if terrain[i][j] > 255:
                terrain[i][j] = 255
            elif terrain[i][j] < 0:
                terrain[i][j] = 0

            color = landKey[0][1]
            for k in range(len(landKey)):
                if terrain[i][j] >= landKey[k][0]:
                    color = landKey[k+1][1]

                
            if crater[i][j] != -1:
                if crater[i][j] == -2:
                    color = (color[0] * .6, color[1] * .3, color[2] * .4)
                    #color = (30,30,0)
                else:
                    bright = crater[i][j]/255.0 * 40
                    
                    if bright < 0:
                        bright = 0
                    color = (bright,bright,bright)
            """else:
                color = landKey[0][1]
                for k in range(len(landKey)):
                    if terrain[i][j] >= landKey[k][0]:
                        color = landKey[k+1][1]"""
              
            display.fill(color,(i*2,j*2,2,2))


def habitable(x,y,terrain,crater,players):
    if x < 0 or y < 0 or x >= len(terrain) or y >= len(terrain[0]):
        return False
    elif crater[x][y] != -1:
        return False
    elif terrain[x][y] <= landKey[landTypes['shallow']][0]:
        return False
    elif terrain[x][y] > landKey[landTypes['forest']][0]:
        return False
    else:
        for player in players:
            if player.city[x][y] != -1:
                return False
                
    return True


def infectPoint(x,y,terrain,crater,players):
    """if x < 0 or y < 0 or x >= len(terrain) or y >= len(terrain[0]):
        return False
    elif crater[x][y] != -1:
        return False
    elif terrain[x][y] <= landKey[landTypes['shallow']][0]:
        return False
    elif terrain[x][y] > landKey[landTypes['forest']][0]:
        return False
    else:
        for player in players:
            if player.city[x][y] != -1:
                return False"""
                
    if habitable(x,y,terrain,crater,players):
        prob = 0
        
        for i in range(x-1,x+2):
            for j in range(y-1,y+2):
                if not (i==x and j==y):
                    try:
                        if crater[i][j] != -1:
                            prob -= 12
                        elif terrain[i][j] < landKey[landTypes['shallow']][0]:
                            prob += 10
                        elif terrain[i][j] <= landKey[landTypes['sand']][0]:
                            prob += 1
                        elif terrain[i][j] <= landKey[landTypes['plain']][0]:
                            prob += 2
                        elif terrain[i][j] <= landKey[landTypes['forest']][0]:
                            prob += 1
                    except:
                        pass
        
        if prob/100.0 > random.random():
            return True
        else:
            return False
    else:
        return False

def genWealth(terrain,crater,players):
    return 10


def growCities(terrain,crater,players):
    
    newlist = []
    for i in range(len(terrain)):
        for j in range(len(terrain[0])):
            for player in players:
                if player.city[i][j] != -1:
                    # grow
                    if player.city[i][j] < 10 and random.random() < 0.1:
                        player.city[i][j] += 1
                        player.population += 100
                        color = (player.baseColor[0],player.baseColor[1]+100*((terrain[i][j]-landKey[landTypes['shallow']][0])/(1.0*landKey[landTypes['rocks']][0]-landKey[landTypes['shallow']][0])),player.baseColor[2]-10*player.city[i][j])
                        #color = (player.baseColor[0],player.baseColor[1],player.baseColor[2]+10*player.city[i][j])
                        player.surf.fill(color,(i*2,j*2,2,2))
    
                    # generate wealth
                    player.cash += genWealth(terrain,crater,players)
                    
                    # try to infect surrounding
                    for x in range(i-1,i+2):
                        for y in range(j-1,j+2):
                            if infectPoint(x,y,terrain,crater,players):
                                newlist.append((player,x,y))
                        
    for p in newlist:
        if p[0].city[p[1]][p[2]] == -1:
            p[0].city[p[1]][p[2]] = 1
            color = (p[0].baseColor[0],p[0].baseColor[1]+100*((terrain[p[1]][p[2]]-landKey[landTypes['shallow']][0])/(1.0*landKey[landTypes['rocks']][0]-landKey[landTypes['shallow']][0])),p[0].baseColor[2]-10*p[0].city[p[1]][p[2]])
            #color = (player.baseColor[0],player.baseColor[1],player.baseColor[2]+10*p[0].city[p[1]][p[2]])
            p[0].surf.fill(color,(p[1]*2,p[2]*2,2,2))
            p[0].population += 100
            p[0].cellCount += 1


class HUD:
    def __init__(self,(w,h), display,players,state):
        self.buttons = []
        self.baseSize = 16
        self.baseColor = (255,255,255)
        self.state = state
    
        self.w = h*4/3-h
        self.h = h
        self.display = display
        self.surface = pygame.Surface((self.w,self.h),0,display)
        self.players = players
        #self.update()
        
        strings = (((0,0),48,self.baseColor,"Assured"),
                    ((0,30),48,self.baseColor,"Destruction"),
                    ((2,90),self.baseSize, self.baseColor, "Player 1"),
                    ((5,110),self.baseSize, self.baseColor, "Population:"),
                    ((5,130),self.baseSize, self.baseColor, "Area:"),
                    ((5,150),self.baseSize, self.baseColor, "Cash:"),
                    ((5,170),self.baseSize, self.baseColor, "Weapons:"),
                    ((2,200),self.baseSize, self.baseColor, "Player 2"),
                    ((5,220),self.baseSize, self.baseColor, "Population:"),
                    ((5,240),self.baseSize, self.baseColor, "Area:"),
                    ((5,260),self.baseSize, self.baseColor, "Cash:"),
                    ((5,280),self.baseSize, self.baseColor, "Weapons:"),
                    )

        for string in strings:       
            fontObj = pygame.font.Font(None, string[1])
            image = fontObj.render(string[3], True, string[2])
            self.surface.blit(image,string[0])
            
        #self.display.blit(self.surface, (self.h,0))
        self.update(state)

     
    def update(self,state):
        self.state = state
    
        strings = (((190,110), self.baseSize, self.baseColor, "%i" % self.players[0].population),
                    ((190,130), self.baseSize, self.baseColor, "%i" % self.players[0].cellCount),
                    ((190,150), self.baseSize, self.baseColor, "%i" % self.players[0].cash),
                    ((190,170), self.baseSize, self.baseColor, "%i" % (self.players[0].weapons+self.players[0].newWeapons)),
                    ((190,220), self.baseSize, self.baseColor, "%i" % self.players[1].population),
                    ((190,240), self.baseSize, self.baseColor, "%i" % self.players[1].cellCount),
                    ((190,260), self.baseSize, self.baseColor, "%i" % self.players[1].cash),
                    ((190,280), self.baseSize, self.baseColor, "%i" % (self.players[1].weapons+self.players[1].newWeapons)),
        )

        self.surface.fill((0,0,0),(100,110,90,340))
        for string in strings:       
            fontObj = pygame.font.Font(None, string[1])
            image = fontObj.render(string[3], True, string[2],(0,0,0))
            w,h = image.get_size()
            #self.surface.fill((0,0,0),(string[0][0]-w-10,string[0][1],w,h))
            self.surface.blit(image,(string[0][0]-w,string[0][1]))
    
        self.display.blit(self.surface, (self.h,0))
        
        self.updateMessage()


    def updateMessage(self):
        self.buttons = []
        
        if self.state[0] != 'gameOver':
            self.buttons.append(Button((610,310),display,"Player %i" %(state[1]+1),'None',bgColor=self.players[state[1]].baseColor))
        
        if self.state[0] == 'start':
            fontObj = pygame.font.Font(None, 30)
            image2 = fontObj.render("Place your city", True, (255,255,255),(0,0,0))
            self.display.blit(image2,(605,350))
        elif self.state[0] == 'chooseAction':
            self.buttons.append(Button((610,600-40),display,"End Turn",'done'))
            
            blist = []
            player = players[self.state[1]]

            if player.cash >= weaponCost and player.weapons+player.newWeapons < len(player.silos):
                blist.append(("Buy Weapon",'buyWeapon'))
            if player.cash >= colonyBaseCost * 1.2:
                blist.append(("Buy Colony", 'buyColony'))
            if player.cash >= siloBaseCost * 1.05:
                blist.append(("Buy Silo", 'buySilo'))                
            if player.weapons > 0:
                blist.append(("Launch Weapon", 'launch'))
                
                
            sx, sy = 610, 400
            step = 10
            for bspec in blist:
                self.buttons.append(Button((sx,sy),display,bspec[0],bspec[1]))
                sy += step + self.buttons[0].h
            
            
            fontObj = pygame.font.Font(None, 30)
            image2 = fontObj.render("Actions:", True, (255,255,255),(0,0,0))
            self.display.blit(image2,(605,350))
            
        elif self.state[0] == 'confirmWeapon':
            self.buttons.append(Button((610,600-40),display,"Cancel",'cancel'))
            self.buttons.append(Button((610,400),display,"OK",'confirm'))

            fontObj = pygame.font.Font(None, 30)
            image2 = fontObj.render("Cost: %i"%weaponCost, True, (255,255,255),(0,0,0))
            self.display.blit(image2,(605,350))
            
        elif self.state[0] == 'buyColony':
            self.buttons.append(Button((610,600-40),display,"Cancel",'cancel'))

            fontObj = pygame.font.Font(None, 30)
            image2 = fontObj.render("Cost:", True, (255,255,255),(0,0,0))
            self.display.blit(image2,(605,350))


        elif self.state[0] == 'buySilo':
            self.buttons.append(Button((610,600-40),display,"Cancel",'cancel'))

            fontObj = pygame.font.Font(None, 30)
            image2 = fontObj.render("Cost:", True, (255,255,255),(0,0,0))
            self.display.blit(image2,(605,350))

            

        elif self.state[0] == 'pickTarget':
            self.buttons.append(Button((610,600-40),display,"Cancel",'cancel'))

            fontObj = pygame.font.Font(None, 30)
            image2 = fontObj.render("Pick Your Target", True, (255,255,255),(0,0,0))
            self.display.blit(image2,(605,350))
            
        elif self.state[0] == 'gameOver':
            self.buttons.append(Button((610,600-40),display,"Quit",'quit'))
            self.buttons.append(Button((610,400),display,"New Game",'new'))

            fontObj = pygame.font.Font(None, 30)
            image1 = fontObj.render("Game Over", True, (255,255,255),(0,0,0))
            if self.state[1] != None:
                image2 = fontObj.render("Player %i Wins"%(self.state[1]+1), True, (255,255,255),(0,0,0))
            else:
                image2 = fontObj.render("No One Wins", True, (255,255,255),(0,0,0))
            self.display.blit(image1,(605,310))
            self.display.blit(image2,(605,350))

        for button in self.buttons:
            display.blit(button.surf,button.pos)




class Button:
    def __init__(self,pos,display,text,retVal,bgColor=(20,20,160),textColor=(255,255,255)):
        self.w = 180
        self.h = 30
        self.pos = pos
        self.retVal = retVal
        self.surf = pygame.Surface((self.w,self.h),0,display)
        self.surf.fill(bgColor,(0,0,self.w,self.h))
        fontObj = pygame.font.Font(None, 24)
        textImage = fontObj.render(text, True, textColor,bgColor)
        tw,th = textImage.get_size()
        self.surf.blit(textImage,(self.w/2-tw/2, self.h/2-th/2))
        
    
    def checkHit(self,x,y):
        if x >= self.pos[0] and x <= self.pos[0] + self.w and y >= self.pos[1] and y <= self.pos[1] + self.h:
            return self.retVal
        else:
            return False


class Player:
    def __init__(self,display,terrain,baseColor):
        self.surf = pygame.Surface((len(terrain)*2,len(terrain[0])*2),0,display)
        self.surf.set_colorkey((0,0,0))
        
        self.siloImage = pygame.Surface((8,8),0,display)
        self.siloImage.fill((255,255,255),(0,0,8,8))
        pygame.draw.line(self.siloImage,baseColor,(0,0),(7,7),3)
        pygame.draw.line(self.siloImage,baseColor,(0,7),(7,0),3)
        
        self.city = []
        for i in range(tx):
            self.city.append([])
        for a in self.city:
            for i in range(len(terrain)):
                a.append(-1)
                
        self.population = 0
        self.cellCount = 0
        self.cash = 2000
        self.weapons = 0
        self.newWeapons = 0
        self.baseColor = baseColor
        self.cityList = []
        self.silos = []
        self.display = display
        
    def drawSilos(self):
        for silo in self.silos:
            self.display.blit(self.siloImage, ((silo.location[0])*2-4,(silo.location[1])*2-4))
        
class Silo:
    def __init__(self, location):
        self.location = location
        self.status = 'empty'
        self.dead = False


w = 800
h = 600

landTypes = {'sea':0,'shallow':1,'sand':2,'plain':3,'forest':4,'rocks':5,'snow':6}
landKey = ((35,(0,0,90)),
            (60,(0,0,200)),
            (80,(200,200,100)),
            (120,(40,200,40)),
            (180,(10,100,10)),
            (200,(100,100,100)),
            (256,(210,210,210)))

sx,sy= 304,304  # weird voodoo shit
tx,ty = 300,300

terrainList = getIslandList(sx,sy)

terrain = genTerrain(sx,sy,terrainList)
terrain = subset(ty,tx,terrain)

init(w,h)
display = pygame.display.get_surface()
#citySurf = pygame.Surface((w,h),0,display)
#citySurf.set_colorkey((0,0,0))
#CitySurf = surf.convert_alpha()


siloBaseCost = 5000
siloMaxCost = 15000
weaponCost = 30000
colonyBaseCost = 5000
colonyMaxCost = 15000


numPlayers = 2
baseColors = ((255,20,100),(100,100,200))
players = []


for i in range(numPlayers):
    players.append(Player(display,terrain,baseColors[i]))


crater = []
for i in range(tx):
    crater.append([])
for a in crater:
    for i in range(ty):
        a.append(-1)

renderTerrain(terrain,crater,display)

state = ['start', 0]

hud = HUD((w,h),display, players,state)

hud.update(state)

# Display instructions

costFont = pygame.font.Font(None, 30)
cost = 0
costW,costH = 0,0


def getDist(x,y,player):
    closestDist = 300
    for city in player.cityList:
        dist =  ( (x-city[0])**2 + (y-city[1])**2 ) ** 0.5
        if dist < closestDist:
            closestDist = dist
            
    return closestDist
    

done = False
while not done:

    if state[0] == 'buyColony':
        x,y = pygame.mouse.get_pos()
        dist = getDist(x/2,y/2,players[state[1]])
        newCost = int(colonyBaseCost + (dist/300.0 *  colonyMaxCost))
        if cost != newCost:
            cost = newCost
            if cost <= players[state[1]].cash:
                color = (255,255,255)
            else:
                color = (255,100,100)
            costImage = costFont.render("%i"%cost, True, color,(0,0,0))
            if costW != 0:
                display.fill((0,0,0),(790-costW,350,costW,costH))
            costW,costH = costImage.get_size()            
            display.blit(costImage,(790-costW,350))
    elif state[0] == 'buySilo':
        x,y = pygame.mouse.get_pos()
        dist = getDist(x/2,y/2,players[state[1]])
        newCost = int(siloBaseCost + (dist/300.0 *  siloMaxCost))
        if cost != newCost:
            cost = newCost
            if cost <= players[state[1]].cash:
                color = (255,255,255)
            else:
                color = (255,100,100)
            costImage = costFont.render("%i"%cost, True, color,(0,0,0))
            if costW != 0:
                display.fill((0,0,0),(790-costW,350,costW,costH))
            costW,costH = costImage.get_size()            
            display.blit(costImage,(790-costW,350))
            

    pygame.display.flip()
    
    eventlist = pygame.event.get()
    for event in eventlist:
        if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
            done = True
        elif event.type == KEYDOWN and event.key == K_BACKQUOTE:
            if ipshell:
                ipshell()
                #engine.clock.tick()
        elif event.type == KEYDOWN and event.key == K_c:
            for i in range(len(crater)):
                for j in range(len(crater[0])):
                    crater[i][j] = -1
            renderTerrain(terrain,crater,display)
            renderCities(display, players)
            
        #elif event.type == KEYDOWN and event.key == K_e:
            #players[0].cash = 100000
            #players[1].cash = 100000
        #    growCities(terrain,crater,players)
        #    renderCities(display, players) 
        #    hud.update()
            
        elif event.type == MOUSEBUTTONDOWN:
            x,y = event.pos
            if event.button == 1:
                if state[0] == 'start':
                    if habitable(x/2,y/2,terrain,crater, players):
                        players[state[1]].city[x/2][y/2] = 1
                        color = baseColors[state[1]]
                        players[state[1]].surf.fill(color,((x/2)*2,(y/2)*2,2,2))
                        players[state[1]].population += 100
                        players[state[1]].cellCount += 1
                        players[state[1]].cityList.append((x/2,y/2))

                        if state[1] == len(players) - 1:
                            for i in range(10):
                                growCities(terrain,crater,players)
                            state = ['chooseAction',0]
                        else:
                            state[1] += 1
                        renderCities(display, players) 
                        hud.update(state)
                elif state[0] == 'chooseAction':
                    for button in hud.buttons:
                        action = button.checkHit(x,y)
                        if action == 'done':
                            if state[1] == len(players) - 1:
                                growCities(terrain,crater,players)
                                renderCities(display, players)
                                state = ['chooseAction',0]
                            else:
                                state[1] += 1
                                
                            for player in players:
                                if player.newWeapons != 0:
                                    player.weapons += player.newWeapons
                                    player.newWeapons = 0

                            if players[0].population == 0 and players[1].population == 0:
                                state = ['gameOver', None]
                            elif players[0].population == 0:
                                state = ['gameOver', 1]
                            elif players[1].population == 0:
                                state = ['gameOver', 0]
                            elif players[0].cellCount * 0.05 > players[1].cellCount:
                                state = ['gameOver', 0]
                            elif players[1].cellCount * 0.05 > players[0].cellCount:
                                state = ['gameOver', 1]

                                
                            for player in players:
                                player.drawSilos()
                                
                            hud.update(state)
                            hud.updateMessage()
                        elif action == 'buyWeapon':
                            state[0] = 'confirmWeapon'
                            hud.update(state)
                        elif action == 'buyColony':
                            state[0] = 'buyColony'
                            hud.update(state)
                        elif action == 'buySilo':
                            state[0] = 'buySilo'
                            hud.update(state)

                        elif action == 'launch':
                            state[0] = 'pickTarget'
                            hud.update(state)
                elif state[0] == 'confirmWeapon':
                    for button in hud.buttons:
                        action = button.checkHit(x,y)
                        if action == 'confirm':
                        
                            emptySilos = filter(lambda x: x.status == 'empty', players[state[1]].silos)
                            
                            silo = random.choice(emptySilos)
                            
                            silo.status = 'full'
                        
                            players[state[1]].cash -= weaponCost
                            players[state[1]].newWeapons += 1
                            state[0] = 'chooseAction'
                            hud.update(state)
                        elif action == 'cancel':
                            state[0] = 'chooseAction'
                            hud.update(state)
                elif state[0] == 'pickTarget':
                    for button in hud.buttons:
                        action = button.checkHit(x,y)
                        if action == 'cancel':
                            state[0] = 'chooseAction'
                            hud.update(state)
                    
                    if x/2 < 300 and y/2 < 300:
                        fullSilos = filter(lambda x: x.status == 'full', players[state[1]].silos)
                        silo = random.choice(fullSilos)
                        silo.status = 'empty'
                        players[state[1]].weapons -= 1
                        
                        yeild = 16 + random.randrange(-3,3)
                        terrain = makeCrater(terrain, crater, x/2,y/2 , yeild, players)
                        renderTerrain(terrain, crater,display, (x/2-yeild,y/2-yeild, yeild*2, yeild*2) )
                        renderCities(display, players)
                        for player in players:
                                player.drawSilos()
                        state[0] = 'chooseAction'
                        hud.update(state)
                        
                        
                elif state[0] == 'buyColony':
                    if habitable(x/2,y/2,terrain,crater, players):
                        dist = getDist(x/2,y/2,players[state[1]])
                        buyCost = int(colonyBaseCost + (dist/300.0 *  colonyMaxCost))
                        
                        if buyCost <= players[state[1]].cash:
                            players[state[1]].city[x/2][y/2] = 1
                            color = baseColors[state[1]]
                            players[state[1]].surf.fill(color,((x/2)*2,(y/2)*2,2,2))
                            players[state[1]].population += 100
                            players[state[1]].cellCount += 1
                            players[state[1]].cityList.append((x/2,y/2))
                            
                            players[state[1]].cash -= buyCost
                            
                            state[0] = 'chooseAction'
                            renderCities(display, players)
                            hud.update(state)
                    else:
                        for button in hud.buttons:
                            action = button.checkHit(x,y)
                            if action == 'cancel':
                                state[0] = 'chooseAction'
                                hud.update(state)



                elif state[0] == 'buySilo':
                    if x < 600 and (habitable(x/2,y/2,terrain,crater, players) or players[state[1]].city[x/2][y/2] != -1):
                        dist = getDist(x/2,y/2,players[state[1]])
                        buyCost = int(siloBaseCost + (dist/300.0 *  siloMaxCost))
                        
                        if buyCost <= players[state[1]].cash:
                            players[state[1]].silos.append(Silo((x/2,y/2)))
                            players[state[1]].cash -= buyCost
                            
                            state[0] = 'chooseAction'
                            renderCities(display, players)
                            hud.update(state)
                            
                            for player in players:
                                player.drawSilos()
                    else:
                        for button in hud.buttons:
                            action = button.checkHit(x,y)
                            if action == 'cancel':
                                state[0] = 'chooseAction'
                                hud.update(state)


                        
                elif state[0] == 'gameOver':
                    for button in hud.buttons:
                        action = button.checkHit(x,y)                    
                        if action == 'quit':
                            done = True
                        elif action == 'new':
                            terrainList = getIslandList(sx,sy)                            
                            terrain = genTerrain(sx,sy,terrainList)
                            terrain = subset(ty,tx,terrain)

                            players = []
                            for i in range(numPlayers):
                                players.append(Player(display,terrain,baseColors[i]))
                            
                            crater = []
                            for i in range(tx):
                                crater.append([])
                            for a in crater:
                                for i in range(ty):
                                    a.append(-1)
                            
                            renderTerrain(terrain,crater,display)
                            
                            state = ['start', 0]
                            
                            hud = HUD((w,h),display, players,state)                            
                            hud.update(state)

                        
                else:     
                    """yeild = 16 + random.randrange(-3,3)
                    terrain = makeCrater(terrain, crater, x/2,y/2 , yeild, players)
                    renderTerrain(terrain, crater,display, (x/2-yeild,y/2-yeild, yeild*2, yeild*2) )
                    renderCities(display, players)
                    hud.update(state)"""
            #elif event.button == 2:
            #    players[1].city[x/2][y/2] = 1
            #    color = (0,255,255)
            #    players[1].surf.fill(color,((x/2)*2,(y/2)*2,2,2))
            #elif event.button == 3:
            #    players[0].city[x/2][y/2] = 1
            #    color = (0,255,255)
            #    players[0].surf.fill(color,((x/2)*2,(y/2)*2,2,2))"""

