#!/usr/bin/python

# Hazzard Sector
# Copyright (C) 2006  Kenny Backus  (nihilocrat a~t gmail d~o~t com)
# http://nil.cjb.net/code/
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# http://www.gnu.org/copyleft/gpl.html


gamestring = 'Hazzard Sector'
#gamestring = 'Asteroid Hootinany'  #old title

# Description:
# The Boss has framed you for another crime to cover up another one of his
# dastardly schemes, and the Space Cops are after you!
# Pilot 'The General Lee Mk 137' and navigate the asteroid belt for as
# long as possible. Their ships aren't as agile as yours: use this to
# your advantage and make them wreck into the asteroids!
#
# In case you aren't familiar with American popular culture, the backstory
# is a 'futuristic' version of the '80s TV show "The Dukes of Hazzard". You
# could probably also compare it to the asteroid chase scene in "The Empire
# Strikes Back". Hey, I figured it was more fun than just describing
# everything as "triangles flying around and dodging rocks"
#
# Controls:
# W - Thrust forward
# A - Turn left
# D - Turn right
# S - Retro thrusters (only 50% as much force as forward thrusters)
# Q - Thrust left (also only 50% force)
# E - Thrust right (also only 50% force)
#
# Scoring:
# You die if you hit an asteroid or a cop touches you, and you have three lives,
# just like the good old days!
#
# 1 pt for every second of play
# 20 pts for every cop destroyed
# New life at 500 pts


# NOTE : I'm a very lazy individual and the air conditioning has been out
#       for several days now (the apartment is practically an OVEN),
#       so this game is sort of buggy and VERY rough around the edges.
#       Occasionally, collisions will kill you more than once. Some other
#       completely random stuff might happen. The AI is sort of dumb because
#       I couldn't get the avoidance AI to work properly.
#       I hope you at least like the idea of the game, though. I think it's
#       an interesting departure from games revolving around shooting at stuff


# game settings
# if I were smart, I would put all of this into a dict or something
# but I'm lazy and want to save on typing
resolution = (800, 600)
fullscreen = False
desired_fps = 60
busy_loop = True
antialiasing = False
background_color = [0,0,0]

global_friction = 0.025

starting_cops = 1
player_lives = 3
score_per_second = 1
cop_kill_score = 20
new_life_score = 500

cop_min_spawn_distance = 400
cop_max_spawn_distance = 600
avoidance_distance = 50.0

arena_size = (1500, 1500)
asteroids_in_arena = 32

asteroid_max_size = 60.0
asteroid_min_size = 20.0
asteroid_edges = 10
asteroid_irregularity = 0.7
asteroid_jaggedness = 0.5
asteroid_line_width = 0

asteroid_spinspeed = 8.0
asteroid_drift = 20.0
asteroid_bounciness = 0.3

debug_mode = False

# Global variables! ack!
global G_origin



#saves bytes to glob instead of being namespace-clean
# dirty includes
from pygame import *
#from pygame import draw, display, time, font
from math import sin, cos, radians, degrees, atan2, hypot

# namespace-aware includes
import random


# cache a little math
half_resx = resolution[0] / 2
half_resy = resolution[1] / 2

half_arenax = arena_size[0] / 2
half_arenay = arena_size[1] / 2



# simple classes ###############################################
class Color:
	def __init__(_, r, g, b):
		_.r = r
		_.g = g
		_.b = b

	def __add__(_, other):
		return Color(_.r + other.r, _.g + other.g, _.b + other.b)

	def __sub__(_, other):
		return Color(_.r - other.r, _.g - other.g, _.b - other.b)

class Point:
	def __init__(_):
		_.x = 0
		_.y = 0

	def __init__(_, xy):
		_.x = xy[0]
		_.y = xy[1]

	def __add__(_, other):
		return Point([_.x + other.x, _.y + other.y])

	def __sub__(_, other):
		return Point([_.x - other.x, _.y - other.y])

	def __neg__(_):
                return Point([-_.x, -_.y])

        def __mul__(_, other):
                if isinstance(other, Point):
                    return Point([_.x * other.x, _.y * other.y])
                else:   # presume it's a scalar value
                    return Point([_.x * other, _.y * other])

        def angleto(_, obj2):
            '''Returns the angle from obj1 to obj2'''
            my_x = obj2.x - _.x
            my_y = obj2.y - _.y

            # dir = -(180.0/3.14159) * atan2(ship.x-x,ship.y-y)

            return degrees(atan2(my_x,my_y))

        def dist(_, obj2):
            #Returns distance from obj1 to obj2
            my_x = (_.x - obj2.x)
            my_y = (_.y - obj2.y)
    
            #return sqrt( (my_x * my_x) + (my_y * my_y) );
            return hypot(my_x,my_y)
        

def wrap(degrees):
	if(degrees >= 360.0):
		degrees -= 360.0
	if(degrees < 0.0):
		degrees += 359.0

	return degrees

# visual content classes     #########################################

class Mesh2D:
	def __init__(_):
		_.vertices = []
                _.original = _.vertices
                _.heading = 0
                _.pos = Point([0,0])
		_.color = [0,0,0]
		_.bbRect = Rect(0,0,0,0)
		_.fatness = 0 #filled polygons

	def loadvertices(_, vertexlist):
		for v in vertexlist:
                        _.add(v)

                _.original = _.vertices

	def add(_, newvert):
		if isinstance(newvert, Point):
			_.vertices.append([newvert.x, newvert.y])
		else:
			# assume it's a size-two tuple/list/whatever
			_.vertices.append(newvert)

		_.original = _.vertices


        def setpos(_, npos):
                oldpos = _.pos
                
                _.pos = npos

                # figure out where verts should be based on old pos

                for v in _.vertices:
                # get them centered on  (0,0)
                    v[0] -= oldpos.x
                    v[1] -= oldpos.y
                
                # now translate to the new position
                    v[0] += npos.x
                    v[1] += npos.y
                    
	def translate(_, offset):
		_.pos += offset
		for v in _.vertices:
			v[0] += offset.x
			v[1] += offset.y

	def rotate(_, rotamt):
                # HACK : silly stuff: translate it to 0,0 then translate it back
		_.heading = wrap(_.heading + rotamt)
            
		rad = radians(rotamt) #+ _.heading)
		for v in _.vertices:
			relx = v[0] - _.pos.x
			rely = v[1] - _.pos.y
			v[0] = (relx * cos(rad)) + (rely * sin(rad))
			v[1] = (-relx * sin(rad)) + (rely * cos(rad))
			v[0] += _.pos.x
			v[1] += _.pos.y

	def draw(_, myscreen, myorigin, mypos, myorient):
		# do some quick transforms to make it show up correctly
		drawverts = []
		for v in _.vertices:
                        # HACK : The first - sign was originally a +,
                        # I flipped it to make the origin work properly
                        # but mathematically I don't know why
			drawverts.append( [v[0] - myorigin[0] + half_resx,
					   half_resy + myorigin[1] - v[1]] )

                if antialiasing is True:
                    _.bbRect = draw.aalines(myscreen, _.color, True, drawverts, True)
                else:
                    _.bbRect = draw.polygon(myscreen, _.color, drawverts, _.fatness)

	def clear(_, myscreen):
		# just clear the bounding box rectangle we have in memory
		myscreen.fill(background_color, _.bbRect)


class PrintFont(font.Font):
	def __init__(_, fonttype, fontsize, fontcolor, thescreen):
		font.Font.__init__(_, fonttype, fontsize)
		_.screen = thescreen
		_.color = fontcolor

		_.justified = "left"

	def sprint(_, text, textpos):
		"""
		font = pygame.font.Font(None, 36)
  	  	text = font.render("Pummel The Chimp, And Win $$$", 1, (10, 10, 10))
  	  	textpos = text.get_rect(centerx=background.get_width()/2)
  	  	background.blit(text, textpos)
		"""
		realtext = _.render(text, 1, _.color)
		if _.justified == "left":
                    realtextpos = realtext.get_rect(left=textpos[0], centery=textpos[1])
                if _.justified == "center":
                    realtextpos = realtext.get_rect(centerx=textpos[0], centery=textpos[1])

		return _.screen.blit(realtext, realtextpos)


# content generation classes #########################################


def makeTri(width, height):
	''' Ships and missiles are made of triangles '''
	verts = [	[0, height/2],
			[width/2, -height/2],
			[-width/2, -height/2]  ]

	tri = Mesh2D()
        tri.loadvertices(verts)

	return tri

def makeDiamond(size):
	''' mainly for fun effects '''
	verts = [  	[0,size],
				[size,0],
				[0,-size],
				[-size,0] ]

	diamond = Mesh2D()
	diamond.loadvertices(verts)

	return diamond


def makeAsteroid(size, edges, irregularity, jaggedness):
	# size : roughly the radius
	# edges : number of edges
	# irregularity : rotation variation between vertices
	#   0.0 makes each vertex regularly spaced
	# jaggedness : magnitude variation between vertices
	#   0.0 is perfectly 'round'
	asteroid = Mesh2D()
	asteroid.color = [128, 128, 164]
        asteroid.fatness = 4

	# average degrees per vertex
	degrees_per_vert = 360 / edges

	realirreg = irregularity * degrees_per_vert
	realjaggy = jaggedness * size

	# coordinates are generated radially then converted to cartesian
	# Generate random thetas for the points, making sure to not make duplicates
	for i in range (0, edges):
		my_irreg = (random.random() - 0.5 * 2) * realirreg
		my_jaggy = (random.random() - 0.5 * 2) * realjaggy

		realtheta = (degrees_per_vert * i) + my_irreg
		realmag = size + my_jaggy

		vx = sin(radians(realtheta)) * realmag
		vy = cos(radians(realtheta)) * realmag

		asteroid.add(Point([vx, vy]))

	return asteroid		#finished mesh!


# object classes #####################################################
class Obj:
	def __init__(_):
                _.alive = True
		_.mesh = Mesh2D()

		_.pos = Point([0,0])
		_.vel = Point([0,0])
		_.heading = 0
		_.size = 1.0

	def setpos(_, newpt):
            if _.alive is True:
		_.pos = newpt
		_.mesh.setpos(newpt)

	def push(_, direction, force):
            if _.alive is True:
		_.vel.x += sin( radians(direction) ) * force
		_.vel.y += cos( radians(direction) ) * force
	
	def rotate(_, rotamt):
            if _.alive is True:
		_.heading = wrap(_.heading + rotamt)
		_.mesh.rotate(rotamt)

	def move(_, numframes):
            if _.alive is True:
		realvel = Point( [_.vel.x * numframes, _.vel.y * numframes] )
		_.pos += realvel

		# make the mesh follow
		_.mesh.translate(realvel)

        def draw(_, myscreen, myorigin):
            if _.alive is True:
                _.mesh.draw(myscreen, myorigin, _.pos, _.heading)

	def friction(_, amt):
             _.vel *= 1.0 - amt
	
	def collideBBox(_, other):
            ''' NON AXIS-ALIGNED bounding box collision '''
            # don't test collision with the same object!
            if other == _:
                    return False

            itsleft = other.pos.x - other.size
            itsright = other.pos.x + other.size
            itstop = other.pos.y - other.size
            itsbottom = other.pos.y + other.size

            # now see if they overlap
            if (_.pos.x + _.size > itsleft):
                    if (_.pos.x - _.size < itsright):
                            if (_.pos.y + _.size > itstop):
                                    if (_.pos.y - _.size < itsbottom):
                                            return True
    
            return False

	def collideBSphere(_, other):
            ''' bounding-sphere collision '''
            if other == _:
                return False
		    
            if _.pos.dist(other.pos) < _.size + other.size:
                return True
            else:
                return False


class Ship(Obj):
	def __init__(_):
		Obj.__init__(_)

		_.turnspeed = 1.0
		_.impulse = 1.0
		_.maxspeed = 1.0

	def thrust(_, thrustamt, numframes):
		''' arg should be a floating-point number between 0 and 1 '''
		_.push(_.heading, thrustamt * _.impulse * numframes)

		# do speed limiting here
		if _.vel.x*_.vel.x + _.vel.y*_.vel.y > _.maxspeed*_.maxspeed:
			_.vel.x *= 0.99
			_.vel.y *= 0.99

	def turn(_, turnamt, numframes):
		''' arg should be a floating-point number between 0 and 1 '''
		_.rotate(turnamt * _.turnspeed * numframes)

	def kill(_):
            # sudden stop!
            _.alive = False
            #_.vel = Point([0,0])
            del _
            



class Roid(Obj):
	def __init__(_):
		Obj.__init__(_)

                # create le mesh
                realsize = random.randrange(asteroid_min_size, asteroid_max_size, 1)

		_.mesh = makeAsteroid(realsize,
				    asteroid_edges,
				    asteroid_irregularity,
				    asteroid_jaggedness)

		_.mesh.fatness = asteroid_line_width

		# set up random spin and drift
		_.spinspeed = (random.random() - 0.5) * 2 * asteroid_spinspeed
		_.vel.x = (random.random() - 0.5) * 2 * asteroid_drift
		_.vel.y = (random.random() - 0.5) * 2 * asteroid_drift

		# make up a plausible physical size
		_.size = realsize - (realsize * asteroid_jaggedness/4)

	def spin(_, numframes):
		this_spin = _.spinspeed * numframes
		_.rotate(this_spin)
                

## AI Stuff #########################################################

class AI:
    def __init__(_, puppet):
        _.puppet = puppet
        _.unlock()

    def thrust(_, amt, numframes):
        if _.thrustLock is not True:
            _.thrustLock = True
            _.puppet.thrust(amt, numframes)

    def turn(_, amt, numframes):
        if _.turnLock is not True:
            _.turnLock = True
            _.puppet.turn(amt, numframes)

    def unlock(_):
        _.thrustLock = False
        _.turnLock = False
            
    def seek(_, dest, tolerance, numframes):
	# turn towards a point and keep thrusting to it until
	# we get there

	desired = _.puppet.pos.angleto(dest)
	current = _.puppet.heading

	
	# first see if we should turn at all
	#if (wrap(desired - current) > _.puppet.turnspeed):
        # turn to face the target
        if (desired > current):
                if (wrap(desired - current) > 180):
                    _.turn(-1.0, numframes)
                    if wrap(current - desired) > 360 - tolerance:
                        #thrust towards the target
                        _.thrust(1.0, numframes)
                else:
                    _.turn(1.0, numframes) # LEFT
                    # dest is between 0 and 180
                    if wrap(current - desired) < tolerance:
                        #thrust towards the target
                        _.thrust(1.0, numframes)
                        
        else:
                if (wrap(current - desired) > 180):
                    _.turn(1.0, numframes)
                    if wrap(current - desired) > 360 - tolerance:
                        #thrust towards the target
                        _.thrust(1.0, numframes)
                else:
                    _.turn(-1.0, numframes) # RIGHT
                    # dest is between 0 and 180
                    if wrap(current - desired) < tolerance:
                        #thrust towards the target
                        _.thrust(1.0, numframes)


    def avoid(_, dest, tolerance, numframes):
		# turn towards a point and keep thrusting to it until
	# we get there

	desired = wrap(_.puppet.pos.angleto(dest) + 180)
	current = _.puppet.heading

	
	# first see if we should turn at all
	#if (wrap(desired - current) > _.puppet.turnspeed):
        # turn to face the target
        if (desired > current):
                if (wrap(desired - current) > 180):
                    _.turn(-1.0, numframes)
                    if wrap(current - desired) > 360 - tolerance:
                        #thrust towards the target
                        _.thrust(1.0, numframes)
                else:
                    _.turn(1.0, numframes) # LEFT
                    # dest is between 0 and 180
                    if wrap(current - desired) < tolerance:
                        #thrust towards the target
                        _.thrust(1.0, numframes)
                        
        else:
                if (wrap(current - desired) > 180):
                    _.turn(1.0, numframes)
                    if wrap(current - desired) > 360 - tolerance:
                        #thrust towards the target
                        _.thrust(1.0, numframes)
                else:
                    _.turn(-1.0, numframes) # RIGHT
                    # dest is between 0 and 180
                    if wrap(current - desired) < tolerance:
                        #thrust towards the target
                        _.thrust(1.0, numframes)

	
    def lead(_, target):
	# figure out the place where the target is GOING to be
	# and then return the point

	# distance / speed = time to target
	# speed is distance from the current position to the velocity vector's
	# endpoint
	myspeed = _.puppet.pos.dist( _.puppet.vel )

	# avoid divide-by-zero
	if myspeed == 0:
            myspeed = 1
            
	timetotarget = _.puppet.pos.dist( target.pos ) / myspeed
	
	# FIXME : this is way too exact... the relative_vel should be offset by a random number 
	# to simulate inexact aiming
	relative_vel = target.vel - _.puppet.vel

	leadpoint = Point([ target.pos.x + (relative_vel.x * timetotarget),
                            target.pos.y + (relative_vel.y * timetotarget) ])

	return leadpoint


class CopAI(AI):
    def __init__(_, puppet, target):
        AI.__init__(_, puppet)
        _.target = target

        _.tolerance = 25 #degrees
            
    def chase(_, shiplist, roidlist, numframes):
        ''' Main AI loop'''
        #avoid_asteroids()
##        closest_roid_dist = avoidance_distance + 1
##        closest_roid = Point([0,0])
##
##        # find the closest asteroid in sight
##        # FIXME : modify this so that we're only avoiding asteroids
##        #   directly in our path (vel -> polar.theta)
##        # However, the list might be shortened by a quick 'vision'
##        # query using distance or bounding box
##        for roid in roidlist:
##            thisroid_dist = _.puppet.pos.dist(roid.pos)
##            if thisroid_dist < closest_roid_dist:
##                closest_roid = roid.pos
##                closest_roid_dist = thisroid_dist
##
##        # avoid it!
##        if closest_roid != Point([0,0]):
##            _.avoid(closest_roid, 180, numframes)

        # avoid other cops
##        closest_ship_dist = avoidance_distance + 1
##        closest_ship = Point([0,0])
##        for ship in shiplist:
##            # don't avoid the player!
##            if ship != _.target:
##                thisship_dist = _.puppet.pos.dist(ship.pos)
##                if thisship_dist < closest_ship_dist:
##                    closest_ship = ship.pos
##                    closest_ship_dist = thisship_dist
##
##        # avoid it!
##        if closest_ship != Point([0,0]):
##            _.avoid(closest_ship, 180, numframes)

        #else:
        #pursue(player)
        leadpt = _.lead(_.target)
        
        _.seek(leadpt, _.tolerance, numframes)
        


# manager classes ###################################################

class ObjManager:
	def __init__(_, myscreen):
		_.ships = []
		_.roids = []
		_.ais = []

		_.screen = myscreen

		# initialize the default font
		_.sysfont = PrintFont(None, 12, (255,64,48), myscreen)

		_.origin = [0,0]

	def createObj(_, constructor):
                ''' returns a pointer to the object just made... OGRE-style!'''
		if isinstance(constructor, Ship):
			_.ships.append(constructor)
			if isinstance(constructor, Player):
                            _.playership = constructor
		elif isinstance(constructor, Roid):
			_.roids.append(constructor)
		elif isinstance(constructor, CopAI):
                        _.ais.append(constructor)
		else:
                    print "error : " + constructor + " is not a valid Obj type"
		
		return constructor

	def deleteObj(_, obj):
                ''' deletes an object '''
		if isinstance(obj, Ship):
			_.ships.remove(obj)
		elif isinstance(obj, Roid):
			_.roids.remove(constructor)
		elif isinstance(obj, CopAI):
                        _.ais.remove(obj)
		else:
                    print "error : " + obj + " not found in ObjMgr"

                # deallocate it
                del obj

	def doRender(_):
		for ship in _.ships:
                    if ship.alive is True:
                        ship.draw(_.screen, _.origin)

		for roid in _.roids:
			roid.draw(_.screen, _.origin)


	def doClear(_):
		for ship in _.ships:
			ship.mesh.clear(_.screen)

		for roid in _.roids:
			roid.mesh.clear(_.screen)


	def doPhysics(_, numframes):
		for ship in _.ships:
                    if ship.alive is True:
                        #for othership in _.ships:
                        #    ship.collidesWith(othership)
			ship.move(numframes)
			ship.friction(global_friction)

			for oship in _.ships[_.ships.index(ship)+1:]:
                            if ship.collideBSphere(oship):
                                # if two ships collide, they both die
                                oship.kill()
                                ship.kill()
                            

		for roid in _.roids:
			# do a little fun spinny rotation
			roid.spin(numframes)
			roid.move(numframes)

			# now check collision with other roids and
			# ships
			for ship in _.ships:
                            if ship.alive is True:
                                if roid.collideBSphere(ship):
                                     #transfer momentum
                                    tempvel = roid.vel
                                    roid.vel = ship.vel * asteroid_bounciness
                                    ship.vel = tempvel * asteroid_bounciness
                                    # HACK: push them along their way a bit
                                    roid.move(numframes)
                                    ship.move(numframes)

                                    ship.kill()

                        # iterate through the remaining roids
                        for oroid in _.roids[_.roids.index(roid)+1:]:
                            if roid.collideBSphere(oroid):
                                #transfer momentum
                                tempvel = roid.vel
                                roid.vel = oroid.vel * asteroid_bounciness
                                oroid.vel = tempvel * asteroid_bounciness
                                # HACK: push them along their way a bit
                                roid.move(numframes)
                                oroid.move(numframes)
                                

        def doAI(_, numframes):
            for ai in _.ais:
                # kill off ai's whose puppets are dead
                if ai.puppet.alive is False:
                    _.ais.remove(ai)
                else:
                    ai.unlock()
                    ai.chase(_.ships, _.roids, numframes)

        def isUnoccupied(_, obj):
            # see if this is a good spot
##            dummy = Obj()
##            dummy.pos = mypos
##            dummy.size = mysize
            
            for roid in _.roids:
                if roid.collideBSphere(obj):
                    #nope
                    return False

            for ship in _.roids:
                if ship.collideBSphere(obj):
                    #nope
                    return False

            # yay!
            return True
                

            

        
# lazy "culling" algorithm
# really just figures out if a portion of an object should be drawn, and if it
# is, draws the whole thing
def isVisible(player, obj):
	min_x = player.pos.x - half_resx
	max_x = player.pos.x + half_resx

	min_y = player.pos.x - half_resy
	max_y = player.pos.x + half_resy

	# now see if they overlap
	if (obj.x + obj.size > min_x):
		if (obj.x - obj.size < max_x):
			if (obj.y + obj.size > min_y):
				if (obj.y - obj.size < max_y):
					return True
	
	return False





# game object settings, play with these to make the game harder/easier
class Player(Ship):
	def setup(_):
		_.mesh = makeTri(14, 20)
		_.mesh.color = (255, 128, 64)

		_.impulse = 400.0
		_.maxspeed = 250.0
		_.turnspeed = 135.0

		_.size = 10.0

##	def kill(_):
##            player_lives -= 1
##            Ship.kill(_)

class Cop(Ship):
	def setup(_):
		_.mesh = makeTri(20, 30)
		_.mesh.color = (32, 32, 164)

		_.impulse = 425.0
		_.maxspeed = 300.0
		_.turnspeed = 100.0
		#_.gun.bulletspeed = 1.0
		#_.gun.rof = 5
		
		_.size = 15.0
		
        def setrandpos(_, player, objmgr):
            # NOTE : this looks pretty ugly mainly because Python
            # has no do-while loops....
            
            # roll up a theta
            theta = random.randint(0, 359)

            # roll up a mag
            mag = random.randint(cop_min_spawn_distance,
                                 cop_max_spawn_distance)

            # calculate position
            newpos = Point([ sin(radians(theta)) * mag,
                             cos(radians(theta)) * mag])


            # now translate it to where it should be in relation to
            # the player
            newpos += player.pos

            # also, the heading to go DIRECTLY towards the player! haha!
            _.rotate( wrap(theta + 180) )

            _.setpos( newpos )

            # DANGER : might cause infinite loop                
            while objmgr.isUnoccupied(_) is False:                
                # roll up a theta
                theta = random.randint(0, 359)

                # roll up a mag
                mag = random.randint(cop_min_spawn_distance,
                                     cop_max_spawn_distance)

                # calculate position
                newpos = Point([ sin(radians(theta)) * mag,
                                 cos(radians(theta)) * mag])


                # now translate it to where it should be in relation to
                # the player
                newpos += player.pos

                _.setpos( newpos )


def main():
        print r"Setting up pygame..."
	init()
	print "done."
	
        print r"Setting up screen..."
        #screen = Surface((resolution))
        
        if fullscreen is True:
            screen = display.set_mode((resolution), FULLSCREEN | HWSURFACE | DOUBLEBUF)
        else:
            screen = display.set_mode((resolution))
            
	display.set_caption(gamestring)

        # set up background
	background = Surface(screen.get_size())
        background = background.convert()
        background.fill(background_color)

	print "done."

	# we're lazy.. make the mouse visible
	mouse.set_visible(1)


	# initialize font module
	font.init()
	register_quit(font.quit)

	# initialize the default font
	sysfont = PrintFont(None, 24, (255,255,255), screen)

	infofont = PrintFont(None, 24, (255, 64, 64), screen)
	info_rect = Rect(( 10, 10, 100, 75 ))

	debugfont = PrintFont(None, 20, (148, 255, 164), screen)
        debug_rect = Rect(( resolution[0] - 200, 5, 200, 50 ))

        gameoverfont = PrintFont(None, 64, (255,128,64), screen)
        gameoverfont.justified = "center"

	# initialize the clock
	gametime = time.Clock()

	# initialize game logic stuff
	ObjMgr = ObjManager(screen)
	score = 0

	playa = ObjMgr.createObj(Player())
	playa.setup()

        while 1:
                randx = (random.random() - 0.5) * arena_size[0]
		randy = (random.random() - 0.5) * arena_size[1]              
		playa.setpos(Point([randx, randy]))
		
                # see if this is a good spot
                if ObjMgr.isUnoccupied(playa):
                    break

                # else try again... DANGER : might cause infinite loop
        
        player_lives = 3
        newlives_earned = 0
        waiting_for_respawn = False

	controls = playa	# abstraction layer woot woot
	G_origin = [controls.pos.x, controls.pos.y]
	ObjMgr.origin = G_origin

	
	cops = []
	level = starting_cops
	for i in range(0, starting_cops):
		rookie = ObjMgr.createObj(Cop())
		rookie.setup()
		rookie.setrandpos(playa, ObjMgr)
		
		# give it some AI
		brains = ObjMgr.createObj(CopAI(rookie, playa))

		cops.append(rookie) #useful for keeping track of how many
                                    #cops are on the screen
	
        roids = []
	for i in range(0, asteroids_in_arena):
		roidoidoid = ObjMgr.createObj(Roid())
		
		randx = (random.random() - 0.5) * arena_size[0]
		randy = (random.random() - 0.5) * arena_size[1]              
		roidoidoid.setpos(Point([randx, randy]))
		
                # see if this is a good spot
                if ObjMgr.isUnoccupied(roidoidoid):
                    roids.append(roidoidoid)
                else:
                    i -= 1 # try again... DANGER : might cause infinite loop


	# run caching functions here

        score_rect = Rect([0,0,0,0])

	gamequit = False
	game_over_man = False
	frametime = 0
	debug_frametime = ""
	while gamequit is False:
		event.pump()
		
		# input ################################### 
                #mousepos = Point(mouse.get_pos())
        
		pressed = key.get_pressed()
		if pressed is not None:
                    if pressed[K_ESCAPE]:	gamequit = True
                    if pressed[K_F1]:	display.toggle_fullscreen()
                    if pressed[K_w]:    controls.thrust(1.0, frametime)
		    if pressed[K_s]:	controls.thrust(-0.5, frametime)
                    if pressed[K_a]:    controls.turn(-1.0, frametime)
                    if pressed[K_d]:    controls.turn(1.0, frametime)

                    # side thrusters! zip!
                    if pressed[K_q]:    controls.push(wrap(controls.heading - 90),
                                                controls.impulse * 0.5 * frametime)

                    if pressed[K_e]:    controls.push(wrap(controls.heading + 90),
                                               controls.impulse * 0.5 * frametime)

		
		# cycle is : clear, render, flip, physics
		# so that the physics functions get a proper time
		
		# clear ########################################
                screen.blit(background, (0,0)) #lazy clear
		#ObjMgr.doClear()
		#screen.fill(score_rect)
		
		# render #######################################
		ObjMgr.doRender()

		# also render the overlay
		screen.fill((100,0,0) , info_rect )
		infofont.sprint('score: %(#)u' % {'#' : score}, [20,20])
                infofont.sprint('lives: ' + str(player_lives), [20, 35])
                
                infofont.sprint('level: ' + str(level), [20, 60])
                infofont.sprint('cops: ' + str(len(cops)), [20, 75])

                if debug_mode is True:
                    screen.fill((0,100,0), debug_rect )
                    debugfont.sprint( 'time modulo: ' + str(time.get_ticks() % 1000.0),
                                      [resolution[0] - 190, 15])

                # GAME OVER MAN! GAME OVER!
                if game_over_man is True:
                    gameoverfont.sprint("GAME OVER, MAN! GAME OVER!", [half_resx, half_resy])

        
		# DISPLAY FLIP ####################################################
		display.flip()
                ##if busy_loop is True:
                ##    gametime.tick_busy_loop(desired_fps)
		##else:
                gametime.tick(desired_fps)

		frametime = gametime.get_time() / 1000.0
		# #################################################################

		# physics, etc. ################################
		# pass a floating point value reporting how many
		# seconds have passed this frame
		ObjMgr.doPhysics(frametime)
		ObjMgr.doAI(frametime)

                # make the camera track the player
		ObjMgr.origin = [controls.pos.x, controls.pos.y]

                if playa.alive is False:
                    if player_lives <= 0:
                        game_over_man = True
                    else:
                        if waiting_for_respawn is False:
                            player_lives -= 1

                        waiting_for_respawn = True

                        # reset player
                        # FIXME : currently, very dumb.
                        if ObjMgr.isUnoccupied(playa):
                            playa.alive = True
                            waiting_for_respawn = False
                        
                        

                # give the player a new life if they deserve it
                if score >= new_life_score * (newlives_earned+1):
                    newlives_earned += 1
                    player_lives += 1
                        

                # HACK: sort of dumb to do this here
                for cop in cops:
                    if cop.alive is False:
                        # FIXME: we're being lazy and giving the player
                        # points no matter what the circumstances of the
                        # cop's death
                        score += cop_kill_score
                        cops.remove(cop)

                

		# every second...
		if time.get_ticks() % 1000 == 0:
                        if playa.alive is True:
                            score += score_per_second # give the player a point

                # generate new cops when there are no cops left
                if len(cops) <= 0:
                    level += 1
                    for i in range(0, level):
                        rookie = ObjMgr.createObj(Cop())
                        rookie.setup()

                        rookie.setrandpos(playa, ObjMgr)

                        # give it some AI
                        brains = ObjMgr.createObj(CopAI(rookie, playa))

                        cops.append(rookie) #useful for keeping track of how many
                                            #cops are on the screen

                # wrap roids when they get outside the 'arena'
                for roid in ObjMgr.roids:
                    # HACK : oh god this is a good example of shooting oneself
                    # in ones foot look how ugly it is lhgaulhga

                    # falling off the RIGHT side of the arena
                    if roid.pos.x - controls.pos.x > half_arenax:
                        roid.setpos( Point([-half_arenax + controls.pos.x,
                                            roid.pos.y])    )
                    # falling off the LEFT side of the arena
                    elif roid.pos.x - controls.pos.x < -half_arenax:
                        roid.setpos( Point([ half_arenax + controls.pos.x,
                                            roid.pos.y])    )
                        
                    # falling off the RIGHT side of the arena
                    if roid.pos.y - controls.pos.y > half_arenay:
                        roid.setpos( Point([ roid.pos.x,
                                             -half_arenay + controls.pos.y]))
                    # falling off the LEFT side of the arena
                    elif roid.pos.y - controls.pos.y < -half_arenay:
                        roid.setpos( Point([ roid.pos.x,
                                             half_arenay + controls.pos.y]))


                # / while quit is False:
	
	# shut down pygame
	quit()
	
if __name__ == '__main__':
	main()
