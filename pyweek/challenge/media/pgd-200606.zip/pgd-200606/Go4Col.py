#!/usr/bin/python

import random
import pygame

screen_size = (1024, 768)

pygame.init()
screen = pygame.display.set_mode(screen_size, pygame.FULLSCREEN)
pygame.mouse.set_visible(False)

def paint(t, c):
    n = 0
    for r in t:
        pygame.draw.rect(screen, c[n], r)
        n += 1
    pygame.display.update()


xnum = 2#int(1+random.random()*5)#screen_size[0])
ynum = xnum#int(1+random.random()*10)#screen_size[1])

w = screen_size[0]/xnum
h = screen_size[1]/ynum

tnum = xnum*ynum

t = []
for y in range(ynum):
    for x in range(xnum):
        t.append((x*w,y*h,w,h))

finished = False
while not finished:

    d = []
    for j in range(3):
        x=[]
        sum = 0.0
        for i in range(tnum):
            x.append(random.random())
            sum += x[i]
        for i in range(tnum):
            x[i] /= sum
        
        d.append(x)

    c = []
    for i in range(tnum) :
        c.append((d[0][i]*255, d[1][i]*255, d[2][i]*255))
        
    paint(t, c)
    
    for e in pygame.event.get():
        if e.type in (pygame.QUIT, pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN, ):
          finished = True
          break
          
    pygame.time.wait(2000)
    
    