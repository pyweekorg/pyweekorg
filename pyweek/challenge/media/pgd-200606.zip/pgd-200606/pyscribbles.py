#!/usr/bin/env python
"""This is a drawing program. Just click and drag to draw.
You can select from 10 colours in the top bar or press the left mouse button
to change colour and the type in red, green and blue values.
Press the up and down arrow keys to change the line width.

You need pygame and python to run this. All of it was made by me, Jes.

Released under the GNU GPL license"""
 
import pygame
from pygame.locals import *


pygame.init()
screen = pygame.display.set_mode((640,480))
pygame.display.set_caption("PyScribbles")
playing = 1
penwidth = 3
colour = (0,0,0)
oldpos = pygame.mouse.get_pos()
#Set up layout
screenrect=pygame.draw.rect(screen,(255,255,255),(5,65,630,410))
palettebox = pygame.draw.rect(screen,(160,160,160),(0,0,640,60),0)
#create palette and "clear" button
red = pygame.draw.rect(screen,(255,0,0),(13,10,40,40))
orange = pygame.draw.rect(screen,(255,140,0),(59,10,40,40))
yellow = pygame.draw.rect(screen,(255,255,0),(105,10,40,40))
green = pygame.draw.rect(screen,(0,255,0),(151,10,40,40))
blue = pygame.draw.rect(screen,(0,0,255),(197,10,40,40))
purple = pygame.draw.rect(screen,(140,0,255),(243,10,40,40))
brown = pygame.draw.rect(screen,(140,77,5),(289,10,40,40))
black = pygame.draw.rect(screen,(0,0,0),(335,10,40,40))
grey = pygame.draw.rect(screen,(200,200,200),(381,10,40,40))
white = pygame.draw.rect(screen,(255,255,255),(427,10,40,40))
colourlist=[red,orange,yellow,green,blue,purple,brown,black,grey,white]
font=pygame.font.Font(None,32)
cleartext = font.render("Clear",1,(0,0,0),(255,255,255))
clearbox=pygame.draw.rect(screen,(255,255,255),(527,10,100,40))
textbox=cleartext.get_rect()
textbox.center = clearbox.center
screen.blit(cleartext,textbox)

while playing == 1:
#get and process input
	for event in pygame.event.get():
		if event.type == QUIT:
			playing = 0
#key conrols
		elif event.type == KEYDOWN and event.key == K_ESCAPE:
			playing = 0
		elif event.type == KEYDOWN and event.key == K_UP:	
			penwidth=penwidth + 1
		elif event.type == KEYDOWN and event.key == K_DOWN:	
			if penwidth >= 2:
				penwidth = penwidth - 1
		elif event.type == MOUSEBUTTONDOWN and event.button == 3:
			red =int(raw_input("Enter a red value ->"))
			green =int(raw_input("Enter a green value ->"))
			blue =int(raw_input("Enter a blue value ->"))
			colour=(red,green,blue)
		elif event.type == MOUSEBUTTONDOWN and event.button == 1:
#drawing/colour selecting controls
			oldpos = pygame.mouse.get_pos()
		clicked = pygame.mouse.get_pressed()
		if clicked[0]==True:
			mousepos = pygame.mouse.get_pos()
			if clearbox.collidepoint(mousepos):
				screenrect=pygame.draw.rect(screen,(255,255,255),(5,65,630,410))
			for c in colourlist:
				if c.collidepoint(mousepos):
					colour = screen.get_at(mousepos)
			if screenrect.collidepoint(mousepos) and screenrect.collidepoint(oldpos):
				pygame.draw.line(screen,colour,oldpos,mousepos,penwidth)
				oldpos = pygame.mouse.get_pos()

	pygame.display.update()

