'''GOOP
Written in 2006 by Toby Sargeant and placed in the pubic domain.

Instructions:

  A,D    -- move left and right
  W,S    -- increase / decrease size
  space   -- jump
  arrows -- rotate play area
'''

from math import *
import sys
import pygame
import random
from pygame.locals import *

SCREENRECT = Rect(0, 0, 1024, 768)
G = 15.0
GRAVITY = (0.0, -G)
DRAG = -0.3

CTM=None

def add(a, b): return (a[0] + b[0], a[1] + b[1])
def sub(a, b): return (a[0] - b[0], a[1] - b[1])
def dot(a, b): return a[0] * b[0] + a[1] * b[1]
def cross(a, b): return a[0] * b[1] - a[1] * b[0]

def length2(a): return dot(a, a)
def length(a): return sqrt(dot(a, a))
def scale(a, l): return (a[0] * l, a[1] * l)
def norm(a): return scale(a, 1.0/length(a))
def neg(a): return (-a[0], -a[1])
def unitl(a): l = length(a); return scale(a, 1.0/l), l
def mult(m, p): return m[0][0] * p[0] + m[0][1] * p[1] + m[0][2], m[1][0] * p[0] + m[1][1] * p[1] + m[1][2]
def reflect(v, n): return add(scale(n, -2.0 * dot(v, n)), v)
def project(a, b): return scale(b, dot(a, b))

def bbox(p):
  return (
    (min([ _[0] for _ in p ]), min([ _[1] for _ in p ])),
    (max([ _[0] for _ in p ]), max([ _[1] for _ in p ])))

def bcirc(p):
  l = float(len(p))
  c = sum([ _[0] for _ in p ]) / l, sum([ _[1] for _ in p ]) / l
  return c, max([ length(sub(_, c)) for _ in p ])

def bcircbcirc((p1, r1), (p2, r2)):
  return length2(sub(p1, p2)) < (r1 + r2) ** 2

def bboxpoint(b, p):
  return b[0][0] <= p[0] <= b[1][0] and b[0][1] <= p[1] <= b[1][1]

def bboxbbox(b1, b2):
  return not (b1[1][0] < b2[0][0] or b1[1][1] < b2[0][1] or
              b2[1][0] < b1[0][0] or b2[1][1] < b1[0][1])

def bboxcirc(b, (p, r)):
  return not (p[0] + r < b[0][0] or p[1] + r < b[0][1] or
              p[0] - r > b[1][0] or p[1] - r > b[1][1])

def A(a):
  if a > pi: return a - 2 * pi
  if a < -pi: return a + 2 * pi
  return a

def contains(p, v):
  s = 0
  rp = r0 = atan2(v[0][1] - p[1], v[0][1] - p[1])

  for i in xrange(1, len(v)):
    r = atan2(v[i][1] - p[1], v[i][1] - p[1])
    s = s + A(r - rp)
    rp = r

  s = s + A(r0 - rp)

  return fabs(s) > 1e-6
  
def intersection(a1, a2, b1, b2):
  va = sub(a2, a1)
  vb = sub(b2, b1)

  dx13 = a1[0] - b1[0]
  dy13 = a1[1] - b1[1]
  dx43 = b2[0] - b1[0]
  dy43 = b2[1] - b1[1]
  dx21 = a2[0] - a1[0]
  dy21 = a2[1] - a1[1]

  ua_n = dx43 * dy13 - dy43 * dx13
  ub_n = dx21 * dy13 - dy21 * dx13
  u_d  = dy43 * dx21 - dx43 * dy21

  if u_d != 0.0:
    ua = ua_n / u_d
    ub = ub_n / u_d
    if 0.0 <= ua <= 1.0 and 0.0 <= ub <= 1.0:
      return add(a1, scale(va, ua)), ua, ub
  return None, None, None

class Mass:
  def __init__(self):
    self.p = self.prev_p = (0.0, 0.0)
    self.v = (0.0, 0.0)
    self.F = (0.0, 0.0)
    self.m = 1.0
    self.contact = None

  def reset(self):       self.prev_v = self.v; self.prev_p = self.p; self.F = (0.0, 0.0)
  def accumA(self, A):   self.F = add(self.F, scale(A, self.m))
  def accumF(self, F):   self.F = add(self.F, F)
  def calcVel(self, dt): self.v = add(self.v, scale(self.F, dt / self.m))
  def calcPos(self, dt): self.p = add(self.p, scale(self.v, dt))

class Repulsion:
  def __init__(self, masses, k, d_min, d_max):
    self.masses = masses
    self.k = k
    self.d_min = d_min
    self.d_max = d_max

  def calc(self, dt):
    for i in range(len(self.masses)):
      for j in range(i + 1, len(self.masses)):
        d = sub(self.masses[i].p, self.masses[j].p)
        l = length(d)
        if l < self.d_min: l = self.d_min
        if l > self.d_max: continue
        F = scale(d, self.k / (l * l * l))
        _f = length(F)

        self.masses[i].accumF(F)
        self.masses[j].accumF(neg(F))
    return True

class Spring:
  def __init__(self, m1, m2, l, ks, kd):
    self.m1 = m1
    self.m2 = m2
    self.l = l
    self.ks = ks
    self.kd = kd

  def calc(self, dt):
    lx = self.m1.p[0] - self.m2.p[0]
    ly = self.m1.p[1] - self.m2.p[1]
    ldotx = self.m1.v[0] - self.m2.v[0]
    ldoty = self.m1.v[1] - self.m2.v[1]
    magl2 = lx * lx + ly * ly
    magl = sqrt(magl2)

    if magl >= 1e-10:
      k = (self.ks * (magl - self.l) / magl +
           self.kd * (lx * ldotx + ly * ldoty) / magl2)
      Fx = lx * -k
      Fy = ly * -k

      self.m1.accumF((Fx, Fy))
      self.m2.accumF((-Fx, -Fy))
    return True

class Poly:
  stickiness = 40.0
  elasticity = 1.0
  contact_thresh = 200.0
  static_friction_thresh = 20.0
  sliding_friction_coeff = -1.0
  friction_drag = -0.1

  def __init__(self, *p):
    self.v = p
    self.bcirc = bcirc(p)

  def edge(self, e):
    return (self.v[e], self.v[(e + 1) % len(self.v)])

  def edgeCount(self):
    return len(self.v)

  def edges(self):
    for i in range(len(self.v)):
      yield self.edge(i)

  def draw(self, ctm, surf):
    pygame.draw.polygon(surf, (100, 120, 160), [ mult(ctm, _) for _ in self.v ])

  def crosses(self, p1, p2):
    a = self.v[-1]
    c = []
    for b in self.v:
      i, ua, ub = intersection(a, b, p1, p2)
      if i is not None:
        c.append((ub, i, self, a, b))
      a = b
    if len(c):
      return min(c)

class Contact:
  def __init__(self, p, m, o, a, b, t_frac):
    self.mass = m
    self.obj = o
    self.p1 = a
    self.p2 = b
    self.t_frac = t_frac
    self.v, self.l = unitl(sub(b, a))
    self.n = (self.v[1], -self.v[0])
    m.contact = self
    m.p = m.prev_p = p
    m.v = m.prev_v = project(m.v, self.v)

  def breakContact(self):
    self.mass.contact = None
    self.mass = None

  def apply(self, dt):
    if self.mass is None: return False

    m = self.mass

    if not 0.0 <= dot(self.v, sub(m.p, self.p1)) <= self.l:
      self.breakContact()
      return False

    Fn_l = dot(self.n, m.F)
    if Fn_l > self.obj.stickiness:
      self.breakContact()
      return False

    vn_l = dot(self.n, m.v)

    Fn = scale(self.n, Fn_l)
    Ft = sub(m.F, Fn)

    vn = scale(self.n, vn_l)
    vt = sub(m.v, vn)

    m.v = vt
    m.accumF(neg(Fn))

    if Fn_l < 0.0:
      Ff = scale(vt, self.obj.sliding_friction_coeff)
      m.accumF(Ff)

    return True

class SpringMassSystem:
  def __init__(self):
    self.masses = []
    self.forces = []
    self.constraints = []

  def calc(self, world, dt, gravity):
    for m in self.masses:
      m.reset()
      m.accumA(gravity)
      m.accumA(scale(m.v, DRAG))

    self.forces = [ _ for _ in self.forces if _.calc(dt) ]
    self.constraints = [ _ for _ in self.constraints if _.apply(dt) ]

    for m in self.masses:
      m.calcVel(dt)
      m.calcPos(dt)

    for m in self.masses:
      if m.contact: continue
      collisions = []

      collision = world.collide(m.prev_p, m.p)
      if collision is not None:
        t, p, o, a, b = collision
        N = norm(sub(b, a))
        N = (N[1], -N[0])
        if dot(N, m.v) > 0:
          continue
        v = scale(reflect(m.v, N), o.elasticity)
        if length2(v) < o.contact_thresh:
          self.constraints.append(Contact(p, m, o, a, b, (1 - t)))
        else:
          m.p, m.v = p, v
          m.calcPos(dt * (1-t))

class KeepWithin:
  def __init__(self, mass, bounds):
    self.mass = mass
    self.bounds = bounds

  def apply(self, dt):
    perim = [ _.p for _ in self.bounds ]
    if not contains(self.mass.p, perim):
      pass
    return True

_h_cache = {}
def H(subdiv = 4):
  try:
    r = _h_cache[subdiv]
  except:
    r = _h_cache[subdiv] = [
    ( 2 * s**3 - 3 * s**2 + 1,
     -2 * s**3 + 3 * s**2,
          s**3 - 2 * s**2 + s,
          s**3 -     s**2) for s in [ _ / float(subdiv) for _ in range(subdiv) ] ]
  return r

def splineLoop(surf, p, subdiv = 10, K = 1.0):
  h = H(subdiv)

  def tangent(p, q, r):
    a, al = unitl(sub(r, q))
    b, bl = unitl(sub(q, p))
    try:
      return scale(norm(add(a, b)), al)
    except:
      return sub(r, q)

  p = [ p[_] for _ in range(len(p)) if p[_] != p[(_+1) % len(p)] ]
  if len(p) == 2:
    return p

  pp = p[-1]
  p1 = p[0]
  p2 = p[1]
  pn = p[2]
  t1 = tangent(pp, p1, p2)
  r = []
  for i in range(len(p)):
    t2 = tangent(p1, p2, pn)
    for c in h:
      px = p1[0] * c[0] + p2[0] * c[1] + K * t1[0] * c[2] + K * t2[0] * c[3]
      py = p1[1] * c[0] + p2[1] * c[1] + K * t1[1] * c[2] + K * t2[1] * c[3]
      r.append((px, py))
    t1 = t2
    pp, p1, p2, pn = p1, p2, pn, p[(i + 3) % len(p)]
  return r

class JumpForce:
  def __init__(self, F, t, b):
    self.b = b
    self.t = t
    self.F = F
    self.b.fJump = self

  def calc(self, dt):
    t = min(dt, self.t)

    for _ in self.b.masses:
      _.accumF(scale(self.F, t))

    self.t = self.t - t
    if self.t <= 0.0:
      self.b.fJump = None
      return False
    return True

class TorqueForce:
  def __init__(self, F, t, b):
    self.b = b
    self.t = t
    self.F = F
    self.b.fRotate = self

  def calc(self, dt):
    t = min(dt, self.t)

    C = self.b.centreOfMass()
    for _ in self.b.masses:
      try:
        d, l = unitl(sub(_.p, C))
      except ZeroDivisionError:
        continue
      F = (-d[1], d[0])
      _.accumF(scale(F, t * self.F))

    self.t = self.t - t
    if self.t <= 0.0:
      self.b.fRotate = None
      return False
    return True

class SlideForce:
  def __init__(self, F, t, b):
    self.b = b
    self.t = t
    self.F = F
    self.b.fSlide = self

  def calc(self, dt):
    t = min(dt, self.t)

    for _ in self.b.masses:
      if _.contact:
        F = (-_.contact.n[1], _.contact.n[0])
        _.accumF(scale(F, self.F * t))

    self.t = self.t - t
    if self.t <= 0.0:
      self.b.fSlide = None
      return False
    return True

class Blob(SpringMassSystem):
  N = 15
  def __init__(self, cx, cy):
    SpringMassSystem.__init__(self)
    N = self.N

    for i in range(N):
      self.masses.append(Mass())
      self.masses[-1].m = 0.1
      self.masses[-1].p = cx + 2.0 * cos(i * 2.0 * pi / N), cy + 2.0 * sin(i * 2.0 * pi / N)
    self.masses.append(Mass())
    self.masses[-1].m = 0.4
    self.masses[-1].p = cx, cy

    for i in range(N):
      j = (i + 1) % N
      k = (i + 2) % N
      l = (i + 7) % N
      dij = length(sub(self.masses[i].p, self.masses[j].p))
      dik = length(sub(self.masses[i].p, self.masses[k].p))
      dil = length(sub(self.masses[i].p, self.masses[l].p))
      dic = length(sub(self.masses[i].p, self.masses[N].p))

      self.forces.append(Spring(self.masses[i], self.masses[j], dij, 28.0, 0.3))
      self.forces.append(Spring(self.masses[i], self.masses[k], dik, 13.0, 0.4))
      self.forces.append(Spring(self.masses[i], self.masses[l], dil, 13.0, 0.4))
      self.forces.append(Spring(self.masses[i], self.masses[N], dic, 15.0, 0.6))
    self.constraints.append(KeepWithin(self.masses[N], self.masses[:N]))

    self.fJump = None
    self.fRotate = None
    self.fSlide = None

  def centreOfMass(self):
    Cx = Cy = 0.0
    m = 0.0
    for _ in self.masses:
      m = m + _.m
      Cx = Cx + _.p[0] * _.m
      Cy = Cy + _.p[1] * _.m
    return (Cx / m, Cy / m)

  def slide(self, dir):
    if self.fSlide:
      self.fSlide.t = 0.5
      self.fSlide.F = dir * 200.0
    else:
      self.forces.append(SlideForce(dir * 200.0, 0.5, self))

  def rotate(self):
    if self.fRotate:
      self.fRotate.t = 0.5
    else:
      self.forces.append(TorqueForce(200.0, 0.5, self))

  def jump(self):
    if self.fJump:
      return

    N = (0.0, 0.0)
    c = 0
    for i in self.masses:
      if i.contact:
        N = add(N, i.contact.n)
        c = c + 1
    if not c:
      return
    N = scale(N, +2000.0/c)
    self.forces.append(JumpForce(N, .05, self))
    pass

  def grow(self, ratio):
    for f in self.forces:
      if isinstance(f, Spring):
        f.l = f.l * ratio

  def draw(self, ctm, surf):
    points = splineLoop(surf, [ mult(CTM, m.p) for m in self.masses[:self.N] ])
    pygame.draw.polygon(surf, (230, 170, 80), points)
    pygame.draw.lines(surf, (0, 0, 0), 1, points, 4)

#     for m in self.masses:
#       pygame.draw.line(surf, (255,0,0), mult(CTM, m.p), mult(CTM, add(m.p, m.v)))
#       pygame.draw.line(surf, (0,0,255), mult(CTM, m.p), mult(CTM, add(m.p, m.F)))
#       pygame.draw.circle(surf, (255,255,0), mult(CTM, m.p), 4)
#     C = self.centreOfMass()
#     pygame.draw.circle(surf, (0,255,0), mult(CTM, C), 6)

def F(x): return int(floor(x + 0.5))
def SPAN(x0, x1): return x0 < x1 and (F(x0), F(x1)+1) or (F(x1), F(x0)+1)

class WorldHash:
  def crossings(self, p1, p2):
    s = {}
    if p1[1] < p2[1]:
      r_xa, r_ya = p1
      r_xb, r_yb = p2
    else:
      r_xa, r_ya = p2
      r_xb, r_yb = p1
    if r_ya == r_yb:
      y = F(r_ya)
      for x in range(*SPAN(r_xa, r_xb)):
        for _ in self.map[y - self.min_y][x - self.min_x]: s[_] = 1
    else:
      slope = float(r_xb - r_xa) / (r_yb - r_ya)
      for y in range(F(r_ya), F(r_yb) + 1):
        y0 = max(y - 0.5, r_ya)
        y1 = min(y + 0.5, r_yb)
        x0 = r_xa + slope * (y0 - r_ya)
        x1 = r_xa + slope * (y1 - r_ya)
        for x in range(*SPAN(r_xa, r_xb)):
          for _ in self.map[y - self.min_y][x - self.min_x]: s[_] = 1
    return s.keys()

  def addObject(self, o):
    spans = {}
    for i in range(o.edgeCount()):
      a, b  = o.edge(i)
      if a[1] < b[1]:
        r_xa, r_ya = a
        r_xb, r_yb = b
      else:
        r_xa, r_ya = b
        r_xb, r_yb = a
      if r_ya == r_yb:
        spans.setdefault(F(r_ya), []).append((SPAN(r_xa, r_xb), i, 0))
      else:
        slope = float(r_xb - r_xa) / (r_yb - r_ya)
        for y in range(F(r_ya), F(r_yb) + 1):
          C = 0
          y0 = max(y - 0.5, r_ya)
          y1 = min(y + 0.5, r_yb)
          if y0 == y - 0.5: C = C + 1
          if y1 == y + 0.5: C = C + 2
          x0 = r_xa + slope * (y0 - r_ya)
          x1 = r_xa + slope * (y1 - r_ya)
          spans.setdefault(y, []).append((SPAN(x0, x1), i, C))

    for y, spanlist in spans.iteritems():
      spanlist.sort()
      C = 0
      prev_x = self.min_x
      for span in spanlist:
        if prev_x < span[0][0] and C == 3:
          self.map[y - self.min_y][x - self.min_x].append((o, -1))
        C = C ^ span[2]
        for x in range(span[0][0], span[0][1]):
          self.map[y - self.min_y][x - self.min_x].append((o, span[1]))
        prev_x = max(prev_x, span[0][1])
      assert C == 0

  def __init__(self, bounds, objects):
    # each element of the map covers [x - 0.5, x + 0.5), [y - 0.5, y + 0.5)
    self.min_x = F(bounds[0][0])
    self.min_y = F(bounds[0][1])
    self.max_x = F(bounds[1][0])+1
    self.max_y = F(bounds[1][1])+1
    self.map = []
    for y in range(self.min_y, self.max_y):
      self.map.append([])
      for x in range(self.min_x, self.max_x):
        self.map[-1].append([])

    for o in objects:
      self.addObject(o)

class World:
  def __init__(self):
    self.objects = []
    self.collision_objects = []

    # o = Poly((-50, -50), (-15, -50), (-15, -10), (-50, +0))
    # self.objects.append(o)
    # self.collision_objects.append(o)

    # o = Poly((-13, -50), (+5, -50), (+5, -10), (-12, -13))
    # self.objects.append(o)
    # self.collision_objects.append(o)
    o = Poly((-50, -50), (+5, -50), (+5, -10), (-50, -10))
    self.objects.append(o)
    self.collision_objects.append(o)

    o = Poly((-50, +30), (+5, +30), (+5, +40), (-50, +40))
    self.objects.append(o)
    self.collision_objects.append(o)

    min_x = max_x = self.collision_objects[0].v[0][0]
    min_y = max_y = self.collision_objects[0].v[0][1]

    for o in self.collision_objects:
      for v in o.v:
        min_x = min(v[0], min_x)
        max_x = max(v[0], max_x)
        min_y = min(v[1], min_y)
        max_y = max(v[1], max_y)
    min_x = min_x - 5
    min_y = min_y - 5
    max_x = max_x + 5
    max_y = max_y + 5
    self.bounds = (min_x, min_y), (max_x, max_y)

    self.collision_objects.append(Poly((min_x, min_y),
                                       (min_x, max_y),
                                       (max_x, max_y),
                                       (max_x, min_y)))

    self.map = WorldHash(self.bounds, self.collision_objects)

    self.blob = Blob(-20.0, -5.0)

  def collide(self, p1, p2):
    C = []
    for o in self.collision_objects:
      c = o.crosses(p1, p2)
      if c is not None:
        C.append(c)
    if len(C):
      return min(C)

  def collide(self, p1, p2):
    C = []
    tests = self.map.crossings(p1, p2)

    for object, edge in tests:
      if edge == -1:
        continue
      a, b = object.edge(edge)
      i, ua, ub = intersection(a, b, p1, p2)
      if i is not None:
        C.append((ub, i, object, a, b))

    if len(C):
      return min(C)

  def update(self, dt):
    self.blob.calc(self, dt, GRAVITY)

class WorldView:
  def __init__(self, s, w):
    self.surface = s
    self.world = w
    self.pos = (0.0, -30.0)
    self.ang = 0.0
    self.zoom = 10.0
    self.mod = 0
    self.downkeys = {}
    self.delta_ang = 0.0
    self.dd_ang = 0.0
    self.revert_speed = 0.0
    self.swing_speed = 0.0

  def predisplay(self):
    dd = 0.0
    for k in self.downkeys.keys():
      if k == K_w: self.world.blob.grow(1.1)
      if k == K_s: self.world.blob.grow(1.0/1.1)
      if k == K_LEFT: dd = pi
      if k == K_RIGHT: dd = -pi
      if k == K_SPACE:
        self.world.blob.jump()
      if k == K_a:
        self.world.blob.slide(+1)
      if k == K_d:
        self.world.blob.slide(-1)

    if dd:
      self.ang = self.ang + self.swing_speed * (dd - self.ang)
      self.revert_speed = 0.0
      self.swing_speed = min(0.4, self.swing_speed + 0.005)
    else:
      self.ang = self.ang + self.revert_speed * (0.0 - self.ang)
      self.revert_speed = min(0.3, self.revert_speed + 0.002)
      self.swing_speed = max(0.0, self.swing_speed - 0.005)

    self.pos = add(self.pos, scale(sub(self.world.blob.masses[-1].p, self.pos), 0.3))
    global GRAVITY
    GRAVITY = (-sin(self.ang) * G, -cos(self.ang) * G)

    C = self.zoom * cos(self.ang)
    S = self.zoom * sin(self.ang)
    global CTM
    CTM = ((+C, -S, -C * self.pos[0] + S * self.pos[1] + SCREENRECT.centerx),
           (-S, -C, +S * self.pos[0] + C * self.pos[1] + SCREENRECT.centery))

    #self.surface.blit(BKG, (0, 0))
    self.surface.lock()
    self.surface.fill((60,80,120))
    pygame.draw.lines(self.surface, (40,50,60), 1, [ mult(CTM, self.world.bounds[0]), mult(CTM, (self.world.bounds[1][0], self.world.bounds[0][1])), mult(CTM, self.world.bounds[1]), mult(CTM, (self.world.bounds[0][0], self.world.bounds[1][1])) ])
    self.surface.unlock()

  def postdisplay(self):
    self.surface.lock()

    self.world.blob.draw(CTM, self.surface)

    for o in self.world.objects:
      o.draw(CTM, self.surface)

    self.surface.unlock()

  def keyDown(self, key, mod):
    self.mod = mod
    self.downkeys[key] = 1

  def keyUp(self, key, mod):
    self.mod = mod
    try:
      del self.downkeys[key]
    except:
      pass

  def mouseDown(self, pos, button):
    pass

  def mouseUp(self, pos, button):
    pass

  def mouseMove(self, pos, buttons):
    self.mouse_pos = pos

def run():
  pygame.init()

  winstyle = DOUBLEBUF
  bestdepth = pygame.display.mode_ok(SCREENRECT.size, winstyle, 32)
  screen = pygame.display.set_mode(SCREENRECT.size, winstyle, bestdepth)

  pygame.mouse.set_visible(0)

  clock = pygame.time.Clock()

  done = 0

  global WORLD, VIEW, SURF, BKG
  SURF = screen
  BKG = SURF.copy()
  BKG.fill((60,80,120))
  WORLD = World()
  VIEW = WorldView(screen, WORLD)
  FONT = pygame.font.SysFont("Arial", 24)

  while not done:
    step = clock.tick(600)

    for event in pygame.event.get():
      if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
        done = 1
        break
      if event.type == KEYDOWN:
        VIEW.keyDown(event.key, event.mod)
      if event.type == KEYUP:
        VIEW.keyUp(event.key, event.mod)
      if event.type == MOUSEBUTTONDOWN:
        VIEW.mouseDown(event.pos, event.button)
      if event.type == MOUSEBUTTONUP:
        VIEW.mouseUp(event.pos, event.button)
      if event.type == MOUSEMOTION:
        VIEW.mouseMove(event.pos, event.buttons)

    VIEW.predisplay()

    dt = min(step, 50) / 1000.0 / 2
    WORLD.update(dt)
    WORLD.update(dt)

    VIEW.postdisplay()

    surf = FONT.render("FPS: %d" % (int(clock.get_fps()),), 1, (255, 255,
    255), (0,0,0))
    screen.blit(surf, (0, 0))
    pygame.display.flip()

if __name__ == '__main__':
  if 0:
    import profile, sys
    p = profile.Profile()
    p.runcall(run)
    p.print_stats()
  else:
    run()

