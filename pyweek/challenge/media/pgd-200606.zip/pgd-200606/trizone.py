#!/usr/bin/python
"""
  Trizone,
   a slightly triangular game for one or two players cooperative.

  ---
  author: Jure Vrscaj <jure@codeshift.net>
  date: 2006-06-15
  license: public domain
  ---
  
  Inspiration: D-Zone, a shareware game from 1992, written by Julian Cochran
  
  == How to play ==

      Action | P1    | P2
  -----------------------
  accelerate | up    | w
       brake | down  | s
   turn left | left  | a
  turn right | right | d
  -----------------------

"""

import sys, os, re, copy, time
from math import sin,cos,radians,degrees,pi,atan2
from random import randint

import pygame
from pygame.locals import *
from pygame.constants import *
from pygame.draw import *

def debug(s):
    print s

# --- SETTINGS ---
SCR_W = 640
SCR_H = 480

# extra keys
K_LEFT_STRAFE = ord('n')
K_RIGHT_STRAFE = ord('m')

# control dict
CONTROL1 = {
#                    acc  rot  stf
    K_UP:           [  1,   0,   0],
    K_DOWN:         [ -1,   0,   0],
    K_LEFT:         [  0,  -1,   0],
    K_RIGHT:        [  0,   1,   0],
    K_LEFT_STRAFE:  [  0,   0,  -1],
    K_RIGHT_STRAFE: [  0,   0,   1],
}

CONTROL2 = {
#                    acc  rot  stf
    ord('w'):       [  1,   0,   0],
    ord('s'):       [ -1,   0,   0],
    ord('a'):       [  0,  -1,   0],
    ord('d'):       [  0,   1,   0],
    ord('q'):       [  0,   0,  -1],
    ord('e'):       [  0,   0,   1],
}

# dict for pressed keys
KEY = {}


# --- SUPPORT FUNCTIONS ---

# flatten - borrowed from google's goopy (http://goog-goopy.sourceforge.net/)
def flatten(seq):
  """
  Returns a list of the contents of seq with sublists and tuples "exploded".
  The resulting list does not contain any sequences, and all inner sequences
  are exploded.  For example:

  >>> flatten([7,(6,[5,4],3),2,1])
  [7,6,5,4,3,2,1]
  """
  lst = []
  for el in seq:
    if type(el) == list or type(el) is tuple:
      lst.extend(flatten(el))
    else:
      lst.append(el)
  return lst


# cyclic_pairs - also from goopy
def cyclic_pairs(lst):
  """cyclic_pairs(lst)

  Returns the cyclic pairs of LST as a list of 2-tuples.
  """

  n = len(lst)
  assert(n >= 2)
  cps = []
  for i in xrange(n - 1):
    cps.append((lst[i], lst[i + 1]))
  cps.append((lst[n - 1], lst[0]))
  return cps

# point_inside_polygon (http://www.ariel.com.au/a/python-point-int-poly.html)
def point_inside_polygon(p, poly, offset=[0,0,0,0]):
    """determine if a point is inside a given polygon or not
    Poly is a list of (x,y) pairs.
    Offset is a list of [dx1, dy1, dx2, dy2]
    """
    x = p[0] + offset[0]
    y = p[1] + offset[1]
    n = len(poly)
    inside = False

    p1x = poly[0][0] + offset[2]
    p1y = poly[0][1] + offset[3]
    for i in range(n+1):
        p2x = poly[i%n][0] + offset[2]
        p2y = poly[i%n][1] + offset[3]
        if y > min(p1y,p2y):
            if y <= max(p1y,p2y):
                if x <= max(p1x,p2x):
                    if p1y != p2y:
                        xinters = (y-p1y)*(p2x-p1x)/(p2y-p1y)+p1x
                    if p1x == p2x or x <= xinters:
                        inside = not inside
        p1x,p1y = p2x,p2y

    return inside

def ensure_abs_range(x, lim):
    if x>lim: x=lim
    elif x<-lim: x=-lim
    return x

def signum(x):
    if x<0: return -1
    elif x>0: return 1
    return 0

def air_resistance(x, k):
    return -signum(x) * min(k*x**2, abs(x))

def norm_degrees(a):
    a = a % 360
    if a>180:
        a-=360
    if a<-180:
        a+=360
    return a

# --- AI CLASSES ---

class DummyAI:
    def __init__(self, player):
        self.player = player
    def storm(self):
        """This function is called every loop cycle"""
        pass

class PlayerAI(DummyAI):
    def storm(self):
        _ = self.player
        for key in KEY:        
            acc, rot, stf = _.control.get(key, [0,0,0])
            _.speed += _.acc*acc
            _.turnspeed += _.turnacc*rot
            _.strafespeed += _.strafeacc*stf
        
class BaseSmartAI(DummyAI):
    def __init__(self, player):
        DummyAI.__init__(self, player)
        self.ctrl = [0,0,0]
        self.data = {}
        
    def check_zone(self):
        _ = self.player
        self.enemy_data = ed = {}
        target = self.data.get('target', players[0])
        
        for tri in players+[target]:
            angle = atan2(_.y-tri.y, _.x-tri.x) + pi
            distance = ( (_.y-tri.y)**2 + (_.x-tri.x)**2)**0.5
            ed[tri] = [degrees(angle), distance]
        
        if 'circle_position' in self.data:
            dx,dy = self.data['circle_position']
            x,y = target.x+dx, target.y+dy
            circ_ang = atan2(_.y-y, _.x-x) + pi
            circ_dist = ((_.y-y)**2 + (_.x-x)**2)**0.5
            ed['circle'] = [degrees(circ_ang), circ_dist]

        if 'target' not in self.data or not target.alive or randint(0,100) == 0:
            #target = players[0]
            #if ((not players[0].alive) or randint(0,1)==0) and players[1].alive:
            #    target = players[1]
            
            #if not target.alive:
            #    target = cars[randint(0, len(cars)-1)]
            
            newtarget = cars[randint(0, len(cars)-1)]
            if newtarget.alive and newtarget.color != _.color:
                newdistance = ( (_.y-newtarget.y)**2 + (_.x-newtarget.x)**2)**0.5
            	if not target.alive or newdistance < ed.get(target, [0,0])[1]:
                    self.data['target'] = newtarget
         
    def do_move(self):
        _ = self.player
        ed = self.enemy_data
        ang,dis = ed.get(target, [0,0])
        self.ctrl = [0, 1, 0]

    def apply(self):
        _ = self.player   

        acc, rot, stf = self.ctrl
        _.speed += _.acc*acc
        _.turnspeed += _.turnacc*rot
        _.strafespeed += _.strafeacc*stf

    def storm(self):
        self.check_zone()
        self.do_move()
        self.apply()
              
class SeekerAI(BaseSmartAI):
    """Search and destroy.
    """
    def do_move(self):
        _ = self.player
        ed = self.enemy_data
        target = self.data.get('target', players[0])
        ang,dis = ed.get(target, [0,0])
        
        self.data.setdefault('rot', 0)
        reflex = _.__dict__.get('reflex', 1)
        accuracy = _.__dict__.get('accuracy', 1)
        
        da = norm_degrees(_.dir - ang)
        if randint(0, int(1.0/reflex)) == 0:
            if abs(da) > _.turnacc*(1/accuracy):
                self.data['rot'] = -signum(da)
            else:
                self.data['rot'] = 0
        self.ctrl = [1, self.data['rot'], 0]

class CircleAI(SeekerAI):
    """Randomly choose a point somewhere around the target and follow it.
    """
    def do_move(self):
        _ = self.player    
        if not 'circle_position' in self.data or randint(0,600) == 0:
            a = randint(0,360)
            self.data['circle_position'] = [150*cos(radians(a)), 150*sin(radians(a))]
        
        ang,dis = self.enemy_data.get('circle', [0,0])
        acc,rot,stf = 1,0,0
        da = norm_degrees(_.dir - ang)
        if abs(da) > _.turnacc*3:
            rot = -signum(da)

        if dis<30:
            acc = 0
            
        self.ctrl = [acc, rot, stf]
        
        
         
    
# --- TRIANGLE CLASS ---

class Tri:
    """The class for each and every triangle that can appear in the game.
    """
    def __init__(self, d={}):            
        self.x,self.y,self.r = 100,100,30
        self.color = [150, 200, 160]
        self.control = CONTROL1
        self.ai = DummyAI
        
        self.acc = 1.5
        self.turnacc = 10
        self.strafeacc = 1.5

        self.speed = 0
        self.turnspeed = 0        
        self.strafespeed = 0
        self.dir = 0
        self.data = {
            'health': 100,
            'damage': 0,
        }
            
        self.__dict__.update(d)
        self.brain = self.ai(player=self)

        self.alive = False
        self.do_control()
        self.alive = True
    
    def do_control(self):
        # physics
        self.speed += air_resistance(self.speed, 0.05)
        self.turnspeed += air_resistance(self.turnspeed, 0.1)
        self.strafespeed += air_resistance(self.strafespeed, 0.1)

        # damage is reduced in time (the players have auto-repairing abilities)
        self.data['damage'] = self.data.get('damage',0) + air_resistance(self.data.get('damage',0), 0.001)
        
        # controls
        if self.alive:
            # this is the storm() function of the player's AI 
            self.brain.storm()
        
        # movements
        self.x += cos(radians(self.dir)) * self.speed
        self.y += sin(radians(self.dir)) * self.speed

        self.dir += self.turnspeed
        self.x += cos(radians(self.dir+90)) * self.strafespeed
        self.y += sin(radians(self.dir+90)) * self.strafespeed

        # compute triangle's points
        a,r = radians(self.dir),self.r
        da = 0.7*pi
        self.P = [
            (1.0 * cos(a+ 0) * r, 1.0 * sin(a+ 0) * r),
            (1.0 * cos(a+da) * r, 1.0 * sin(a+da) * r),
            (1.0 * cos(a-da) * r, 1.0 * sin(a-da) * r),
        ]

    def do_stuff(self):
        global SCORE
        if self.data.get('damage',0) > self.data.get('health',0) and self.alive:
            self.alive = False
            SCORE = SCORE + 1

        if not self.alive:
            return
        
        pip = False
        for tri in cars:
            if tri == self or not tri.alive:
                continue
            
            # death touch           
            if point_inside_polygon(self.P[0], tri.P, offset=[self.x, self.y, tri.x, tri.y]):
                pip = True
                self.data['deathtouch'] = pip
                
                # compute damage
                a1,a2 = radians(self.dir),radians(tri.dir)
                dx = 1.2*self.speed*cos(a1)-0.3*tri.speed*cos(a2)
                dy = 1.2*self.speed*sin(a1)-0.3*tri.speed*sin(a2)
                relspeed = (dx**2 + dy**2)**0.5

                damage = relspeed**2
                if self.ai == PlayerAI and tri.ai == PlayerAI and SCORE>0:
                    # friendly fire
                    damage /= 2
                
                tri.data['damage'] =  tri.data.get('damage', 0) + damage
                
                self.data['deathtouch_target'] = tri                

        self.data['deathtouch'] = pip
            
    def do_checks(self):
        global cars
        
        cars_new = []
        for tri in cars:
        
            # out of bounds
            delta = 15
            if tri.x<-delta: tri.x+=(SCR_W+delta*2)
            if tri.x>SCR_W+delta: tri.x-=(SCR_W+delta*2)
            if tri.y<-delta: tri.y+=(SCR_H+delta*2)
            if tri.y>SCR_H+delta: tri.y-=(SCR_H+delta*2)
        
            # filter out dead triangles
            if tri.alive or tri.data.get('damage',0) > 5:
                cars_new.append(tri)
        
        cars = cars_new
        
        
    def do_draw(self, clear=False):
        x,y,r,a = self.x,self.y,self.r,radians(self.dir)
        
        clr = self.color
        w = getattr(self, 'w', 3)
        if clear:
            clr = [0,0,0]
        
        if not self.alive:
            return
    
        # smoke
        for L in cyclic_pairs(self.P):
            dx1,dy1,dx2,dy2 = flatten(L)
            smoke_color = [abs(int(self.speed))*10 + 10]*3
            circle(screen, smoke_color, [int(x+dx1), int(y+dy1)], randint(3,5), 1)

        # deathtouch
        if self.data.get('deathtouch') or getattr(self.data.get('deathtouch_target'), 'alive', None) == False:
            dx,dy = self.P[0]
            target = self.data['deathtouch_target']
            dmg = int(target.data.get('damage',0)/3)
            circle(screen, [0,0,0], [int(x+dx), int(y+dy)], dmg+4, min(dmg+4, 4))
            circle(screen, target.color, [int(x+dx), int(y+dy)], dmg, min(dmg, 5))

        # triangle
        for L in cyclic_pairs(self.P):
            dx1,dy1,dx2,dy2 = flatten(L)
            line(screen, clr, [x+dx1, y+dy1], [x+dx2, y+dy2], w)
                    

# --- ENEMIES ---
seeker_dict = {
            'color': [200, 160, 150],
            'data': {'health': 100},
            
            'control': None,
            'ai': SeekerAI,
            'x': 100,
            'y': 200,
            
            'acc': 1.0,
            'turnacc': 3,

            'reflex': 0.1,
            'accuracy': 0.1,
            
}

circle_dict = seeker_dict.copy()
circle_dict.update({
            'ai': CircleAI,
            'color': [200, 160, 150],
            'data': {'health': 100},
            'acc': 1.0,
            'turnacc': 3,
            'reflex': 0.1,
            'accuracy': 0.1,
})

destroyer_dict = seeker_dict.copy()
destroyer_dict.update({
            'ai': SeekerAI,
            'color': [60, 120, 180],
            'data': {'health': 150},
            'w': 4,
            'acc': 1.5,
            'turnacc': 3,
            'reflex': 0.3,
            'accuracy': 0.2,
})

kamikaze_dict = seeker_dict.copy()
kamikaze_dict.update({
            'ai': SeekerAI,
            'r': 20,
            'color': [250, 250, 100],
            'data': {'health': 50},
            'acc': 3.0,
            'turnacc': 3,
            'reflex': 0.01,
            'accuracy': 0.05,
})
uber_kamikaze_dict = seeker_dict.copy()
uber_kamikaze_dict.update({
            'ai': SeekerAI,
            'r': 15,
            'color': [250, 250, 250],
            'data': {'health': 50},
            'acc': 4.0,
            'turnacc': 1,
            'reflex': 0.5,
            'accuracy': 0.5,
})


def spawn_enemy():
    global cars, SCORE
    
    x = randint(0,SCR_W)
    y = randint(0,SCR_H)
    
    tmp = randint(0,3)
    if tmp == 0:
        x = -10
    elif tmp == 1:
        x = SCR_W+10
    elif tmp == 2:
        y = -10
    elif tmp == 3:
        y = SCR_H+10

    select = seeker_dict
    if randint(0,5) == 0:
        select = circle_dict
    if SCORE > 10 and randint(0,100) < SCORE:
        select = destroyer_dict
    if SCORE > 20 and randint(0,10) == 0:
        select = kamikaze_dict
    if SCORE > 50 and randint(0,10) == 0:
        select = uber_kamikaze_dict
    
    d = copy.deepcopy(select)
    d.update({
        'x': x,
        'y': y,
    })
    tri = Tri(d)
    cars += [tri]


def handle_keyboard():
    global KEY
        
    for event in pygame.event.get():
        if event.type in (KEYDOWN, KEYUP):
            if event.key == 27:
                sys.exit()
            if event.key == K_F1:
                print cars[0].__dict__
                
            KEY[event.key] = True
            if event.type == KEYUP:
                del KEY[event.key]
  
                
def loop(): 
    # draw background
    #rect(screen, [0, 0, 0], [tri.x-tri.r,tri.y-tri.r,tri.r*2,tri.r*2], 0)

    if randint(0,60) == 0:
        spawn_enemy()

    for tri in cars:
        tri.do_draw(clear=True)

    clock.tick(60)

    handle_keyboard()
    
    for tri in cars:
        tri.do_control()
        tri.do_stuff()
        tri.do_checks()
        tri.do_draw()

    """
    # HUD (disabled) - some people reported font problems...
    font = pygame.font.Font(None, 15)
    text = "damage: %d:%d  score: %d  "%(players[0].data.get('damage', 0), players[1].data.get('damage', 0), SCORE)
    ren = font.render(text, 0, [255,255,255], [0,0,0])
    screen.blit(ren, (10, 10))
    """

    # ...write score in window title instead
    pygame.display.set_caption("score: %d" % SCORE)
    pygame.display.update()


# this is the list of all cars aka triangles
cars = []

# add player 1 and 2
cars += [
    Tri(
        {
            'color': [120, 180, 120],
            'control': CONTROL1,
            'ai': PlayerAI,
            'acc': 2.1,
            'x': SCR_W/2+30,
            'y': SCR_H/2,
            'w': 4,
            'dir': -90,
            'data': {'health': 150},
        }
    ),
    Tri(
        {
            'color': [120, 180, 120],
            'control': CONTROL2,
            'ai': PlayerAI,
            'acc': 2.1,
            'x': SCR_W/2-30,
            'y': SCR_H/2,
            'w': 4,
            'dir': 90,
            'data': {'health': 150},
            
        }
    ),
]
players = [cars[0], cars[1]]

while 1:
    print
    print "Number of players ['1', '2', 'info']: ",
    s = sys.stdin.readline().strip()
    if s == '1':
        players[1].alive = False
        break
    elif s == '2':
        break
    elif 'i' in s:
        for ss in __doc__.split('\n'):
            print ss
            time.sleep(0.1)

screen = pygame.display.set_mode([SCR_W, SCR_H], {True: FULLSCREEN}.get('fullscreen' in sys.argv, 0))
pygame.init()

SCORE = 0    
clock = pygame.time.Clock()
while 1:
    loop()
    
    
    
