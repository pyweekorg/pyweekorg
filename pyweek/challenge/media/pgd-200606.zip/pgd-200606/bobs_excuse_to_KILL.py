#!/usr/bin/python

# This code ranges from poorly structured to very poorly structured. I'm sorry,
# but I didn't know Python before I started writing this game. If I were to
# rewrite this game right now, most of the current code would be either scrapped
# or refactored. But since I got the events working, this is not going to happen
# anytime soon. =)
#
# This game is licensed under the GNU GPL v2. The license can be obtained at
# http://www.gnu.org/licenses/gpl.txt
#
# -Shundread

print "Initializing game."

print "- Loading pygame libraries."

import pygame
from pygame.locals import *

## Graphic Unit ##

print "- Starting game internal graphic library."

# Some important colors
nocolor = (255,0,255)
black = (0,0,0)
blue = (110,110,255)
brown = (178,178,0)
cyan = (180,180,255)
red = (255,60,60)
green = (0,255,0)
pink = (255,0,200)
white = (255,255,255)
yellow = (255,255,0)
gray = (175,175,175)

def mix_colors(c1, c2):
    return ((c1[0]*c2[0])/255, (c1[1]*c2[1])/255, (c1[2]*c1[2])/255)

# Basic shapes
class circle:
    def __init__(self, x, y, rad, color):
        self.x, self.y, self.rad, self.color = x, y, rad, color

    def draw(self, surface, x, y):
        pygame.draw.circle(surface, self.color,
          (self.x + x, self.y + y),self.rad)

class ellipse:
    def __init__(self, x, y, w, h, color):
        self.x, self.y, self.w, self.h, self.color = x, y, w, h, color

    def draw(self, surface, x, y):
        pygame.draw.ellipse(surface, self.color,
          ((self.x + x, self.y + y),(self.w, self.h)))

class lines:
    def __init__(self, x, y, plist, color):
        self.x, self.y, self.plist, self.color = x, y, plist, color
    def draw(self, surface, x, y):
        p = []
        for point in self.plist:
            p.append((self.x + point[0] + x, self.y + point[1] + y))
        pygame.draw.lines(surface, self.color, 0, p)

class poly:
    def __init__(self, x, y, plist, color, o=0):
        self.x, self.y, self.plist, self.color, self.o = x, y, plist, color, o
    def draw(self, surface, x, y):
        p = []
        for point in self.plist:
            p.append((self.x + point[0] + x, self.y + point[1] + y))
        pygame.draw.polygon(surface, self.color, p)
        if(self.o == 1):
            outline = (self.color[0]/3,self.color[1]/3,self.color[2]/3)
            pygame.draw.lines(surface, outline, True, p)
        if(self.o == 2):
            outline = (self.color[0]/3,self.color[1]/3,self.color[2]/3)
            pygame.draw.lines(surface, outline, True, p)

class rect:
    def __init__(self, x, y, w, h, color):
        self.x, self.y, self.w, self.h, self.color = x, y, w, h, color

    def draw(self, surface, x, y):
        pygame.draw.rect(surface, self.color,
          ((self.x + x, self.y + y),(self.w, self.h)))

# Drawing complex shapes
def drawShape(surface, image, x, y):
    for shape in image:
        shape.draw(surface, x, y)

# "Loading" images from shape information.
def loadImage(shape, x, y):
    result = pygame.Surface((x,y))
    result.set_colorkey(nocolor)
    pygame.draw.rect(result, nocolor, ((0,0),(x,y)))
    drawShape(result, shape, 0, 0)
    return result

# Printable characters
alphabet = {
  "a":
  lambda c: [
    lines(0,0,[(0,14),(5,0),(10,14)],c),
    lines(0,0,[(2,8),(8,8)],c)
  ],
  "b":
  lambda c: [
    lines(0,0,[(0,0),(7,0),(10,3),(6,7),(10,11),(7,14),(0,14),(0,0)],c)
  ],
  "c":
  lambda c: [
    lines(0,0,[(10,0),(3,0),(0,5),(0,9),(3,14),(10,14)],c)
  ],
  "d":
  lambda c: [
    lines(0,0,[(0,0),(6,0),(10,6),(10,9),(6,14),(0,14),(0,0)],c)
  ],
  "e":
  lambda c: [
    lines(0,0,[(10,0),(0,0),(0,14),(10,14)],c),
    lines(0,0,[(0,7),(10,7)],c)
  ],
  "f":
  lambda c: [
    lines(0,0,[(10,0),(0,0),(0,14)],c),
    lines(0,0,[(0,7),(10,7)],c)
  ],
  "g":
  lambda c: [
    lines(0,0,[(10,0),(3,0),(0,5),(0,9),(3,14),(10,14),(10,7),(6,7)],c)
  ],
  "h":
  lambda c: [
    lines(0,0,[(0,0),(0,6),(10,6),(10,0)],c),
    lines(0,0,[(0,14),(0,6),(10,6),(10,14)],c)
  ],
  "i":
  lambda c: [
    lines(0,0,[(3,0),(8,0)],c),
    lines(0,0,[(5,0),(5,14)],c),
    lines(0,0,[(3,14),(8,14)],c),
  ],
  "j":
  lambda c: [
    lines(0,0,[(10,0),(10,9),(7,14),(4,14),(0,7)],c)
  ],
  "k":
  lambda c: [
    lines(0,0,[(0,0),(0,14)],c),
    lines(0,0,[(10,0),(0,7),(10,14)],c)
  ],
  "l":
  lambda c: [
    lines(0,0,[(0,0),(0,14),(10,14)],c)
  ],
  "m":
  lambda c: [
    lines(0,0,[(0,14),(0,0),(5,7),(10,0),(10,14)],c)
  ],
  "n":
  lambda c: [
    lines(0,0,[(0,14),(0,0),(10,14),(10,0)],c)
  ],
  "o":
  lambda c: [
    lines(0,0,[(3,0),(0,4),(0,10),(3,14),(7,14),(10,10),(10,4),(7,0),(3,0)],c)
  ],
  "p":
  lambda c: [
    lines(0,0,[(0,7),(10,7),(10,0),(0,0),(0,14)],c)
  ],
  "q":
  lambda c: [
    lines(0,0,[(3,0),(0,4),(0,10),(3,14),(7,14),(10,10),(10,4),(7,0),(3,0)],c),
    lines(0,0,[(5,7),(10,14)],c)
  ],
  "r":
  lambda c: [
    lines(0,0,[(10,14),(0,6),(9,6),(9,0),(0,0),(0,14)],c),
  ],
  "s":
  lambda c: [
    lines(0,0,[(10,0),(4,0),(0,3),(4,6),(7,6),(10,10),(7,14),(0,14)],c)
  ],
  "t":
  lambda c: [
    lines(0,0,[(0,0),(10,0)],c),
    lines(0,0,[(5,0),(5,14)],c)
  ],
  "u":
  lambda c: [
    lines(0,0,[(0,0),(0,9),(3,14),(7,14),(10,9),(10,0)],c)
  ],
  "v":
  lambda c: [
    lines(0,0,[(0,0),(5,14),(10,0)],c)
  ],
  "w":
  lambda c: [
    lines(0,0,[(0,0),(3,14),(5,7),(8,14),(10,0)],c)
  ],
  "x":
  lambda c: [
    lines(0,0,[(0,0),(10,14)],c),
    lines(0,0,[(10,0),(0,14)],c)
  ],
  "y":
  lambda c: [
    lines(0,0,[(0,0),(5,7),(10,0)],c),
    lines(0,0,[(5,7),(5,14)],c)
  ],
  "z":
  lambda c: [
    lines(0,0,[(0,0),(10,0),(0,14),(10,14)],c)
  ],
  "K":
  lambda c: [
    lines(0,0,[(0,0),(0,14)],mix_colors(red, c)),
    lines(0,0,[(10,0),(0,7),(10,14)],mix_colors(red, c)),
    lines(0,1,[(0,0),(0,14)],mix_colors(red, c)),
    lines(0,1,[(10,0),(0,7),(10,14)],mix_colors(red, c)),
    lines(1,0,[(0,0),(0,14)],mix_colors(red, c)),
    lines(1,0,[(10,0),(0,7),(10,14)],mix_colors(red, c))
  ],
  "I":
  lambda c: [
    lines(0,0,[(3,0),(8,0)],mix_colors(red, c)),
    lines(0,0,[(5,0),(5,14)],mix_colors(red, c)),
    lines(0,0,[(3,14),(8,14)],mix_colors(red, c)),
    lines(0,1,[(3,0),(8,0)],mix_colors(red, c)),
    lines(0,1,[(5,0),(5,14)],mix_colors(red, c)),
    lines(0,1,[(3,14),(8,14)],mix_colors(red, c)),
    lines(1,0,[(3,0),(8,0)],mix_colors(red, c)),
    lines(1,0,[(5,0),(5,14)],mix_colors(red, c)),
    lines(1,0,[(3,14),(8,14)],mix_colors(red, c))
  ],
  "L":
  lambda c: [
    lines(0,0,[(0,0),(0,14),(10,14)],mix_colors(red, c)),
    lines(0,1,[(0,0),(0,14),(10,14)],mix_colors(red, c)),
    lines(1,0,[(0,0),(0,14),(10,14)],mix_colors(red, c))
  ],
  " ":
  lambda c: [],
  ",":
  lambda c: [
    poly(0,0,[(0,14),(3,14),(7,8),(3,8),(4,11)],c),
  ],
  "'":
  lambda c: [
    poly(0,0,[(0,6),(3,6),(7,0),(3,0),(4,3)],c),
  ],
  ".":
  lambda c: [
    circle(5,12,2,c)
  ],
  ":":
  lambda c: [
    circle(5,4,2,c),
    circle(5,11,2,c)
  ],
  "!":
  lambda c: [
    rect(4,0,2,8,c),
    circle(5,12,2,c)
  ],
  "?":
  lambda c: [
    lines(0,0,[(0,4),(3,0),(8,0),(10,3),(10,5),(7,7),(7,9)],c),
    circle(7,13,1,c)
  ],
  "-":
  lambda c: [
    lines(0,0,[(2,5),(8,5)],c)
  ],
  "1":
  lambda c: [
    lines(0,0,[(3,2),(5,0),(5,14)],c)
  ],
  "2":
  lambda c: [
    lines(0,0,[(0,3),(3,0),(7,0),(10,3),(10,5),(0,14),(10,14)],c)
  ],
  "3":
  lambda c: [
    lines(0,0,[(0,0),(7,0),(10,3),(8,5),(4,7),(8,9),(10,11),(7,14),(0,14)],c)
  ],
  "4":
  lambda c: [
    lines(0,0,[(10,7),(0,7),(7,0),(7,14)],c)
  ],
  "5":
  lambda c: [
  lines(0,0,[(10,0),(0,0),(0,5),(5,5),(7,6),(9,8),(10,10),(10,12),(9,13),(5,14),
       (0,14)],c)
  ],
  "6":
  lambda c: [
    lines(0,0,[(10,0),(3,0),(0,3),(0,11),(3,14),(7,14),(10,11),(10,8),(7,5),
         (3,5),(0,8)],c)
  ],
  "7":
  lambda c: [
    lines(0,0,[(0,0),(10,0),(7,4),(5,14)],c)
  ],
  "8":
  lambda c: [
    lines(0,0,[(3,0),(0,3),(0,5),(3,7),(7,7),(10,10),(10,12),(7,14),(3,14),
         (0,12),(0,10),(10,5),(10,3),(7,0),(3,0)],c)
  ],
  "9":
  lambda c: [
    lines(0,0,[(0,14),(7,14),(10,11),(10,3),(7,0),(3,0),(0,3),(0,5),(3,8),
         (7,8),(10,5)],c)
  ],
  "0":
  lambda c: [
    lines(0,0,[(3,0),(0,4),(0,10),(3,14),(7,14),(10,10),(10,4),(7,0),(3,0)],c),
    lines(0,0,[(2,1),(8,13)],c)
  ],
}

# Writing text
centerText = -1

def drawText(surface, lines, xpos=5, ypos=485, color=white):
    y = ypos
    for l in lines:
        if xpos == centerText:
            x = surface.get_width()/2 - (15*len(l))/2
        else:
            x = xpos
        for c in l:
            drawShape(surface, alphabet[c](color), x, y)
            x = x + 15
        y = y + 20

def talk(surface, lines, options=0):
    drawText(surface, lines)
    pygame.display.flip()
    pygame.event.get([KEYUP,KEYDOWN])
    while True:
        if check_quit():
            return -1
        keys = pygame.event.get([KEYDOWN])
        if(options == 0):
            for k in keys:
                if k.dict['key'] == K_RETURN:
                    surface.fill(black, ((0,480),
                        (surface.get_width(), surface.get_height()-480)))
                    return 0
        else:
            for k in keys:
                if k.dict['key'] == K_1:
                    surface.fill(black, ((0,480),
                        (surface.get_width(), surface.get_height()-480)))
                    return 1
                if k.dict['key'] == K_2:
                    surface.fill(black, ((0,480),
                        (surface.get_width(), surface.get_height()-480)))
                    return 2
                if k.dict['key'] == K_3:
                    if options == 3:
                        surface.fill(black, ((0,480),
                            (surface.get_width(), surface.get_height()-480)))
                        return 3
        check_redraw()
        pygame.time.wait(50)

# Graphics for characters
def face1(c):
    return [
        poly(0,0,[(0,2),(2,2),(2,0),(19,0),(19,2),(21,2),(21,27),(19,27),
            (19,29),(2,29),(2,27),(0,27)],c,2),
        rect(4,8,2,6,black),
        rect(16,8,2,6,black),
        rect(4,18,14,2,black),
        rect(6,20,10,2,black),
        rect(8,22,6,2,black)
    ]

def face2(c):
    return [
        poly(0,0,[(0,2),(2,2),(2,0),(19,0),(19,2),(21,2),(21,27),(19,27),
            (19,29),(2,29),(2,27),(0,27)],c,2),
        rect(4,8,2,6,black),
        rect(14,8,6,6,(c[0]/2,c[1]/2,c[2]/2)),
        rect(16,10,2,2,black),
        rect(8,18,6,2,black),
        rect(6,20,10,2,black),
        rect(4,22,14,2,black)
    ]

def face3(c):
    return [
        poly(0,0,[(0,2),(2,2),(2,0),(19,0),(19,2),(21,2),(21,27),(19,27),
            (19,29),(2,29),(2,27),(0,27)],c,2),
        rect(4,8,2,6,black),
        rect(16,8,2,6,black),
        rect(8,18,6,2,black),
        rect(6,20,10,2,black),
        rect(4,22,14,2,black)
    ]

### Scenarios ###

print "- Loading scenario information."

# Scenario information
class scenarioData:
    def __init__(self):
        self.events, self.areaMap, self.image = None, None, None

    def setData(self, events, areaMap, image):
        self.events, self.areaMap, self.image = events, areaMap, image

city = scenarioData()
bobsHouse = scenarioData()
ronsHouse = scenarioData()
vonsHouse = scenarioData()
hotel = scenarioData()

## Maps ##

print "  - Loading scenario maps."

cityMap = [
    "....................",
    "...@@@@.............",
    "...@B@@.............",
    "...........@@@@@@.p.",
    "...........@@H@@@...",
    "....................",
    ".@@@@@..............",
    ".@@R@@..k...........",
    "....................",
    "....................",
    "..............t.....",
    ".....@@@...wwwwwww..",
    ".....@V@...wwwwwww..",
    "...........wwww.....",
    "....................",
]

bobsHouseMap = [
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@b...........@@@@",
    "@@@@............@@@@",
    "@@@@............@@@@",
    "@@@@............@@@@",
    "@@@@............@@@@",
    "@@@@............@@@@",
    "@@@@............@@@@",
    "@@@@............@@@@",
    "@@@@@@@@@@@@E@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
]

ronsHouseMap = [
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "........@...r...@.t.",
    "........@.......@...",
    "........@.......@...",
    "........@@@@.@@@@@.@",
    "........@...........",
    "........@...........",
    "....................",
    "........@...........",
    "........@...........",
    "@@@@@@@@@@@@E@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
]

vonsHouseMap = [
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@........@@@@@@@@",
    "@@@@........@@@@@@@@",
    "@@@@...v....@@@@@@@@",
    "@@@@........@@@@@@@@",
    "@@@@........@@@@@@@@",
    "@@@@@@@@E@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
]

hotelMap = [
    "@@@@@@@@@@@@@@@@@@@@",
    "@.....@.....@....B@@",
    "@.....@.....@.....@@",
    "@..d..@.....@.....@@",
    "@.....@.....@.....@@",
    "@@@.@@@@@.@@@@@.@@@@",
    "@.................@@",
    "@.................@@",
    "@@@.@@@@@.@@@.....@@",
    "@.....@.....@.....@@",
    "@.....@.....@....m@@",
    "@.....@.....@.....@@",
    "@.....@....b@.....@@",
    "@@@@@@@@@@@@@@@E@@@@",
    "@@@@@@@@@@@@@@@@@@@@",
]

print "  - Building scenario graphics."

# Graphics for the main city
def house(x,y,w,c1,c2):
    l = w*24
    d = ((w-1)/2)*24
    return [
        poly(x*24,y*32,[(4,10),(4,63),(l-10,63),(l-10,10)],c1,1),
        poly(x*24,y*32,[(l-10,10),(l-10,63),(l-3,54),(l-3,3)],c2,1),
        poly(x*24,y*32,[(4,0),(0,10),(l-8,10),(l,2),(l-5,0)],(214,79,79),1),
        poly(x*24,y*32,[(l-8,10),(l,2),(l-5,0)],(205,26,26),1),
        rect(x*24+d,(y+1)*32,24,32,black),
    ]

def grass(x,y):
    return [
        lines(x,y,[(11,15),(4,9),(0,9)],(2,85,2)),
        lines(x,y,[(11,15),(9,8),(3,4)],(2,85,2)),
        lines(x,y,[(11,15),(12,5),(8,0)],(2,85,2)),
        lines(x,y,[(11,15),(15,8),(21,5)],(2,85,2)),
    ]

def grass2(x,y):
    return [
        lines(x,y,[(8,14),(3,12),(0,13)],(2,85,2)),
        lines(x,y,[(8,14),(4,7),(0,5)],(2,85,2)),
        lines(x,y,[(8,14),(11,0),(15,1)],(2,85,2)),
        lines(x,y,[(8,14),(15,8),(19,9)],(2,85,2)),
    ]

def grassLine(x,y,w):
    result = []
    for k in range(0,w):
        result.extend(grass(x+5*k+(4*(x+y+k)%5),y+(7*(x+y+k)%11)))
        result.extend(grass2(x+5*k+(7*(x+y+k)%11),y+(8*(x+y+k)%13)))
    return result

cityShape = [
    rect(0,0,480,480,(60,138,60)),
    poly(0,0,[(100,113),(101,156),(138,165),(161,184),(162,226),(158,266),
        (113,285),(94,268),(75,277),(104,304),(125,309),(155,297),(181,296),
        (212,312),(226,368),(206,422),(172,432),(146,426),(128,442),(167,455),
        (197,453),(233,436),(248,382),(238,311),(270,248),(319,210),(303,191),
        (264,215),(244,244),(222,284),(187,266),(187,226),(186,188),(177,162),
        (152,141),(125,135),(119,115)],(246,234,111),1),
    poly(0,0,[(280,347),(261,386),(270,438),(340,446),(361,424),(435,411),
        (429,351),(382,348),(320,362)],(136,26,226),1),
]

cityShape.extend(house(3,1,4,(216,204,162),(193,176,122)))
cityShape.extend(house(1,6,5,(189,229,228),(133,197,195)))
cityShape.extend(house(5,11,3,(174,174,160),(140,141,114)))
cityShape.extend(house(11,3,6,(244,238,238),(226,214,214)))
cityShape.extend(grassLine(10,110,10))
cityShape.extend(grassLine(10,125,11))
cityShape.extend(grassLine(206,15,43))
cityShape.extend(grassLine(230,28,38))
cityShape.extend(grassLine(240,41,40))
cityShape.extend(grassLine(300,54,20))
cityShape.extend(grassLine(32,361,8))
cityShape.extend(grassLine(27,374,10))
cityShape.extend(grassLine(20,387,13))
cityShape.extend(grassLine(26,400,11))
cityShape.extend(grassLine(20,413,8))
cityShape.extend(grassLine(24,426,4))
cityShape.extend(grassLine(350,425,18))
cityShape.extend(grassLine(340,438,18))

cityImage = loadImage(cityShape, 480, 480)
del cityShape

# Graphics for buildings

def pattern(tile, shape_w, shape_h, xpos, ypos, w, h):
    result = []
    for x in range(0, w):
        for y in range(0, h):
            result.extend(tile(xpos + x*shape_w, ypos + y*shape_h))
    return result

def tile1(x, y):
    return [
        rect(x,y,32,32,(120,90,52)),
        rect(x,y+4,32,4,(138,98,63)),
        rect(x,y+12,32,4,(129,101,61)),
        rect(x,y+20,32,4,(134,103,64)),
        rect(x,y+28,32,4,(136,100,60)),
        rect(x,y,17,4,(110,90,75)),
        rect(x+12,y+8,15,4,(120,96,75)),
        rect(x+3,y+16,15,4,(114,90,65)),
        rect(x+14,y+24,18,4,(124,96,75)),
        rect(x+7,y+4,17,4,(121,97,67)),
        rect(x+16,y+12,16,4,(121,97,67)),
        rect(x+13,y+20,15,4,(127,100,63)),
        rect(x+7,y+28,14,4,(111,97,77)),
    ]

boxShape = [
    poly(0,0,[(5,0),(0,5),(0,24),(23,24),(23,5),(18,0)],(207,182,149),2),
    lines(0,0,[(3,3),(21,3)],(137,112,79)),
    lines(0,0,[(19,3),(18,7)],(137,112,79)),
    lines(0,0,[(0,6),(23,7)],(137,112,79)),
    lines(0,0,[(6,6),(6,10)],(137,112,79)),
    lines(0,0,[(0,10),(23,9)],(137,112,79)),
    lines(0,0,[(0,16),(23,17)],(137,112,79)),
    lines(0,0,[(14,16),(14,20)],(137,112,79)),
    lines(0,0,[(0,20),(23,20)],(137,112,79)),
    lines(0,0,[(0,13),(23,13)],(87,62,29)),
    ellipse(9,12,4,6,(87,62,29))
]

toilet = [
    poly(0,0,[(5,2),(18,2),(18,28),(5,28)],(230,230,230),2),
    poly(0,0,[(3,0),(16,0),(18,2),(5,2),(5,28),(3,26)],(180,180,180),2),
    lines(0,0,[(3,0),(5,2)],(60,60,60)),
    poly(0,0,[(6,16),(6,10),(9,7),(17,7),(19,10),(19,16)],white,2),
    poly(0,0,[(5,17),(18,17),(21,19),(18,23),(9,23),(5,20)],(240,240,240),2),
    poly(0,0,[(8,17),(17,17),(17,19),(15,21),(12,21),(8,19)],blue,1)
]

def fillWall(mapArg):
    result = []
    for x in range(0,20):
        for y in range(0,15):
            if(mapArg[y][x]=="@"):
                result.append(rect(x*24,y*32,24,32,nocolor))
    return result
    

bobsHouseShape = []
bobsHouseShape.extend(pattern(tile1, 32, 32, 96, 64, 9, 8))
bobsHouseShape.extend(tile1(284, 320))

bobsHouseImage = loadImage(bobsHouseShape, 480, 480)
del bobsHouseShape

ronsHouseShape = []
ronsHouseShape.extend(pattern(tile1, 32, 32, 0, 64, 15, 9))
ronsHouseShape.extend(tile1(284, 352))
ronsHouseShape.extend(fillWall(ronsHouseMap))

ronsHouseImage = loadImage(ronsHouseShape, 480, 480)
del ronsHouseShape

vonsHouseShape = []
vonsHouseShape.extend(pattern(tile1, 32, 32, 96, 128, 6, 5))
vonsHouseShape.extend(tile1(188, 288))

vonsHouseImage = loadImage(vonsHouseShape, 480, 480)
del vonsHouseShape

hotelShape = []
hotelShape.extend(pattern(tile1, 32, 32, 0, 0, 15, 15))
hotelShape.extend(fillWall(hotelMap))

hotelImage = loadImage(hotelShape,480,480)
del hotelShape

## Events ##

print "  - Loading scenario events."

# Event actions

# Use this if nothing is happening.
def doNothing(screen):
    pass

# Builds a teleporter
def teleport(scenario, x, y):
    def f(screen):
        player.scenario = scenario
        player.pos[0] = x
        player.pos[1] = y
        draw_game_screen(screen)
    return f

# First event of the game. Gives the player an idea of the greatness of the
# storyline.
def firstEvent(screen):
    talk(screen, [
        "this is horia, a very peaceful town where",
        "no one wants to harm other people. today is",
        "going to be a different day, however..."])
    talk(screen, ["bob: what a wonderful day to KILL someone!"])

# Bob's box event
def box1Event(screen):
    if player.actions["box"]["found money"] == 0:
        player.actions["box"]["found money"] = 1
        talk(screen, ["bob: oh yeah, i forgot i had a few bucks",
            "bucks stored in this box."])
        talk(screen, ["you got 10 bucks."])
        player.bucks+=10
        draw_game_screen(screen)
        return
    talk(screen, ["bob: there is nothing left here."])

# Tim's box event
def box2Event(screen):
    if player.actions["box"]["found leg"] == 1:
        talk(screen, ["bob: there's nothing left in the box."])
        return

    if player.actions["tim"]["leg"] == 1:
        talk(screen, ["bob: here is the creepy man's leg..."])
        talk(screen, ["you got a leg."])
        player.inventory.append("leg")
        draw_game_screen(screen)
        player.actions["box"]["found leg"] = 1
        return

    talk(screen, ["bob: what the f... there's a leg in here!"])

# Empty box event
def box3Event(screen):
    talk(screen, ["bob: this box is empty."])

# Weapons dealer's event
def dealerEvent(screen):
    if player.inventory.count("knife") > 0:
        knifeEnding(screen, "dealer")
        return

    if player.inventory.count("machine gun") > 0:
        machineGunEnding(screen, "dealer")
        return

    if player.actions["dealer"]["password"] < 2:
        talk(screen, ["man: what's the password?"])

    if player.actions["dealer"]["password"] == 1:
        talk(screen, ["bob: 'i want to KILL'."])
        talk(screen, ["dealer: correct!"])
        player.actions["dealer"]["password"] = 2

    if player.actions["dealer"]["password"] == 2:
        talk(screen, ["dealer: so, are you interested in any",
            "of my weapons?"])
        result = talk(screen, ["1: knife, 20 bucks",
            "2: machine gun, 75 bucks", "3: nuclear missile, 150 bucks"], 3)

        if result == 1:
            talk(screen, ["bob: give me the knife."])
            talk(screen, ["dealer: do you have the money?"])
            if player.bucks < 20:
                talk(screen, ["bob: nope."])
                talk(screen, ["dealer: can't do business, then."])
                talk(screen, ["bob: damn!"])
                return

            talk(screen, ["bob: yup."])
            player.bucks-=20
            player.inventory.append("knife")
            draw_game_screen(screen)
            talk(screen, ["you got a knife!"])
            talk(screen, ["dealer: make good use of it."])
            return

        if result == 2:
            talk(screen, ["bob: i want the machine gun."])
            talk(screen, ["dealer: it's 75 bucks, do you have it?"])
            if player.bucks < 75:
                talk(screen, ["bob: no..."])
                talk(screen, ["dealer: no deal, then."])
                talk(screen, ["bob: crap!"])
                return

            talk(screen, ["bob: sure, here."])
            player.bucks-=75
            player.inventory.append("machine gun")
            draw_game_screen(screen)
            talk(screen, ["you got a machine gun!"])
            talk(screen, ["dealer: i hope it brings you joy."])
            return

        if result == 3:
            talk(screen, ["bob: i'll have the nuclear missile."])
            talk(screen, ["dealer: it costs 150 bucks."])
            if player.bucks < 125:
                talk(screen, ["bob: i don't have this much."])
                talk(screen, ["dealer: too bad, then. you can't have it."])
                talk(screen, ["bob: this is so unfair!"])
                return

            talk(screen, ["bob: it's too expensive for me!"])
            talk(screen, ["dealer: it's a nuclear missile, what did",
                "you expect?"])
            talk(screen, ["bob: can't we make a deal for 125 bucks",
                "instead?"])
            talk(screen, ["dealer: hmm... alright, alright. no one",
                "was ever going to buy it anyway!"])
            talk(screen, ["bob: sweet!"])
            player.bucks-=125
            player.inventory.append("nuke")
            draw_game_screen(screen)
            talk(screen, ["you got the nuclear missile!!!"])
            nuclearEnding(screen)
            return

        return

    if player.actions["dealer"]["has met"] == 1:
        talk(screen, ["bob: i don't know."])
        talk(screen, ["man: wrong!"])
        return

    result = talk(screen, ["1: 'huh?'", "2: 'what password?'",
        "3: 'what you say ??'"], 3)
    if result == 1:
        talk(screen, ["bob: huh?"])
    if result == 2:
        talk(screen, ["bob: what password?"])
    if result == 3:
        talk(screen, ["captain: what you say ??"])
    talk(screen, ["man: wrong!"])
    if result == 3:
        talk(screen, ["man: by the way, making stupid references",
            "to old games isn't going to help you!"])
    player.actions["dealer"]["has met"] = 1

# Kirk's event
def kirkEvent(screen):
    if player.inventory.count("knife") > 0:
        knifeEnding(screen, "kirk")
        return

    if player.inventory.count("machine gun") > 0:
        machineGunEnding(screen, "kirk")
        return

    #If Kirk was mugged:
    if player.actions["kirk"]["mugged"] == 1:
        talk(screen, ["kirk: please don't hurt me!"])
        return

    #If Kirk is muggable:
    if player.actions["kirk"]["muggable"] == 1:
        talk(screen, ["bob: hey there kirk. i need some money,",
            "could i borrow some from you?"])
        talk(screen, ["kirk: i'm sorry. i don't have any money",
            "right now."])
        result = talk(screen, ["1: leave him", "2: punch him"], 2)
        if result == 1:
            talk(screen, ["bob: bah, you suck!"])
            return

        if result == 2:
            # Took me a while to get the next line done. =(
            # That's what you get from bad code design, kids!
            player.scenario.events["k"].setImage(loadImage(face2(green), 22, 30))
            draw_game_screen(screen)
            talk(screen, ["- bonk -"])
            talk(screen, ["kirk: i'm sorry! here, that's all the",
                "money i have!"])
            talk(screen, ["you got 15 bucks."])
            player.bucks+=15
            draw_game_screen(screen)
            talk(screen, ["bob: good."])
            player.actions["kirk"]["muggable"] = 0
            player.actions["kirk"]["mugged"] = 1
            return


    #If Bob met the weapons dealer and doesn't know the password.
    if player.actions["dealer"]["has met"] == 1 and player.actions["dealer"]["password"] == 0:
        talk(screen, ["bob: hey, who is that strange guy in the",
            "hotel?"])
        talk(screen, ["kirk: i don't know. i think i saw pip",
            "talking to him, though."])
        return

    #If Bob met the weapons dealer and he knows the password.
    if player.actions["dealer"]["has met"] == 1 and player.actions["dealer"]["password"] > 0:
        talk(screen, ["kirk: good day to you, bob!"])

    #If Kirk is scared:
    if player.actions["kirk"]["scared"] == 1:
        talk(screen, ["kirk: h-hey t-there bob."])
        return

    #If Kirk is angry:
    if player.actions["kirk"]["angry"] == 1:
        talk(screen, ["kirk: just don't talk to me while you are",
            "in a bad mood."])
        return

    talk(screen, ["kirk: hi there, bob! how are you?"])
    result = talk(screen, ["1: good","2: bad","3: not sure"], 3)
    if result == 1:
        talk(screen, ["bob: oh, i feel so good that i could KILL", "someone!"])
        talk(screen, ["kirk: hehe, you're always a big kidder!"])
        talk(screen, ["bob: whatever you say..."])
    if result == 2:
        talk(screen, ["bob: i feel so bad that i'd KILL someone",
            "if i had the chance!"])
        talk(screen, ["kirk: i'm sure things will look better for",
            "you if you relax a little. why don't you", "give it a shot?"])
        talk(screen, ["bob: hmm... give it a shot? that's actually",
            "a great idea!"])
    if result == 3:
        talk(screen, ["bob: i'm not sure. for some reason i want",
            "to KILL someone!"])
        talk(screen, ["kirk: h-hey bob... what are you talking",
            "about? y-you look so serious..."])
        player.actions["kirk"]["scared"] = 1
        return

    talk(screen, ["kirk: so... what are you doing today?"])
    talk(screen, ["bob: i think i really am going to KILL",
        "someone."])
    talk(screen, ["kirk: are you serious?"])
    result = talk(screen, ["1: yes", "2: no"], 2)
    if result == 1:
        talk(screen, ["bob: of course i am, stupid!"])
        talk(screen, ["kirk: you don't need to be sarcastic nor",
            "rude! i'm sorry for being suspicious ok?",
            "geez, you're so rude!"])

    if result == 2:
        talk(screen, ["bob: of course i am not, you bastard!"])
        talk(screen, ["kirk: you don't need to insult me like",
            "that! just don't talk to me while you're",
            "like that, ok?"])

    player.actions["kirk"]["angry"] = 1

# Meg's Event
def megEvent(screen):
    if player.inventory.count("knife") > 0:
        knifeEnding(screen, "meg")
        return

    if player.inventory.count("machine gun") > 0:
        machineGunEnding(screen, "meg")
        return

    #If Bob met the weapons dealer and doesn't know the password.
    if player.actions["dealer"]["has met"] == 1 and player.actions["dealer"]["password"] == 0:
        talk(screen, ["bob: hey, who is the strange guy staying in",
            "this hotel?"])
        talk(screen, ["meg: i don't know. maybe pip knows, he",
            "usually spends his day standing by the",
            "hotel."])
        return

    talk(screen, ["meg: oh, hello bob. how are you?"])

    #If Bob is looking for the glasses
    if player.actions["tim"]["glasses"] == 1 and player.inventory.count("glasses") == 0:
        talk(screen, ["bob: i'm busy looking for some old man's",
            "glasses."])
        talk(screen, ["meg: oh, i found some glasses in a room",
            "earlier. here, take them."])
        talk(screen, ["you got glasses."])
        player.inventory.append("glasses")
        draw_game_screen(screen)
        return

    #If Bob has already listened to Meg
    if player.actions["meg"]["listen"] == 1:
        talk(screen, ["bob: just shut up."])
        return

    result = talk(screen, ["1: bored", "2: busy"], 2)
    if result == 1:
        talk(screen, ["bob: so bored i'd KILL someone for fun!"])
        talk(screen, ["meg: bob, darling, if you're so bored then",
            "you should just stay and chat with me for",
            "a while."])
        talk(screen, ["bob: actually, i don..."])
        talk(screen, ["meg: you see, yesterday i was going to the",
            "market and couldn't find any carrots, can",
            "you believe it?"])
        talk(screen, ["bob: i don't car..."])
        talk(screen, ["meg: and then i asked the vendor why didn't",
            "they have any carrots and blah blah blah",
            "blah blah blah blah blah blah blah..."])
        for x in range(1, 6):
            talk(screen, ["meg: blah blah blah blah blah",
                "blah blah blah blah blah", ("blah "*x) + "..."])
            result = talk(screen, ["1: keep listening", "2: ignore her"], 2)
            if result == 2:
                return
        talk(screen, ["meg: oh my, i must have kept you listening",
            "to me for too long, haven't i? i'm sorry",
            "here, have some bucks for listening to me!"])
        talk(screen, ["you got 30 bucks."])
        player.bucks+=30
        draw_game_screen(screen)
        talk(screen, ["bob: not even a million bucks would make",
            "this worth the trouble..."])
        player.actions["meg"]["listen"] = 1

    if result == 2:
        talk(screen, ["meg: oh, i see..."])

# Pip's event
def pipEvent(screen):
    if player.inventory.count("knife") > 0:
        knifeEnding(screen, "pip")
        return

    if player.inventory.count("machine gun") > 0:
        machineGunEnding(screen, "pip")
        return

    #Regular talk if the player doesn't know the password.
    if player.actions["dealer"]["password"] == 0:
        talk(screen, ["pip: hey there, bob. how are you?"])
        result = talk(screen, ["1: not much", "2: feeling weird"],2)
        if result == 1:
            talk(screen, ["bob: not much, just walking around."])
            talk(screen, ["pip: oh. see you then!"])

        if result == 2:
            talk(screen, ["bob: not much, just the desire to KILL",
                "someone."])
            talk(screen, ["pip: cool! let me know if anyone dies!"])

    #If the player wants to know the password
    if player.actions["dealer"]["has met"] == 1 and player.actions["dealer"]["password"] == 0:
        talk(screen, ["bob: by the way, do you know who is that",
            "strange guy staying at the hotel?"])
        talk(screen, ["pip: ah, sure. that would be my uncle. he",
            "is a weapons dealer!"])
        talk(screen, ["bob: oh, really? and what is the password",
            "to buy stuff from him?"])
        talk(screen, ["pip: are you interested in  buying a",
            "weapon? do you want to kill anyone?"])
        talk(screen, ["bob: yes i do."])
        talk(screen, ["pip: ok. the password is 'i want to KILL'."])
        talk(screen, ["bob: what a beautiful password. thanks!"])
        player.actions["dealer"]["password"] = 1
        return

    #Asks the player whether or not anyone was killed.
    if player.actions["dealer"]["password"] > 0:
        if player.actions["kirk"]["mugged"] == 0:
            talk(screen, ["pip: so, have you killed anyone yet?"])
            talk(screen, ["bob: i'm working on that. i need more money",
                "to get a decent weapon."])
            talk(screen, ["pip: you can always ask kirk to lend you",
                "some."])
            talk(screen, ["bob: hmm..."])
            player.actions["kirk"]["muggable"] = 1

        talk(screen, ["pip: good luck on your noble quest!"])

# Ron's event
def ronEvent(screen):
    if player.inventory.count("knife") > 0:
        knifeEnding(screen, "ron")
        return

    if player.inventory.count("machine gun") > 0:
        machineGunEnding(screen, "ron")
        return

    if player.actions["ron"]["told truth"] == 1:
        talk(screen, ["ron: get out of my house!"])
        return

    if player.actions["ron"]["water"] == 6:
        talk(screen, ["ron: my mouth tastes funny."])
        talk(screen, ["bob: it's because i gave you toilet water."])
        player.scenario.events["r"].setImage(loadImage(face3(cyan), 22, 30))
        draw_game_screen(screen)
        talk(screen, ["ron: ack! get out of my house!"])
        player.actions["ron"]["told truth"] = 1
        return

    #If Bob didn't bring Ron some water
    if player.inventory.count("empty cup") > 0:
        talk(screen, ["ron: so, where is my water?"])
        return

    #If Bob brought Ron some water
    if player.inventory.count("filled cup") > 0:
        talk(screen, ["ron: ahhhh, thanks!"])
        player.inventory.remove("filled cup")
        player.inventory.append("empty cup")
        draw_game_screen(screen)
        player.actions["ron"]["water"]+=1

        #If Ron is still unsatisfied
        if player.actions["ron"]["water"] < 6:
            talk(screen, ["ron: i am still thisty, can you bring me",
                "some more water?"])
            return

        talk(screen, ["ron: thanks for serving me. here, take some",
            "pocket change."])
        talk(screen, ["you got 15 bucks."])
        player.bucks+=15
        draw_game_screen(screen)
        return
        

    talk(screen, ["ron: hey there, bob. i am thisty, can you",
        "bring me some water?"])
    talk(screen, ["you got an empty cup."])
    player.inventory.append("empty cup")
    draw_game_screen(screen)

# Ron's toilet's event
def ronToiletEvent(screen):
    if player.inventory.count("empty cup") > 0:
        talk(screen, ["filled cup with toilet water."])
        player.inventory.remove("empty cup")
        player.inventory.append("filled cup")
        draw_game_screen(screen)
        return

    talk(screen, ["bob: this is one ugly toilet! it seems like",
        "someone forgot to flush."])

# Tim's event
def timEvent(screen):
    if player.inventory.count("knife") > 0:
        knifeEnding(screen, "tim")
        return

    if player.inventory.count("machine gun") > 0:
        machineGunEnding(screen, "tim")
        return

    if player.actions["tim"]["leg"] == 2 and player.actions["tim"]["glasses"] == 2:
        talk(screen, ["tim: i think i lost 10 bucks somewhere."])
        return

    if player.actions["tim"]["leg"] == 1:
        talk(screen, ["tim: have you found my leg?"])
        if player.inventory.count("leg") > 0:
            talk(screen, ["bob: yes. here it is."])
            player.inventory.remove("leg")
            draw_game_screen(screen)
            talk(screen, ["tim: thank you. here are 5 bucks for your",
                "help!"])
            talk(screen, ["you got 5 bucks."])
            player.bucks+=5
            draw_game_screen(screen)
            player.actions["tim"]["leg"] = 2
        else:
            talk(screen, ["bob: nope."])

    if player.actions["tim"]["glasses"] == 1:
        talk(screen, ["tim: where are my glasses?"])
        if player.inventory.count("glasses") > 0:
            talk(screen, ["bob: here they are."])
            player.inventory.remove("glasses")
            draw_game_screen(screen)
            talk(screen, ["tim: thank you! here are your 15 bucks for",
                "helping me out."])
            talk(screen, ["you got 25 bucks."])
            player.bucks+=25
            draw_game_screen(screen)
            player.actions["tim"]["glasses"] = 2
        else:
            talk(screen, ["bob: i'm still looking for them."])

    if player.actions["tim"]["leg"] > 0 or player.actions["tim"]["glasses"] > 0:
        return

    talk(screen, ["tim: hey, bob! want to make some cash?"])
    talk(screen, ["bob: why, sure!"])
    talk(screen, ["tim: good. can you fetch me some things",
        "then?"])
    talk(screen, ["bob: i think so."])
    talk(screen, ["tim: good. there are two things that are",
        "missing. my leg and my glasses."])
    talk(screen, ["bob: your leg?"])
    talk(screen, ["tim: yes. i think i forgot my leg at the",
        "hotel could you check that place for me?"])
    talk(screen, ["bob: dude, your leg?"])
    talk(screen, ["tim: the second thing that is missing are",
        "my glasses. i don't know where i lost them,",
        "though."])
    talk(screen, ["bob: how does one lose a leg?!"])
    talk(screen, ["tim: if you bring me my leg i will pay you",
        "5 bucks. if you bring me my glasses i will pay",
        "you another 15 bucks."])
    talk(screen, ["bob: dude, you're asking me to fetch you a",
        "leg, what's wrong with you?"])
    talk(screen, ["tim: after you find those items return them",
        "to me so i can reward you."])
    player.actions["tim"]["leg"] = 1
    player.actions["tim"]["glasses"] = 1

# Von's event
def vonEvent(screen):
    if player.inventory.count("knife") > 0:
        knifeEnding(screen, "von")
        return

    if player.inventory.count("machine gun") > 0:
        machineGunEnding(screen, "von")
        return

    if player.actions["von"]["aggression"] == 1:
        talk(screen, ["wise man: ..."])
        return

    if player.actions["von"]["test"] == 2:
        talk(screen, ["wise man: good luck, son!"])
        talk(screen, ["bob: i'm not your son, you bastard!"])
        talk(screen, ["wise man: that's just a way of speaking..."])
        player.scenario.events["v"].setImage(loadImage(face2(gray), 22, 30))
        draw_game_screen(screen)
        talk(screen, ["- bonk - "])
        talk(screen, ["bob: and that's just a way of aggression!"])
        player.actions["von"]["aggression"] = 1
        return

    if player.actions["von"]["test"] == 0:
        talk(screen, ["wise man: hello there, bob. how are you?",
            "wait, don't tell me... you wish to KILL",
            "someone, don't you?"])
        talk(screen, ["bob: you got that right."])
        talk(screen, ["wise man: i might be able to help you on",
            "your quest. but i am only going to help",
            "you if you pass my test."])
        talk(screen, ["bob: this is so lame."])
        player.actions["von"]["test"] = 1

    talk(screen, ["wise man: so, will you take my test?"])
    result = talk(screen, ["1: ok", "2: no way"], 2)
    if result == 2:
        talk(screen, ["bob: i don't have time for your nonsense",
            "i'm out of here."])
        talk(screen, ["wise man: as you wish..."])
        return

    correct = 0

    talk(screen, ["bob: ok, ok, i'll take your stupid test."])
    talk(screen, ["wise man: good! let's get started!"])

    talk(screen, ["wise man: kirk is easily scared. can you",
        "tell me which answer would you give to the",
        "question 'how are you' to scare him?"])
    result = talk(screen, ["1: not sure", "2: good", "3: bad"], 3)
    if result == 1:
        correct+=1

    talk(screen, ["wise man: how much money was kirk holding",
        "at the beginning of this day?"])
    result = talk(screen, ["1: 10 bucks", "2: 15 bucks", "3: 25 bucks"], 3)
    if result == 2:
        correct+=1

    talk(screen, ["wise man: what couldn't meg find at the",
        "market?"])
    result = talk(screen, ["1: carrots", "2: lettuce", "3: her brain"], 3)
    if result == 1:
        correct+=1

    talk(screen, ["wise man: how much money is there in the",
        "box at your house?"])
    result = talk(screen, ["1: 10 bucks", "2: 0 bucks"], 2)
    if result == 1:
        if player.actions["box"]["found money"] == 0:
            correct+=1
    if result == 2:
        if player.actions["box"]["found money"] == 1:
            correct+=1

    talk(screen, ["wise man: how many boxes are there in the",
        "city?"])
    result = talk(screen, ["1: 1 box", "2: 2 boxes", "3: 3 boxes"], 3)
    if result == 3:
        correct+=1

    talk(screen, ["wise man: what is the price of a machine",
        "gun?"])
    result = talk(screen, ["1: 65 bucks", "2: 70 bucks", "3: 75 bucks"], 3)
    if result == 3:
        correct+=1

    if correct < 6:
        talk(screen, ["wise man: you got some answers wrong. feel",
            "free to try again later."])
        return

    if correct == 6:
        talk(screen, ["wise man: congratulations! you got all the",
            "answers right! here are the 25 bucks that i",
            "promised you."])
        talk(screen, ["you got 25 bucks"])
        player.bucks+=25
        draw_game_screen(screen)
        player.actions["von"]["test"] = 2

# Regular water event
def waterEvent(screen):
    if player.inventory.count("empty cup") > 0:
        talk(screen, ["bob: i'm not filling the cup with this",
            "water"])

# Events information
class eventData:
    def __init__(self, solid, function=doNothing, image=None, w=0, h=0):
        self.solid, self.function = solid, function
        if image != None:
            self.image = loadImage(image, w, h)
        else:
            self.image = None

    def setImage(self, image):
        self.image = image

    def hasImage(self):
        if self.image == None:
            return False
        return True

# Events
events = {}

def init_events():
    events["ground"] = eventData(False)
    events["water"] = eventData(True, waterEvent)
    events["wall"] = eventData(True)
    events["toBobHouse"] = eventData(False, teleport(bobsHouse, 12,9))
    events["bobsHouseExit"] = eventData(False, teleport(city, 4, 3))
    events["toRonsHouse"] = eventData(False, teleport(ronsHouse, 12,10))
    events["ronsHouseExit"] = eventData(False, teleport(city, 3,8))
    events["toVonHouse"] = eventData(False, teleport(vonsHouse, 8,8))
    events["vonsHouseExit"] = eventData(False, teleport(city, 6,13))
    events["toHotel"] = eventData(False, teleport(hotel,15, 12))
    events["hotelExit"] = eventData(False, teleport(city, 13, 5))
    events["box1"] = eventData(True, box1Event, boxShape, 25, 26)
    events["box2"] = eventData(True, box2Event, boxShape, 25, 26)
    events["box3"] = eventData(True, box3Event, boxShape, 25, 26)
    events["dealer"] = eventData(True, dealerEvent, face1(white), 22, 30)
    events["kirk"] = eventData(True, kirkEvent, face1(green), 22, 30)
    events["meg"] = eventData(True, megEvent, face1(pink), 22, 30)
    events["pip"] = eventData(True, pipEvent, face1(blue), 22, 30)
    events["ron"] = eventData(True, ronEvent, face1(cyan), 22, 30)
    events["ronToilet"] = eventData(True, ronToiletEvent, toilet, 24, 32)
    events["tim"] = eventData(True, timEvent, face1(brown), 22, 30)
    events["von"] = eventData(True, vonEvent, face1(gray), 22, 30)

init_events()

cityEvents = {
    ".":events["ground"],
    "w":events["water"],
    "@":events["wall"],
    "B":events["toBobHouse"],
    "R":events["toRonsHouse"],
    "V":events["toVonHouse"],
    "H":events["toHotel"],
    "k":events["kirk"],
    "p":events["pip"],
    "t":events["tim"]
}

bobsHouseEvents = {
    ".":events["ground"],
    "@":events["wall"],
    "E":events["bobsHouseExit"],
    "b":events["box1"],
}

ronsHouseEvents = {
    ".":events["ground"],
    "@":events["wall"],
    "E":events["ronsHouseExit"],
    "r":events["ron"],
    "t":events["ronToilet"]
}

vonsHouseEvents = {
    ".":events["ground"],
    "@":events["wall"],
    "E":events["vonsHouseExit"],
    "v":events["von"]
}

hotelEvents = {
    ".":events["ground"],
    "@":events["wall"],
    "E":events["hotelExit"],
    "m":events["meg"],
    "d":events["dealer"],
    "b":events["box2"],
    "B":events["box3"]
}

# Setting up scenarios
city.setData(cityEvents, cityMap, cityImage)
hotel.setData(hotelEvents, hotelMap, hotelImage)
bobsHouse.setData(bobsHouseEvents, bobsHouseMap, bobsHouseImage)
ronsHouse.setData(ronsHouseEvents, ronsHouseMap, ronsHouseImage)
vonsHouse.setData(vonsHouseEvents, vonsHouseMap, vonsHouseImage)

## Endings ##

print "- Loading endings information and graphics."

knifeShape = [
    poly(0,0,[(0,10),(4,10),(4,14),(0,14)],black),
    lines(0,0,[(5,7),(5,17)],black),
    poly(0,0,[(6,8),(23,8),(22,11),(19,14),(14,15),(6,15)],gray,2),
]

machineGunShape = [
    poly(0,0,[(0,8),(23,8),(23,11),(18,11),(18,15),(14,15),(14,12),(4,12),
        (4,15),(0,15)],gray,2)
]

nukeShape = [
    poly(0,0,[(3,7),(16,7),(17,10),(18,14),(18,23),(13,23),(13,25),(19,29),
        (0,29),(7,25),(7,23),(1,23),(1,14),(2,10),(3,7)],gray,2),
    poly(0,0,[(3,6),(4,4),(6,3),(8,2),(11,2),(13,3),(15,4),(16,6)],red,2)
]

bloodPoolShape = [
    poly(0,0,[(2,9),(4,7),(7,8),(11,5),(15,5),(18,6),(20,9),(21,12),(21,14),
        (19,17),(17,21),(14,22),(11,21),(9,18),(7,19),(4,23),(2,22),(0,19),
        (0,13),(2,12)],(200,38,38),2)
]

victimColor = {"dealer":white, "kirk":green, "meg":pink, "pip":blue, "ron":cyan,
    "tim":brown, "von":gray}

def endingText(screen):
    screen.fill(black)
    pygame.display.flip()
    pygame.time.wait(1000)
    for x in range(1, 16):
        drawText(screen, ["and so bob was able to KILL someone",
            "and leave to another city to",
            "live new exciting adventures."],
            centerText, 50, (17*x,17*x,17*x))
        pygame.time.wait(50)
        pygame.display.flip()
    pygame.time.wait(6000)
    drawText(screen, ["the end"], centerText, 200, pink)
    pygame.display.flip()
    pygame.time.wait(1000)
    drawText(screen, ["press any key to return to the main menu."], centerText,
        300, yellow)
    pygame.display.flip()
    pygame.event.get([KEYUP, KEYDOWN])
    while True:
        if check_quit() or has_key():
            return
        pygame.time.wait(50)

def knifeEnding(screen, victim):
    result = talk(screen,["1: kill this person","2: don't kill this person"],2)
    if result == 2:
        return

    xpos = screen.get_width()/2 - cityImage.get_width()/2
    ypos = screen.get_height()/2 - cityImage.get_height()/2
    victimImage = loadImage(face1(victimColor[victim]), 22, 30)
    sadVictimImage = loadImage(face3(victimColor[victim]), 22, 30)
    bobImage = loadImage(face1(red), 22, 30)
    knifeImage = loadImage(knifeShape, 24, 32)
    bloodImage = loadImage(bloodPoolShape, 24, 24)

    player.actions["game over"] = 1
    screen.fill(black)
    pygame.display.flip()
    pygame.time.wait(1000)
    for x in range(1, 16):
        drawText(screen, ["the next day..."], centerText, 100, (17*x,17*x,17*x))
        pygame.time.wait(50)
        pygame.display.flip()

    pygame.time.wait(2000)

    screen.blit(cityImage, (xpos,ypos))
    screen.blit(victimImage, (xpos+316,ypos+196))
    screen.blit(bobImage, (xpos+196,ypos+196))
    pygame.display.flip()
    pygame.time.wait(1000)
    # Approaching the victim
    for x in range(0, 4):
        screen.blit(cityImage,(xpos+196+24*x,ypos+196),
            ((196+24*x,196),(22,30)))
        screen.blit(bobImage,(xpos+220+24*x,ypos+196))
        pygame.display.flip()
        pygame.time.wait(120)
    pygame.time.wait(1000)
    # Stabbing the victim
    screen.blit(sadVictimImage, (xpos+316,ypos+196))
    screen.blit(knifeImage, (xpos+314,ypos+196))
    pygame.display.flip()
    pygame.time.wait(300)
    screen.blit(cityImage,(xpos+314,ypos+196),((314,196),(24,32)))
    screen.blit(sadVictimImage, (xpos+316,ypos+196))
    pygame.display.flip()
    pygame.time.wait(500)
    # Victim falling
    for x in range(1, 7):
        screen.blit(cityImage,(xpos+316,ypos+196),((316,196),(35,40)))
        rotated = pygame.transform.rotate(sadVictimImage,-15*x)
        screen.blit(rotated, (xpos+316,ypos+196+x))
        pygame.display.flip()
        pygame.time.wait(100)
    # Victim bleeding
    for x in range(0, 20):
        scaled = pygame.transform.scale(bloodImage, (bloodImage.get_width()+x,
            bloodImage.get_height()+x))
        screen.blit(cityImage, (xpos+316,ypos+196),((316,196),
            (scaled.get_width(), scaled.get_height())))
        screen.blit(scaled, (xpos+316,ypos+202))
        screen.blit(rotated, (xpos+316,ypos+202))
        pygame.display.flip()
        pygame.time.wait(100)

    pygame.time.wait(2000)
    endingText(screen)

def machineGunEnding(screen, victim):
    result = talk(screen,["1: kill this person","2: don't kill this person"],2)
    if result == 2:
        return

    xpos = screen.get_width()/2 - cityImage.get_width()/2
    ypos = screen.get_height()/2 - cityImage.get_height()/2
    victimImage = loadImage(face1(victimColor[victim]), 22, 30)
    sadVictimImage = loadImage(face3(victimColor[victim]), 22, 30)
    bobImage = loadImage(face1(red), 22, 30)
    machineGunImage = loadImage(machineGunShape, 24, 24)
    bloodImage = loadImage(bloodPoolShape, 24, 24)

    player.actions["game over"] = 1
    screen.fill(black)
    pygame.display.flip()
    pygame.time.wait(1000)
    for x in range(1, 16):
        drawText(screen, ["the next day..."], centerText, 100, (17*x,17*x,17*x))
        pygame.time.wait(50)
        pygame.display.flip()

    pygame.time.wait(2000)

    screen.blit(cityImage, (xpos,ypos))
    screen.blit(victimImage, (xpos+316,ypos+196))
    screen.blit(bobImage, (xpos+196,ypos+196))
    pygame.display.flip()
    pygame.time.wait(1000)
    # Shooting the victim
    screen.blit(sadVictimImage, (xpos+316,ypos+196))
    screen.blit(machineGunImage, (xpos+218,ypos+196))
    pygame.display.flip()
    pygame.time.wait(1000)
    holes = [(5,5),(14,7),(3,8),(12,11),(20,4)]
    pos = [(-1,-3,15),(-3,-2,-20),(-3,2,-10),(-2,0,-14),(-2,-2,18)]
    for x in range(0,5):
        screen.blit(cityImage,(xpos+313,ypos+194),((313,194),(40,40)))
        pygame.draw.circle(sadVictimImage,black,(holes[x][0],holes[x][1]),3)
        rotated = pygame.transform.rotate(sadVictimImage,pos[x][2])
        screen.blit(rotated,(xpos+316+pos[x][0],ypos+196+pos[x][1]))
        pygame.display.flip()
        pygame.time.wait(50)
        screen.blit(cityImage,(xpos+313,ypos+194),((313,194),(40,40)))
        screen.blit(sadVictimImage,(xpos+316,ypos+196))
        pygame.time.wait(50)
    # Victim falling
    for x in range(1, 7):
        screen.blit(cityImage,(xpos+316,ypos+196),((316,196),(35,40)))
        rotated = pygame.transform.rotate(sadVictimImage,-15*x)
        screen.blit(rotated, (xpos+316,ypos+196+x))
        pygame.display.flip()
        pygame.time.wait(100)
    # Victim bleeding
    for x in range(0, 23):
        scaled = pygame.transform.scale(bloodImage, (bloodImage.get_width()+x,
            bloodImage.get_height()+x))
        screen.blit(cityImage, (xpos+316,ypos+196),((316,196),
            (scaled.get_width(), scaled.get_height())))
        screen.blit(scaled, (xpos+316,ypos+202))
        screen.blit(rotated, (xpos+316,ypos+202))
        pygame.display.flip()
        pygame.time.wait(100)

    pygame.time.wait(2000)
    endingText(screen)

def nuclearEnding(screen):
    xpos = screen.get_width()/2 - cityImage.get_width()/2
    ypos = screen.get_height()/2 - cityImage.get_height()/2
    victimImage = []
    sadVictimImage = []
    for x in [white, green, pink, blue, cyan, brown, gray]:
        victimImage.append(loadImage(face1(x),22,30))
        sadVictimImage.append(loadImage(face3(x),22,30))
    bobImage = loadImage(face1(red), 22, 30)
    nukeImage = loadImage(nukeShape, 24, 32)

    player.actions["game over"] = 1
    screen.fill(black)
    pygame.display.flip()
    pygame.time.wait(1000)
    for x in range(1, 16):
        drawText(screen, ["the next day..."], centerText, 100, (17*x,17*x,17*x))
        pygame.time.wait(50)
        pygame.display.flip()

    pygame.time.wait(2000)

    screen.blit(cityImage, (xpos,ypos))
    pos = [(366,236),(423,201),(341,160),(350,300),(430,311),(299,177),(311,255)]
    for x in range(0,7):
        screen.blit(victimImage[x], (xpos+pos[x][0],ypos+pos[x][1]))
    screen.blit(bobImage, (xpos+196,ypos+196))
    pygame.display.flip()
    pygame.time.wait(1000)

    # Throwing the nuke
    route = [(218,186,0),(218,178,-18),(220,172,-36),(226,166,-54),
        (233,161,-72),(243,163,-90),(252,165,-108),(256,168,-126),
        (259,172,-144),(263,180,-162),(265,190,-180)]
    screen.blit(nukeImage, (xpos+218,ypos+196))
    for x in range(0,7):
        screen.blit(sadVictimImage[x], (xpos+pos[x][0],ypos+pos[x][1]))
    pygame.display.flip()
    pygame.time.wait(1000)
    prevSize = nukeImage.get_size()
    prevRoute = (218,196)
    for x in range(0,len(route)):
        rotateNuke = pygame.transform.rotate(nukeImage, route[x][2])
        screen.blit(cityImage,(prevRoute[0]+xpos,prevRoute[1]+ypos),
            (prevRoute,prevSize))
        screen.blit(rotateNuke,(route[x][0]+xpos,route[x][1]+ypos))
        prevRoute = (route[x][0],route[x][1])
        prevSize = rotateNuke.get_size()
        pygame.display.flip()
        pygame.time.wait(70)

    # Exploding
    for x in range(0, 16):
        screen.fill((255 - 17*x, 255 - 17*x, 255 - 17*x))
        pygame.display.flip()
        pygame.time.wait(50)

    # Ending text
    screen.fill(black)
    pygame.display.flip()
    pygame.time.wait(1000)
    for x in range(1, 16):
        drawText(screen, ["and so bob was able to KILL everyone",
            "by nuking the city. he died in the",
            "explosion along with all the",
            "villagers so the only place he can",
            "go to live new exciting adventures",
            "now is hell."],
            centerText, 50, (17*x,17*x,17*x))
        pygame.time.wait(50)
        pygame.display.flip()
    pygame.time.wait(6000)
    drawText(screen, ["the end"], centerText, 200, pink)
    pygame.display.flip()
    pygame.time.wait(1000)
    drawText(screen, ["press any key to return to the main menu."], centerText,
        300, yellow)
    pygame.display.flip()
    pygame.event.get([KEYUP, KEYDOWN])
    while True:
        if check_quit() or has_key():
            return
        pygame.time.wait(50)        

print "- Loading other game information."

# Player information
class playerData:
    def __init__(self):
        self.init()
    def init(self):
        self.inventory = []
        self.scenario = city
        self.pos = [4,3]
        self.bucks = 0
        self.actions = {}
        self.actions["box"] = {"found money":0, "found leg":0}
        self.actions["dealer"] = {"has met":0, "password":0}
        self.actions["kirk"] = {"scared":0, "angry":0, "mugged":0, "muggable":0}
        self.actions["meg"] = {"listen":0}
        self.actions["ron"] = {"water":0, "told truth":0}
        self.actions["tim"] = {"leg":0, "glasses":0}
        self.actions["von"] = {"test":0, "aggression":0}
        self.actions["game over"] = 0
    def setImage(self, image):
        self.image = loadImage(image,22,30)

player = playerData()
player.setImage(face1(red))

## User interface for main screen and main menu ##

# Checks if that "close window" button was pressed. Allow the player to quit
# when she wants to.
def check_quit():
    if pygame.event.peek(QUIT):
        return True
    return False

# Checks for redraw. Not really sure whether or not this is necessary.
def check_redraw():
    if pygame.event.peek(ACTIVEEVENT):
        pygame.event.get(ACTIVEEVENT)
        pygame.display.flip()

# Checks if there are key presses that need evaluation.
def has_key():
    if pygame.event.peek(KEYDOWN):
        return True
    return False

# Introduction Screen
def intro(screen):
    for x in range(0, 20):
        if check_quit() or has_key():
            return
        check_redraw()
        pygame.time.wait(50)

    for x in range(1, 25):
        c = (x*10, x*10, x*10)
        drawText(screen,["shundread is on fire!!1 presents:"],centerText,100,c)
        pygame.display.flip()
        if check_quit() or has_key():
            return
        pygame.time.wait(50)

    for x in range(0, 40):
        if check_quit() or has_key():
            return
        check_redraw()
        pygame.time.wait(50)

    for x in range(1, 25):
        c = (x*10, x*10, x*10)
        drawText(screen, ["bob's excuse to KILL"], centerText, 150, c)
        pygame.display.flip()
        if check_quit() or has_key():
            return
        pygame.time.wait(50)

    for x in range(0, 40):
        if check_quit() or has_key():
            return
        check_redraw()
        pygame.time.wait(50)

    screen.blit(player.image,
        ((screen.get_width()/2 - player.image.get_width()/2,200),
        player.image.get_size()))
    pygame.display.flip()

    for x in range(0, 40):
        if check_quit() or has_key():
            return
        check_redraw()
        pygame.time.wait(50)

    for x in range(0, 16):
        screen.fill((255 - 17*x, 255 - 17*x, 255 - 17*x))
        pygame.display.flip()
        if check_quit() or has_key():
            return
        pygame.time.wait(50)
    screen.fill(black)
    pygame.display.flip()

# Draws the game's screen. Called by teleports and the beggining of the game.
def draw_game_screen(screen):
    screen.fill(black)
    screen.blit(player.scenario.image, ((0,0),player.scenario.image.get_size()))

    for x in range(0,20):
        for y in range(0,15):
            event = player.scenario.events[player.scenario.areaMap[y][x]]
            if event.hasImage():
                screen.blit(event.image, ((x*24,y*32), event.image.get_size()))
    screen.blit(player.image, ((player.pos[0]*24, player.pos[1]*32),
        player.image.get_size()))

    drawText(screen, ["bucks:","","items:"], 485, 10, yellow)
    drawText(screen, [repr(player.bucks)], 590, 10, white)
    drawText(screen, player.inventory, 485, 70, white)
    pygame.display.flip()

# Game main loop
def game(screen):
    draw_game_screen(screen)
    firstEvent(screen)
    while True:
        if check_quit():
            return

        timer0 = pygame.time.get_ticks()
        pygame.event.pump()
        keys = pygame.key.get_pressed()
        speed = [0,0]
        # Allow the player to quit the game
        if keys[K_ESCAPE]:
            return

        # Allow the player to move
        if keys[K_LEFT]:
            speed[0] = speed[0]-1
        if keys[K_RIGHT]:
            speed[0] = speed[0]+1
        if keys[K_UP]:
            speed[1] = speed[1]-1
        if keys[K_DOWN]:
            speed[1] = speed[1]+1

        if (player.pos[0] + speed[0]) in range(0,20):
            x = player.pos[0] + speed[0]
        else:
            x = player.pos[0]

        if (player.pos[1] + speed[1]) in range(0,15):
            y = player.pos[1] + speed[1]
        else:
            y = player.pos[1]

        target = player.scenario.events[player.scenario.areaMap[y][x]]
        if target.solid == False:
            # Redraw only parts of the screen which are necessary
            screen.set_clip(((player.pos[0]*24, player.pos[1]*32),
                player.image.get_size()))
            screen.blit(player.scenario.image,((0,0),(480,480)))
            screen.set_clip((0,0),screen.get_size())
            player.pos = [x,y]
            screen.blit(player.image,
                ((player.pos[0]*24, player.pos[1]*32),(player.image.get_size())))

        target.function(screen)
        pygame.display.flip()
        if player.actions["game over"] == 1:
            return
        timer1 = pygame.time.get_ticks()
        if timer1 - timer0 < 120:
            pygame.time.wait(120 - (timer1 - timer0))

def new_game(screen):
    init_events()
    city.events["k"].setImage(loadImage(face1(green), 22, 30))
    vonsHouse.events["v"].setImage(loadImage(face1(gray), 22, 30))
    player.init()
    game(screen)

def instructions(screen):
    screen.fill(black)
    drawText(screen,["instructions"], centerText, 10, yellow)
    drawText(screen,[
        "movement: move bob with the arrow keys in",
        "your keyboard. it is as simple as it gets.",
        "",
        "interaction: bob can interact with people",
        "and other objects, when that happens you",
        "will be presented with some options in ",
        "your dialogue box. when that happens you",
        "should just press the number corresponding",
        "to your choice in the keyboard. if you are",
        "not presented with options, then you can",
        "just press enter to make the text go away.",
        "",
        "note: violence is only fun when it is not",
        "happening in real life. this game is not",
        "to be taken seriously",
        "","",
        "this game is licensed under the gnu gpl v2.",
        "",
        "        this game was written by:",
        "     thiago chaves de oliveira horta",
        "",
        "press any key to return to the main menu."], 5, 50)
    pygame.display.flip()
    pygame.event.get([KEYUP, KEYDOWN])
    while not has_key():
        check_redraw()
        pygame.time.wait(50)

def main_menu(screen):
    pygame.event.get([KEYUP, KEYDOWN])
    screen.fill(black)
    drawText(screen, ["bob's excuse to KILL"], centerText, 100)
    drawText(screen, ["f1:  new game", "f2:  instructions", "esc: quit"],
        10, 200)
    pygame.display.flip()
    while True:
        if has_key():
            pygame.event.get([KEYUP])
            keys = pygame.event.get([KEYDOWN])
            for k in keys:
                if k.dict['key'] == K_ESCAPE:
                    pygame.event.post(pygame.event.Event(QUIT, {}))
                    return

                if k.dict['key'] == K_F1:
                    new_game(screen)
                    return

                if k.dict['key'] == K_F2:
                    instructions(screen)
                    return

        if check_quit():
            return

        check_redraw()
        pygame.time.wait(50)

def main():
    pygame.init()
    pygame.event.set_allowed([KEYUP,KEYDOWN, QUIT, ACTIVEEVENT])
    pygame.event.set_blocked([MOUSEMOTION, MOUSEBUTTONUP, MOUSEBUTTONDOWN,
        JOYAXISMOTION, JOYBALLMOTION, JOYHATMOTION, JOYBUTTONUP, JOYBUTTONDOWN,
        VIDEORESIZE, VIDEOEXPOSE])
    pygame.display.set_caption("Bob's Excuse to KILL")
    screen = pygame.display.set_mode((650, 545))
    intro(screen)
    while check_quit() == False:
        main_menu(screen)
    pygame.quit()

print "Game ready to start!"
main()
