#!/usr/bin/python

import pygame
import random
import math
import pygame
import StringIO
import uu

pygame.mixer.pre_init(8000,-16,2, 1024 * 3)
pygame.init()
pygame.mixer.set_num_channels(4096)

tick_uu = StringIO.StringIO('begin 666 -\nM3V=G4P "           /\'MQH     /*^2$T!\'@%V;W)B:7,      42L    \nM     7<!      "X 4]G9U,             #Q[<: $   !1 LRP$"W_____\nM_____________\\X#=F]R8FES\'0   %AI<&@N3W)G(&QI8E9O<F)I<R!)(#(P\nM,#(P-S$W      $%=F]R8FES*4)#5@$ "    #%,*,2 T)!5   0   @F#80\nM:Z>UUEIK@J1V6FNJM=9::R:UMEIKK;766FNMM=9::ZVUUEIC(#1D%0  ! ! \nM*$H2M&123$HI92!\'CG+D.4C*)Z4H1PIBXCGH/?5D:TVFI.1;34HI)0@-604 \nM  ( 0 @AA!!22"&%%%)((8448H@AIIABRBFGG\'+**<<@@PPRR""#3#+II*..\nM.NJLL\\XZ"RVTT$(,L<024VTUUMIS$,HHI9122BFEE%)**:6,,<8(0D-6 0 @\nM   $0@899)!!""&%%%***::<<@PRZ(#0D%4  "  @     #\'D!1)L1S+T1Q/\nM\\B3/$BU1$SW3,T73-$W3-6U5=W555W755G755F73-6W35F735757EW57MG5=\nMUW5=UW5=UW5=UW5=UW7=MFT@-&05 " ! * C.9KB*:)B&J[B.JH%A(:L @!D\nM   $ * )GB$JHB9JHN9IGN=YGN=YGN=YGN=YG@>$AJP"   !  0      *!I\nMFJ9IFJ9IFJ9IFJ9IFJ9IFJ9IFF99EF59EF59EF59EF59EF59EF59EF59EF59\nMEF59EF59EF59EF590&C(*@!  @! QW$D1U(D15(DQW(L!P@-604 R   " ! \nM4BS%4C3\'<SQ\'=$3\'=$Q)E53)E5S+M5P-" U9!0   @ (      ! $S3%4BS\'\nMDBQ/,S554SU55#754SW55%55555555555555555555555555555555555555\nM5555555558\'0D%4   0   &=9IAJ@ @SDED@-&05 (     0@0Q3# @-604 \nM  0  $B1Y"2)DI-22CD,DL4DJ9234DIY%)-\'-<D8E%)**:644DHII9122BD,\nMDN4HJ9234DI)C)+%**E2DU)*>923)S7)V)-22BFEE%)**:644DI9D)(G+>D:\nME%)*28Z2!BW9U)-22HE2E"@YV9Z44DHII9122BFEE%)*^:"4#T(II9122KG:\nMDVL]*:644DH9HY3P22FEE%)**:644DHII912R@A"0U8! $   (!QUBB\'HI/H\nM?\'&&<J8I2"J4)G1ODJ/D.<FMM-R<;L(YIYM3SOGDG\'."T)!5   @  "$$%)(\nM(8444D@AA112B"&&&\'+(*:>@@@HJJ:2BBBJJK++,,LLLL\\PRRRRSS#+KK*..\nM.@LIA))""ZW5&&N,L=7>G+0U1RF=E%)**:64SCGGG" T9!4   ( 0"!DD$$&\nM&6444H@AIIQRRBFHI)(*" U9!0   @ (    $"73,1W1$171$1W1$1W1$1W/\nM\\1Q/$B71\\BQ1,SU3-$W35657EG79EFU7EW5;EWW;MW7;MGW=V(W?.([C.([C\nM.([C.([C.(YC"$)#5@$ (    $(((8044D@AA91BBC\'GH(,00BF!T)!5   @\nM (      17$4QY$<29(D2[(LS=(T3=,T3_1$S_14SQ5ET19MS_5LT?9<3_54\nM3Q554S5=TU5=UW5=U55E579MV[9MV[9MV[9MV[9MV[9E(#1D%0 @ 0"@(SF2\nM(BF2(CF.(SF2!(2&K ( 9   ! "@*(KB.([D6)(E:9(HF99JN9KLZ9XNZJ(.\nMA(:L @   0 $      !@B(9HB(YHB9HHBJ(HBJ(HBJ(HBJ(HBJ(HBJ(HBJ(H\nMBJ(HBJ(HBJ(HBJ(HBJ(HBJ(HBI[G>9[G>9[G>4!HR"H 0 ( 0$=R),=2+$52\nM),5R+ <(#5D% ,@   @ P#$<0U(DQ[(L2],TS_,\\3_1$411%TU1-%0@-604 \nM  ( "       0%$4R[$<2=(<3Q(=41(ET1(E41,U411%411%411%411%411%\nM411%411%411%411%411%411%411%412!T)"5   9  !#O19==!".@M!"+358\nM"C\'EI/2@.0:AM%:#IQ S##$-(G2022<UJ)!!PXCBH$HI%41*@Q F-XX@"T*X\nMGE\'E/ A"0U8$ %$  ( QR#\'$&\'+.2<F@1,XQ"9V4QCE\'I9/242HMEA@S*2&F\nM$F/DG)/22<FDE!A+BIVD$F.)K0  @  \' (  "Z\'0D!4!0!0  &(,4@HIA912\nMSBGFD%+*,>4<4DHYIIQ3SCD(\'82*.0:=@Q II1Q3SBGG\'(3,0>6<@]!!*   \nM(, ! "# 0B@T9$4 $"< X\' DSY,T2Q0E2Q-%SQ1=UQ--5Y8TS10U4515S1--\nMU515V19-598E31-%3?144Q-%5155TY9-595MSS1EV515W195U;9EW39^5[9]\nMWS--6195U;9-U;5U5Y9]7[9M79@TS30U45153115U515W395U;8U4715455E\nM6515679=6==55_9U2Q15U5--V15-U;556?5M599UWU1575==V==56?9]6]>%\nMX]9]X1A5U=9-5]5UU95U7]9E8;=UWU@F33--311551-%53555;=-5;5U2Q15\nM551-6?9,U9556=9U595E71-%U155599%595E57:%7Y5=7Q=55;=56?9]4W5U\nMW=9U89AE71=.U=5U599]995=8;A]71EN73>.SS1MVW157Q=55?=M7Q>&V;:-\nM85157U=EV3=6619^W1>.NNXS1E7U=5-VA5V595^XC5TY=M]7CEG7E6\'6=>.X\nM=5TI\')7E%X;&:\\O&,.NR<MRZKBR_L!-^95B.SS1MVU1573=5U?=E71=^6]>-\nM95157U=E6?E-5]:%7=>59?=]H:BJOJ_*LB^LLFP<MZ\\;QR[\\2M>VA6/V?>.8\nM;5WH"T.^3AE>W1:.6_<9M^\\;?6%(6(:E  "  0< @  3RD"A(2L"@#@! $8I\nMYQ13$"K%(\'004NH@I%0Q!B%S3DK%\')102DHAE-0JQB!4CDG(G),22F@IE-)2\nM!Z&E4$IKH9364FLQIM1:[""D%$II+9326FHIQM1:C15C$#+\'I&3,00FEM!1*\nM22ES3DKGH*3..2JEI-1*2:U5C$G)G*/2.2BII!)3*:FU4$IKI9062THQMM12\nM;2W&&DII+9326BFIQ=12;:VU6BO&(&2.2<F8DQ)*22F4TEK%F)0..BJ9<Y)*\nM2:V5DE+,G)/2.2>I@XY*2:6UDDI+H9362DJQA5)::ZW5FE)K-9326DFIM5)*\nM:RVV6E-+-7404@JEM!9*:2VU5FMJ+<902FNEI!9+*K&U%FMMK=482FDME!);\nM*:G%%EN-K<584TLUIM1B;;\'5&EM-/=;:<THIQM12C:W%FEMMO=5:>^\\@I!1*\nM:2V4TEIJ+<;66JVAE-9**K&%4EILK=786HPYE-):*:G%DDIL+;9:6VPUII1B\nM;+\'5FE*+-=;:<VRUY=1:K*W%6E-+-<9:<X\\U]50  ,"  P! @ EEH-"0E0! \nM%   88A2CDE)$\'+,.4H)0LPY)ZER#$()+67,00@EM<XY"2G%UCD\');462RHM\nMQ59K*2FU%FLM  "@P $ (, &38G% 0H-60D 1 $ (,8@Q1B$!AFE&(/0&*,4\nM8Q JI1AS3DJE%&/.2<D8<PY"*1ECSD$H*8102BHIA1!*22FE @  "AP   )L\nMT)18\'*#0D!4!0!0  & ,8@PQAJ!S5#(I$81.2B>I@1!2"BUUE%)KI;6,4FFM\nMM-9 ""F%E#)*I;626D>IM)9:*P  [, ! .S 0B@T9"4 D < 0!BC%&/..6<0\nM8LPYZ* S"#\'FG(,0*L:<@PY""!5CSCD((83..>@@A!!"YYR#$$((H8,.0@BE\nME-)!""&$4DKI((000BFE=!!""*&44@H  "IP   (L%%D<X*1H$)#5@( >0  \nM@#%*.0>AE$8IQB"4DE*C%&,02DFI<@Y"*2W%5C$\'H9246NL@E))::S5V$$I)\nMJ<4:2RJMQ5ACKB6EUEJ,,>?46FRQUIIK2BW&6&O-N0  W 4\' + #&T4V)Q@)\nM*C1D)0"0!P" (*048XPYAQ12BC\'GG$-**<68<\\XII1ACS#GGE&*,,>:<<XPQ\nMQIQSSCG&F\'/..><<<\\XYYYQSCCGGG\'/..>><<\\XYYYQSSCGGG\'/."0  *G  \nM  BP461S@I&@0D-6 @"I    (59::ZVUUA(\'K;766FNM-1!::ZVUUEI+K;76\nM6FNMM19::ZVUUEIKK;766FNMM=9::ZVUUEIKK;766FNMM=9::ZVUUEIKK;76\nM6FNMM9922BFEE%)**:644DHII9122BFEE%)**:644DJI $"_"@< _P<;5D<X\nM*1H++#1D)0 0#@  &,.8@XPY!Z&42"GHI(0.0@FI-$HY"*6#4$I))7-.2DJE\nMI)122IES4E(J):644NN@I-):2BFUUF(\'(:744DJIM=8Z"*6DU%)K+<;802@E\nMI99:B[\'%4$I*+;58:\\ZYAE)2:JVU&&NM-9344HLUUEAKK2&EE%J,L<:<:RTI\nMM19CC+76G\'-)J;468\\PUUUH+ .!N< " 2+!QAI6DL\\+1X$)#5@( (0$ "$*,\nM.>><<Q!"""%2BC\'GG(,00@@A1$HQYIQSSD$((82,,>><<Q!"""&$D#\'FG\',0\nM0@@AA! RYYQS#D(((8000N:<<]!!""&$$$+HG(,00@@AA!!""9US$$(((800\nM0@@AA!!"""&$$$(((8000@@AA!!"*"&$$$(((8000@@EA!)"""&$$$((H802\nM0@@AA!!""2&$4$(((8000BFEA%)*"2&$$$((I9000B@AA!!"**&$$$H)H0  \nM@ ,\' (  (^@DH\\HB;#3AP@-0:,A* ( ,  !QV&KLJ<7((.6@A-9*9)1R4&HO\nME5**06<Q9D@9I1CUDC&F%&-4:^@<4HI1#YUS2BG#+)662BB1DA)SSKEV# ( \nM " ( # 0(3.!0 $4&,@ @ .$!"D H+# T#%<! 3D$C(*# K\'A\'/2:0, $(3(\nM#)&(6 P2$ZJ!HF(Z %A<8,@\'@ R-C;2+"^@RP 5=W\'4@A" $(8C% 120@(,3\nM;GCB#4^XP0DZ1:4. @       0 >  "2#2 B(IHYC@Z/#Y 0D1&2$I,3E   \nM      * #P" ) 6(B(AFCJ/#XP,D1&2$I,3D!"4            (" @     \nM  0    ("$]G9U, !  @        #Q[<: (   "\'(&<("SDR 0$! 0$! 0$!\nM="J/["8 BFA/$X :&U\\O9)MU3\\^TM[,:IF$*24A"+I/+Y#*YD(1D\'>M8QSK6\nMD;F^_NO7KU^_?D41]!@+AULJ_OGF0)7;;@7P, /],U?S&5_K#]E,]Y +95 "\n:EGC&O"^8]X4)S\\>,(RE=)P(*#@X.#@X.#@X \n \nend\n')
beep_uu = StringIO.StringIO('begin 666 -\nM3V=G4P "          #.[VEI     &S3:=$!\'@%V;W)B:7,      4 ?    \nM    8&T       "9 4]G9U,             SN]I:0$   #,4B(H"RW_____\nM______^U W9O<F)I<QT   !8:7!H+D]R9R!L:6)6;W)B:7,@22 R,# R,#<Q\nM-P     !!79O<F)I<Q)"0U8!   !  Q2%"$EF4)*8RF54E(I)1EC$$IHH7/4\nM.2>=@]1!B,48XX,Q+M9B:VD14E8A)1E3#%MHE5)4*0498U)*:*%SUCE&G7,4\nM0B?%"&.,+KZV8EM)\'6/6,28=4XI**)UCU#$&G6-02@@E=!9"1R5TT#D&Q1AC\nMC#\'"UR);BJW%GDKIK86,6TJUUMI2*K:55&2*Q1@A? Y&]^);2L488XPQQ@AC\nM9,N!T)!5   !  ! ! %"0U8!  H  ,(P%$51@-"050! !@"  !1%<13\'<21\'\nMDBS\' D)#5@$ 0    @  &([B*(XC.9)D29KE::(GBJ:KZ[JNZ[INV[9MV[8-\nMA(:L! #(   8AB&\'WDG,D%.0228I5<PY"*\'U#CGE%&324L:88HQ1SI!3##$%\nM,8;0*840U$XYI0PB"$-(G63.($L]Z.!BYS@0&K(B (@"  ",08PAQI!S#$H&\nM(7*.2<@@1,XY*9V43$HHK;2620DME=8BYYR43DHFI;064LNDE-9"*P4   0X\nM   $6 B%AJP( *(  !"#D%)(*<248DXQAY12CBG\'D%+,.<68<HPQZ"!4S#\'(\nM\'(1(*<48<TXYYB!D#"KF\'(0,,@$   $.   !%D*A(2L"@#@! (,D:9JE::)H\nM:9HH>J:HJJ(HJJKE>:;IF::J>J*IJJ:JNJZIJJYL>9YI>J:HJIXIJJJIJJYK\nMJJKKBJIJRZ:KVK;IJK;LRK)NN[*LVYZJRK:INK)NJJYMN[)LZZXLV[KD>:KJ\nMF:;K>J;INJKKVK+JNK+MF:;KBJHKVZ;KRK+KRK:MRK*N:Z;INJ*KVJZINK+M\nMRJYMN[*L^Z;KZK;JRKJNRK+NV[:N^[*M"[OHNK:NRJZNJ[*LZ[(MZ[9LVT+)\nM\\U35,TW7]4S3=577M6W5=6U;,TW7-5U7ED75=675E75==65;]TS3=4U7E673\nM5659E67==F57ET77M6U5EGU==65?EVW=]V59UWW3=75;E67;5V59]V5=]X59\nMMWW=4U5;-UU7UTW7U7U;UWUAMFW?%UU7UU79UH55EG7?UGUEF\'6=,+JNKJNV\nM[.NJ+.N^KNO&,.NZ,*RZ;?RNK0O#J^O&L>N^KMR^CVK;OO#JMC&\\NFX<N[ ;\nMO^W[QK&IJFV;KJOKIBOKNFSKOF_KNG&,KJOKJBS[NNK*OF_KNO#KOB\\,H^OJ\nMNBK+NK#:LJ_+NBX,NZX;PVK;PN[:NG#,LBX,M^\\KQZ\\+0]6VA>\'5=:.KV\\9O\nM"\\/2-W:^  "  0< @  3RD"A(2L"@#@!  8A"!5C$"K&((004@HAI%0Q!B%C\nM#DK&\')002DDAE-(JQB!DCDG(\'),02FBIE-!***6E4$I+H9364FHMIM1:#*&T\nM%$IIK9326FHIMM12;!5C$#+GI&2.22BEM%9*:2ES3$K&H*0.0BJEI-)*2:UE\nMSDG)H*/2.4BII-)22:FU4$IKH9362DJQI=)*;:W%&DII+:326DFIM=12;:VU\nM6B/&(&2,0<F<DU)*2:F4TEKFG)0..BJ9@Y)**:F5DE*LF)/202@E@XQ*2:6U\nMDDHKH9362DJQA5)::ZW5F%)+-9226DFIQ5!*:ZVU&E,K-8504@NEM!9*::VU\nM5FMJ+;900FNAI!9+*C&U%F-MK<482FFMI!);*:G%%EN-K;584TLUEI)B;*W5\nMV$HM.=9::THMUM)2C*VUF%M,N<58:PTEM!9*::V4TEI*K<766JVAE-9**K&5\nMDEILK=786HPUE-)B*2FUD$ILK;586VPUII9B;+\'56%*+,<98<TNUU91:BZVU\nM6$LK-<88:VXUY5(  ,"  P! @ EEH-"0E0! %   8 QCC$%H%\'+,.2F-4LXY\nM)R5S#D((*67.00@AI<XY"*6TU#D\'H9240BDII11;*"6EUEHL  "@P $ (, &\nM38G% 0H-60D 1 $ (,8HQ1B$QB"E&(/0&*,48Q JI1AS#D*E%&/.0<@8<\\Y!\nM*1ECSD$G)8000BFEA!!"**64 @  "AP   )LT)18\'*#0D!4!0!0  & ,8@PQ\nMAB!T4CHI$81,2B>ED1):"REEEDJ*)<;,6HFMQ-A(":V%UC)K)<;28D:MQ%AB\nM*@  [, ! .S 0B@T9"4 D < 0!BC%&/..6<08LPY""$T"#\'F\'(00*L:<<PY"\nM"!5CSCD\'(83..><@A!!"YYQS$$((H8,00@BEE-)!""&$4DKI((000BFE=!!"\nM"*&44@H  "IP   (L%%D<X*1H$)#5@( >0  @#%*.2<EI48IQB"D%%NC%&,0\nM4FJM8@Q"2JW%6#$&(:768NP@I-1:C+5V$%)J+<9:0TJMQ5AKSB&EUF*L-=?4\nM6HRUYMQ[:BW&6G/.N0  W 4\' + #&T4V)Q@)*C1D)0"0!P! (*048XPYAY1B\nMC#\'GG$-*,<:8<\\XIQAASSCGG%&.,.>><<XPQYYQSSCG&F\'/..>><<\\XYYZ"#\nMD#GGG\'/00>B<<\\XY""%TSCGG\'(00"@  *G    BP461S@I&@0D-6 @#A  " \nM,9122BFEE%)*J*.44DHII912 B&EE%)**:644DHII9122BFEE%)**:644DHI\nMI9122BFEE%)**:644DHII9122BFEE%)**:644DHII9122BFEE%)**:644DHI\nMI9122BFEE%)**:644DHII9122BFEE%)**:644DHII9122BF54DHII9122BFE\nME%)**:4 (-\\*!P#_!QMG6$DZ*QP-+C1D)0 0#@  &,,8A(PY)R6EAC$(I71.\nM2DDE-8Q!**5S$E)**8/06FJEI-)22AF$E&(+(9646@JEM%9K*:FUE%(H*<4:\nM2TJII=8RYR2DDEI+K;:8.0>EI-9::JW%$$)*L;764FNQ=5)22:VUUEIM+:24\nM6FLMQM9B;"6EEEIKJ<766DRIM19;2RW&UF)+K<788HLQQAH+ .!N< " 2+!Q\nMAI6DL\\+1X$)#5@( (0$ !#)*.>><@Q!"""%2BC\'GH(,00@@A1$HQYIR#$$((\nM(82,,><@A!!""*&4D#\'F\'(000@@AA%(ZYR"$4$H)I9122N<<A!!""*644DH)\nM(8000BBEE%)**2&$$$HII9122BDEA!!"**644DHII8000BBEE%)**:64$$(H\nMI9122BFEE!)""*&44DHII9120@BEE%)**:644DHH(8122BFEE%)*"2644DHI\nMI9122BDAE%)**:644DHII0  @ ,\' (  (^@DH\\HB;#3AP@,0     @ "3 "!\nM 8*"40@"A!$(       ( /@  $@*@(B(:.8,#A 2%!88&AP>("(D        \nM        !$]G9U, !" #        SN]I:0(   #XAF< !1<7%QD6JN\'W;G,D\nM 0#?W@$     @-G! 0    "JX?=N<R0! -_> 0    " 4V$0     *KA]VYS\nM) $ W]X!     (!381      IN%;L3N9 (!O[P      P&PX"     !N *;?\n4]TX[D@" QSL      \'#Z$@$     \n \nend\n')
tuut_uu = StringIO.StringIO('begin 666 -\nM3V=G4P "           -[M9I     +^:Y8H!\'@%V;W)B:7,      4 ?    \nM    8&T       "9 4]G9U,             #>[6:0$   "E:(Y^"RW_____\nM______^U W9O<F)I<QT   !8:7!H+D]R9R!L:6)6;W)B:7,@22 R,# R,#<Q\nM-P     !!79O<F)I<Q)"0U8!   !  Q2%"$EF4)*8RF54E(I)1EC$$IHH7/4\nM.2>=@]1!B,48XX,Q+M9B:VD14E8A)1E3#%MHE5)4*0498U)*:*%SUCE&G7,4\nM0B?%"&.,+KZV8EM)\'6/6,28=4XI**)UCU#$&G6-02@@E=!9"1R5TT#D&Q1AC\nMC#\'"UR);BJW%GDKIK86,6TJUUMI2*K:55&2*Q1@A? Y&]^);2L488XPQQ@AC\nM9,N!T)!5   !  ! ! %"0U8!  H  ,(P%$51@-"050! !@"  !1%<13\'<21\'\nMDBS\' D)#5@$ 0    @  &([B*(XC.9)D29KE::(GBJ:KZ[JNZ[INV[9MV[8-\nMA(:L! #(   8AB&\'WDG,D%.0228I5<PY"*\'U#CGE%&324L:88HQ1SI!3##$%\nM,8;0*840U$XYI0PB"$-(G63.($L]Z.!BYS@0&K(B (@"  ",08PAQI!S#$H&\nM(7*.2<@@1,XY*9V43$HHK;2620DME=8BYYR43DHFI;064LNDE-9"*P4   0X\nM   $6 B%AJP( *(  !"#D%)(*<248DXQAY12CBG\'D%+,.<68<HPQZ"!4S#\'(\nM\'(1(*<48<TXYYB!D#"KF\'(0,,@$   $.   !%D*A(2L"@#@! (,D:9JE::)H\nM:9HH>J:HJJ(HJJKE>:;IF::J>J*IJJ:JNJZIJJYL>9YI>J:HJIXIJJJIJJYK\nMJJKKBJIJRZ:KVK;IJK;LRK)NN[*LVYZJRK:INK)NJJYMN[)LZZXLV[KD>:KJ\nMF:;K>J;INJKKVK+JNK+MF:;KBJHKVZ;KRK+KRK:MRK*N:Z;INJ*KVJZINK+M\nMRJYMN[*L^Z;KZK;JRKJNRK+NV[:N^[*M"[OHNK:NRJZNJ[*LZ[(MZ[9LVT+)\nM\\U35,TW7]4S3=577M6W5=6U;,TW7-5U7ED75=675E75==65;]TS3=4U7E673\nM5659E67==F57ET77M6U5EGU==65?EVW=]V59UWW3=75;E67;5V59]V5=]X59\nMMWW=4U5;-UU7UTW7U7U;UWUAMFW?%UU7UU79UH55EG7?UGUEF\'6=,+JNKJNV\nM[.NJ+.N^KNO&,.NZ,*RZ;?RNK0O#J^O&L>N^KMR^CVK;OO#JMC&\\NFX<N[ ;\nMO^W[QK&IJFV;KJOKIBOKNFSKOF_KNG&,KJOKJBS[NNK*OF_KNO#KOB\\,H^OJ\nMNBK+NK#:LJ_+NBX,NZX;PVK;PN[:NG#,LBX,M^\\KQZ\\+0]6VA>\'5=:.KV\\9O\nM"\\/2-W:^  "  0< @  3RD"A(2L"@#@!  8A"!5C$"K&((004@HAI%0Q!B%C\nM#DK&\')002DDAE-(JQB!DCDG(\'),02FBIE-!***6E4$I+H9364FHMIM1:#*&T\nM%$IIK9326FHIMM12;!5C$#+GI&2.22BEM%9*:2ES3$K&H*0.0BJEI-)*2:UE\nMSDG)H*/2.4BII-)22:FU4$IKH9362DJQI=)*;:W%&DII+:326DFIM=12;:VU\nM6B/&(&2,0<F<DU)*2:F4TEKFG)0..BJ9@Y)**:F5DE*LF)/202@E@XQ*2:6U\nMDDHKH9362DJQA5)::ZW5F%)+-9226DFIQ5!*:ZVU&E,K-8504@NEM!9*::VU\nM5FMJ+;900FNAI!9+*C&U%F-MK<482FFMI!);*:G%%EN-K;584TLUEI)B;*W5\nMV$HM.=9::THMUM)2C*VUF%M,N<58:PTEM!9*::V4TEI*K<766JVAE-9**K&5\nMDEILK=786HPUE-)B*2FUD$ILK;586VPUII9B;+\'56%*+,<98<TNUU91:BZVU\nM6$LK-<88:VXUY5(  ,"  P! @ EEH-"0E0! %   8 QCC$%H%\'+,.2F-4LXY\nM)R5S#D((*67.00@AI<XY"*6TU#D\'H9240BDII11;*"6EUEHL  "@P $ (, &\nM38G% 0H-60D 1 $ (,8HQ1B$QB"E&(/0&*,48Q JI1AS#D*E%&/.0<@8<\\Y!\nM*1ECSD$G)8000BFEA!!"**64 @  "AP   )LT)18\'*#0D!4!0!0  & ,8@PQ\nMAB!T4CHI$81,2B>ED1):"REEEDJ*)<;,6HFMQ-A(":V%UC)K)<;28D:MQ%AB\nM*@  [, ! .S 0B@T9"4 D < 0!BC%&/..6<08LPY""$T"#\'F\'(00*L:<<PY"\nM"!5CSCD\'(83..><@A!!"YYQS$$((H8,00@BEE-)!""&$4DKI((000BFE=!!"\nM"*&44@H  "IP   (L%%D<X*1H$)#5@( >0  @#%*.2<EI48IQB"D%%NC%&,0\nM4FJM8@Q"2JW%6#$&(:768NP@I-1:C+5V$%)J+<9:0TJMQ5AKSB&EUF*L-=?4\nM6HRUYMQ[:BW&6G/.N0  W 4\' + #&T4V)Q@)*C1D)0"0!P! (*048XPYAY1B\nMC#\'GG$-*,<:8<\\XIQAASSCGG%&.,.>><<XPQYYQSSCG&F\'/..>><<\\XYYZ"#\nMD#GGG\'/00>B<<\\XY""%TSCGG\'(00"@  *G    BP461S@I&@0D-6 @#A  " \nM,9122BFEE%)*J*.44DHII912 B&EE%)**:644DHII9122BFEE%)**:644DHI\nMI9122BFEE%)**:644DHII9122BFEE%)**:644DHII9122BFEE%)**:644DHI\nMI9122BFEE%)**:644DHII9122BFEE%)**:644DHII9122BF54DHII9122BFE\nME%)**:4 (-\\*!P#_!QMG6$DZ*QP-+C1D)0 0#@  &,,8A(PY)R6EAC$(I71.\nM2DDE-8Q!**5S$E)**8/06FJEI-)22AF$E&(+(9646@JEM%9K*:FUE%(H*<4:\nM2TJII=8RYR2DDEI+K;:8.0>EI-9::JW%$$)*L;764FNQ=5)22:VUUEIM+:24\nM6FLMQM9B;"6EEEIKJ<766DRIM19;2RW&UF)+K<788HLQQAH+ .!N< " 2+!Q\nMAI6DL\\+1X$)#5@( (0$ !#)*.>><@Q!"""%2BC\'GH(,00@@A1$HQYIR#$$((\nM(82,,><@A!!""*&4D#\'F\'(000@@AA%(ZYR"$4$H)I9122N<<A!!""*644DH)\nM(8000BBEE%)**2&$$$HII9122BDEA!!"**644DHII8000BBEE%)**:64$$(H\nMI9122BFEE!)""*&44DHII9120@BEE%)**:644DHH(8122BFEE%)*"2644DHI\nMI9122BDAE%)**:644DHII0  @ ,\' (  (^@DH\\HB;#3AP@,0     @ "3 "!\nM 8*"40@"A!$(       ( /@  $@*@(B(:.8,#A 2%!88&AP>("(D        \nM        !$]G9U, !( ^        #>[6:0(   #)%V%Y0!@9&1D9&1D9&1D9\nM&1D9&1D9&1D9&1D9&1D9&1D9&1D9&1D9&1D9&1D9&1D9&1D9&1D9&1D9&1D9\nM&1D9&1D9&AFFWZ2-6Q\\ \\!T     ;.0 ]F-\\2@    "FWZ2-6Q\\ \\!T     \nM;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\nM\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^D\nMC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0  \nM  "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^\nMC$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     \nM;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\nM\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^D\nMC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0  \nM  "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^\nMC$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     \nM;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\nM\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^D\nMC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0  \nM  "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^\nMC$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     \nM;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\nM\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^D\nMC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0  \nM  "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^\nMC$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     \nM;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\nM\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^D\nMC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0  \nM  "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^\nMC$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     \nM;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\nM\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^D\nMC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0  \nM  "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^\nMC$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     \nM;&0#P7Z,3@D     IM^DC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\nM\'0    !L9 /!?HQ."0    "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^D\nMC5L? / =     &QD \\%^C$X)     *;?I(U;\'P#P\'0    !L9 /!?HQ."0  \nM  "FWZ2-6Q\\ \\!T     ;&0#P7Z,3@D     IM^DC5L? -CO      39E$$&\nA>3<^)0    "FWJ2%JP\\ [\'<      BTB(NZ-=@8     \n \nend\n')

tick_fil = StringIO.StringIO()
beep_fil = StringIO.StringIO()
tuut_fil = StringIO.StringIO()

uu.decode(tick_uu, tick_fil)
uu.decode(beep_uu, beep_fil)
uu.decode(tuut_uu, tuut_fil)

tick_ogg = StringIO.StringIO(tick_fil.getvalue())
beep_ogg = StringIO.StringIO(beep_fil.getvalue())
tuut_ogg = StringIO.StringIO(tuut_fil.getvalue())

snd_tick = pygame.mixer.Sound(tick_ogg)
snd_beep = pygame.mixer.Sound(beep_ogg)
snd_tuut = pygame.mixer.Sound(tuut_ogg)

def tick():
    snd_tick.play()
    
def beep():
    snd_beep.play()

def tuut():
    snd_tuut.play()

SOUND = True
PAINT_TREE = True
SHUFFLE = False
PAINT_SPHERE = True
PAINT_HIT = False

pygame.init()

SCR_RES = pygame.display.list_modes()[0]
#SCR_RES = [800,600]

COL_FG = (0,0,0)
COL_BANG = (128,128,128)
COL_LIGHT = (240,240,240)
COL_VLIGHT = (220,220,220)
COL_TLIGHT = (230,230,230)
COL_BG = (255,255,255)

#COL_FG = (255,255,255)
#COL_BANG = (128,128,128)
#COL_LIGHT = (20,20,20)
#COL_VLIGHT = (30,30,30)
#COL_BG = (0,0,0)


NUMPOINTS = 100
RADMIN = 10
RADMAX = 30
#SFRICT = 0.9
RFRICT = 0.99
GRAV = 0.2
MAXIMPULSE=4

disp = pygame.display.set_mode(SCR_RES,pygame.FULLSCREEN)
disp.fill(COL_BG)
pygame.display.flip()

class Point :
    """ A class representing a point in a 2d plane. """

    def __init__(self, pos):
        " Represents a point on a 2d plane. "
        self.pos = pos
        
    def getX(self):
        return self.pos[0]
        
    def setX(self, x):
        self.pos[0] = x
        
    def getY(self):
        return self.pos[1]
        
    def setY(self, y):
        self.pos[1] = y

    def setPos(self,pos):
        self.pos = pos
        
    def getPos(self,):
        return self.pos
        
    def addPos(self, pos):
        self.pos[0] += pos[0]
        self.pos[1] += pos[1]
        
    def distance2(self, other):
        return ((self.getX()-other.getX())**2)+((self.getY()-other.getY())**2)
        
    def distance(self, other):
        return math.sqrt(self.distance2(other))
        
    def distVec(self, other):
        dx = other.getX()-self.getX()
        dy = other.getY()-self.getY()
        return [dx,dy]
    
    def length(self,vec):
        return math.sqrt(vec[0]**2+vec[1]**2)
        
    def norm(self, vec, len=1):
        r = math.sqrt(vec[0]**2 + vec[1]**2)
        return [len*vec[0]/r, len*vec[1]/r]
        
    def addVec(self, vec1, vec2):
        return [vec1[0]+vec2[0],vec1[1]+vec2[1]]
                
    def multVec(self, vec1, s):
        return [vec1[0]*s,vec1[1]*s]
        
    def projectVec(self, a,b):
        return self.norm(a, (a[0]*b[0]+a[1]*b[1])/math.sqrt(a[0]**2+a[1]**2) )
        
class Particle(Point) :
    
    def __init__(self, pos, mass, impulse):
        Point.__init__(self, pos)
        self.mass = mass
        self.impulse = impulse
        self.colliders = []
        
    def getSize(self,):
        return self.size
        
    def setSize(self,):
        self.size = size
        
    def getMass(self,):
        return self.mass
        
    def setSize(self,):
        self.mass = mass
        
    def getImpulse(self,):
        return self.impulse
        
    def addImpulse(self, impulse):
        self.impulse[0] += impulse[0]
        self.impulse[1] += impulse[1]

    def setImpulse(self, impulse):
        self.impulse = impulse
        
    def evolve(self, dt):
        for other in self.colliders:
            if not self.collide(other):
                self.colliders.remove(other)
        dpx = self.impulse[0] / self.mass * dt
        dpy = self.impulse[1] / self.mass * dt
        
        self.impulse[0] *= RFRICT ** (dt / 1000.0)
        self.impulse[1] *= RFRICT ** (dt / 1000.0)
        
        nx = self.getX()+dpx
        ny = self.getY()+dpy
        self.setPos([nx, ny])
        
    def elasticCollision(self, other, dt):
        
        if other in self.colliders:
            return
            pass
        else :
            self.colliders.append(other)
            other.colliders.append(self)
        
        #self.paint(disp,COL_BANG)
        #other.paint(disp,COL_BANG)
        
        #sdt = self.seperate(other, dt*2)
        #if not self.collide(other):
        #    raise "!!!"
                
        m1 = self.getMass()
        v1 = self.getImpulse()
        m2 = other.getMass()
        v2 = other.getImpulse()
        
        # 1 stoesst auf 2
        # 2 ruht -> impuls v2 von v1 relativ bei 1 abziehen
        
        i1 = [v1[0]-v2[0],v1[1]-v2[1]]
        i2 = [0,0]
        
        # Stossparameter 'b'
        # b = (r1+r2)*cos(alpha)
        # alpha = arccos(b/(r1+r2))
        # b ist im rechten winkel zum impuls
        
        inormale = [i1[1],-i1[0]]
        m1m2 = self.distVec(other)
        bvect = self.projectVec(inormale,m1m2)
        b = self.length(bvect)

        if PAINT_HIT :
            self.paint(disp,(0,0,255))
            other.paint(disp,(0,0,255))
            pygame.draw.line(disp,(255,0,0),self.getPos(),self.addVec(self.getPos(),bvect),2)
            pygame.draw.line(disp,(0,255,0),self.getPos(),self.addVec(self.getPos(),self.multVec(i1,50)),3)
        
        r1 = self.size
        r2 = other.size
        alpha = math.acos(b/(r1+r2))
        
        rp1 = i1
        rpr = self.projectVec(m1m2,rp1)
        rpt = self.multVec(rp1,math.cos(alpha))
        
        if PAINT_HIT :
            pygame.draw.line(disp,(0,255,0),other.getPos(),self.addVec(other.getPos(),self.multVec(rpr,50)),5)
            pygame.draw.line(disp,(0,255,0),other.getPos(),self.addVec(other.getPos(),self.multVec(rpt,50)),3)
        
        # impuls fuer objekt 2
        rp_2 = self.multVec(rpr,(2*m2)/(m1+m2))
        
        rp_r = self.multVec(rpr,(m1-m2)/(m1+m2))
        
        # impuls fuer objekt 1
        rp_1 = self.addVec(rpt,rp_r)
        
        # impuls vom Anfang wieder dazu
        i1 = self.addVec(rp_1,v2)
        i2 = self.addVec(rp_2,v2)
        
        self.setImpulse(i1)
        other.setImpulse(i2)
        
        #self.evolve(sdt)
        #other.evolve(sdt)
        
        return
        
class Sphere(Particle):
    
    def __init__(self, pos, mass, acceleration, size):
        Particle.__init__(self, pos, mass, acceleration)
        self.size = size
        
    def getSize(self,):
        return self.size
        
    def setSize(self, size):
        self.size = size
        
    def collide(self, other):
        dist = self.distance(other)
        rads = self.getSize()+other.getSize()
        if dist - rads <= 0:
            return True
        else:
            return False
            
    def bang(self, other, dt):
        self.elasticCollision(other, dt)
                    
    def paint(self,surf,col=COL_FG):
        pos = self.getPos()
        px = pos[0]
        py = pos[1]
        
        p2 = self.addVec(self.getPos(),self.multVec(self.getImpulse(),self.size))
        p2x = p2[0]
        p2y = p2[1]
        if PAINT_SPHERE:
            pygame.draw.circle(surf, COL_VLIGHT, [int(self.getPos()[0]),int(self.getPos()[1])], int(self.size), 1)
#        pygame.draw.line(surf, COL_LIGHT, (px-self.size, py),(px+self.size,py))
#        pygame.draw.line(surf, COL_LIGHT, (px, py-self.size),(px,py+self.size))        
        #pygame.draw.circle(surf, COL_BG, self.getPos(), int(self.size-1), 0)
        pygame.draw.line(surf, col, pos, p2, 1)
        pygame.draw.rect(surf, col, (p2x-1,p2y-1,3,3))
        
        #pygame.draw.line(surf, COL_LIGHT, (0,py),(SCR_RES[0],py))
        #pygame.draw.line(surf, COL_LIGHT, (px,0),(px,SCR_RES[1]))
        
    def seperate(self, other, dt):

        ax = self.getX()
        ay = self.getY()
        
        bx = other.getX()
        by = other.getY()
        
        r1 = self.getSize()
        r2 = other.getSize()
        
        cx = bx-ax
        cy = by-ay
        
        av = self.getImpulse() 
        bv = other.getImpulse()
        
        vx = (bv[0]-av[0]) / self.mass
        vy = (bv[1]-av[1]) / self.mass
        
        p = -(cx*vx+cy*vy) / (vx**2+vy**2)
        q = ((r1+r2)**2 - cx**2 - cy**2) / (vx**2+vy**2)
        
        t1 = p + math.sqrt(p**2+q)
        t2 = p - math.sqrt(p**2+q)
        
        if t1 < t2 :
            raise "time error on seperation!!!"
        
        if t2 > -(dt):
            self.evolve(t2)
            other.evolve(t2)
            return -t2
        else :
            return 0
        
            
class Node :

    def __init__(self, kind, parent):
        """ This is a node in a tree. """
        self.kind = kind
        self.l = None
        self.r = None
        self.o = None
        self.p = parent
        
    def addPoint(self, point): 
        """ Hooks a point in the tree. """
        if self.o == None :
            self.o = point
            if self.kind == 'x' :
                nkind = 'y'
            else :
                nkind = 'x'
            self.r = Node(nkind, self)
            self.l = Node(nkind, self)
            return self.p
        if self.kind == 'x' :
            if point.getX() < self.o.getX() :
                return self.l.addPoint(point)
            else :
                return self.r.addPoint(point)
        else :
            if point.getY() < self.o.getY() :
                return self.l.addPoint(point)
            else :
                return self.r.addPoint(point)
        
    def paint(self, surf, col=COL_FG):
        if self.o :
            self.o.paint(surf, col)
            if self.l.o :
                if PAINT_TREE:
                    pygame.draw.line(disp,COL_TLIGHT,self.o.getPos(), self.l.o.getPos())
                #self.l.o.paint(surf,col)
                self.l.paint(surf,col)
            if self.r.o :
                if PAINT_TREE:
                    pygame.draw.line(disp,COL_TLIGHT,self.o.getPos(), self.r.o.getPos())
                #self.r.o.paint(surf,col)
                self.r.paint(surf,col)
#            if self.r.o and self.l.o:
#                if PAINT_TREE:
#                    pygame.draw.line(disp,COL_TLIGHT,self.r.o.getPos(),self.l.o.getPos())
                
class World:
        
    def __init__(self,):        
        self.root = Node('x', None)
        self.storage = []
        self.ticks = pygame.time.get_ticks()
        
    def paint(self,surf):
        self.root.paint(surf)
        
    def trigger(self, pos):
        
        pygame.draw.line(disp, COL_BG, (pos[0],0), (pos[0],SCR_RES[1]),3)
        pygame.draw.line(disp, COL_BG, (0,pos[1]), (SCR_RES[0],pos[1]),3)
        pygame.draw.line(disp, COL_VLIGHT, (pos[0],0), (pos[0],SCR_RES[1]),1)
        pygame.draw.line(disp, COL_VLIGHT, (0,pos[1]), (SCR_RES[0],pos[1]),1)
        pygame.draw.line(disp, COL_FG, (pos[0]-RADMIN,pos[1]),(pos[0]+RADMIN,pos[1]))
        pygame.draw.line(disp, COL_FG, (pos[0],pos[1]-RADMIN),(pos[0],pos[1]+RADMIN))        
        
        lis = []
        for elem in self.storage:
            if elem.collide(Sphere(pos,None,None,1)):
                lis.append(elem)
        if SOUND and lis:
            beep()
        for elem in lis:
            rvx = elem.getX()-pos[0]
            rvy = elem.getY()-pos[1]
            rvec = elem.norm([rvx,rvy],MAXIMPULSE)
            elem.addImpulse(rvec)
                
    def evolve(self,):
        ticks = pygame.time.get_ticks()
        dt = (ticks - self.ticks)
        #dt = 150

        self.ticks = ticks

        def bounds(o):
            
            if o.getX() < o.size:
                i = o.getImpulse()
                o.setImpulse([-i[0],i[1]])
                o.setX(o.size)
                
            if o.getX() > SCR_RES[0] - o.size:
                i = o.getImpulse()
                o.setImpulse([-i[0],i[1]])
                o.setX(SCR_RES[0]-o.size)
                
            if o.getY() < o.size:
                i = o.getImpulse()
                o.setImpulse([i[0],-i[1]])
                o.setY(o.size)
                
            if o.getY() > SCR_RES[1] - o.size:
                i = o.getImpulse()
                o.setImpulse([i[0],-i[1]])
                o.setY(SCR_RES[1]-o.size)
                
            return


        def collide(n):
            if n.o :
                bounds(n.o)                        
                if n.l.o :
                    if n.o.collide(n.l.o):
                        n.o.bang(n.l.o, dt)
                    collide(n.l)
                if n.r.o :
                    if n.o.collide(n.r.o):
                        n.o.bang(n.r.o, dt)
                    collide(n.r)
                if n.r.o and n.l.o:
                    if n.r.o.collide(n.l.o):
                        n.l.o.bang(n.r.o, dt)
                        
        collide(self.root)
        del self.root
        self.root = Node('x', None)
        
        nstor = []
        
        if SHUFFLE:
            random.shuffle(self.storage)
            
        cx = 0.0
        cy = 0.0
        for elem in self.storage:
            # time
            elem.evolve(dt)
            
            # gravitation sucks
            dgrav = GRAV * dt / 1000
            elem.addImpulse([0,dgrav])
            
            # remember the center
            cx += elem.getX()
            cy += elem.getY()

            self.root.addPoint(elem)
            
        cx /= len(self.storage)
        cy /= len(self.storage)

        # average
        self.cx = cx
        self.cy = cy

        # show area of random
        if cy > SCR_RES[1]/2:
            ymin = cy
            ymax = SCR_RES[1]
        else:
            ymin = 0
            ymax = cy
        if cx < SCR_RES[0]/2:
            xmin = 0
            xmax = cx
        else :
            xmin = cx
            xmax = SCR_RES[0]
            
        pygame.draw.rect(disp, COL_LIGHT, (xmin,ymin,xmax-xmin,ymax-ymin))        
        pygame.draw.line(disp, COL_VLIGHT, (0,cy),(SCR_RES[0],cy))
        pygame.draw.line(disp, COL_VLIGHT, (cx,0),(cx,SCR_RES[1]))

        # do random
        if random.random() < 0.01:
            x = xmin+random.random()*(xmax-xmin)
            y = ymin+random.random()*(ymax-ymin)
            tick()
            self.trigger([x,y])
        
            
    def addElement(self, e):
        self.storage.append(e)
        self.root.addPoint(e)
        
def randimpuls():
    ax = (random.random()-0.5)*MAXIMPULSE
    ay = (random.random()-0.5)*MAXIMPULSE
    return [ax,ay]

r = World()
for i in range(NUMPOINTS):
    mass = RADMIN+random.random()*(RADMAX-RADMIN)
    x = mass+random.random()*(SCR_RES[0]-2*mass)
    y = mass+random.random()*(SCR_RES[1]-2*mass)
    impuls = randimpuls()    
    s = Sphere([x,y], mass, impuls, int(mass))    
    n = r.addElement(s)
    i += 1
    if i >= NUMPOINTS :
        break	

r.paint(disp)
pygame.display.flip()

run = True
buttondown = False
pos = [0,0]
while run:

    disp.fill(COL_BG)
    r.evolve()
    r.paint(disp)

    for event in pygame.event.get():
        if event.type in (pygame.KEYDOWN, ):
            if event.key == pygame.K_ESCAPE:
                run = False
            
        elif event.type in (pygame.MOUSEBUTTONDOWN, ):
            pos = event.pos
            buttondown = True
            
        elif event.type in (pygame.MOUSEBUTTONUP, ):
            buttondown = False
            
        elif event.type in (pygame.MOUSEMOTION, ):
            if event.buttons[0] == 1:
                buttondown = True
                pos = event.pos
            
    if buttondown:
        x = pos[0]
        y = pos[1]
        r.trigger(pos)
                
    pygame.display.flip()
