# Basic concept is to trigger the presence of certain basic shapes at
# certain times in the gameplay.
# If at any time the shapes on-screen match a combination shape (even if
# the components are part of another combination shape) then we form that
# combination shape.

# This code was written by Richard Jones and is placed in the Public
# Domain.

# BUG: combo made from 1 big and 1 little tri
# BUG: vert placement spacing not correct for combos
# TODO: form larger combos by breaking smaller combos
# TODO: better timing of baddies coming on-screen
# TODO: more powerful weapons for combos

import sys, math, random, sets
import pygame
from pygame.locals import *

FPS = 30

class LevelOver: pass
class PlayerDead: pass

def midpoint(a, b, M=1, N=2):
    ax, ay = a
    bx, by = b
    return (ax+M*(bx-ax)/N, ay+M*(by-ay)/N)
def translate(points, vec):
    return [(vec[0]+px, vec[1]+py) for px, py in points]
def rotate(points, rot):
    if not rot: return points
    s = math.sin(rot)
    c = math.cos(rot)
    return [(px*c-py*s, px*s+py*c) for px, py in points]
def scale(points, mag):
    return [(px*mag, py*mag) for px, py in points]
def rotateAboutFirst(points, rot):
    tx, ty = points[0]
    points = translate(points, (-tx, -ty))
    s = math.sin(rot)
    c = math.cos(rot)
    points = [(px*c-py*s, px*s+py*c) for px, py in points]
    return translate(points, (tx, ty))

def draw_outlined(points, fill, outline):
    ''' assumes points are for image topleft corner 0,0 '''
    maxx = max([x for x,y in points])
    maxy = max([y for x,y in points])
    size = (maxx + 10, maxy + 10)
    image = pygame.Surface(size)
    image.set_colorkey((0,0,0))
    points = [(x+5, y+5) for x,y in points]
    pygame.draw.polygon(image, outline, points, 1)
    pygame.draw.polygon(image, fill, points)
    return image

class PlayerSprite(pygame.sprite.Sprite):
    speed = 10
    def __init__(self, pos):
        pygame.sprite.Sprite.__init__(self)
        self.fired = 0
        self.move = 0
        points = [(20,0), (20,10), (30,10), (30,0), (50,20), (30,40),
            (20,40), (0,20)]
        self.image = draw_outlined(points, (100, 100, 100), (50, 50, 50))
        self.rect = self.image.get_rect()
        self.rect.midbottom = pos
        self.health = 3

    def update(self, dt, screen, pgroup):
        x,y = self.rect.midbottom
        x += self.move
        self.rect.midbottom = (x,y)

points = [(2,1), (3,1), (4,2), (3,4), (2,4), (1,2)]
pbull = draw_outlined(points, (1, 1, 1), (255, 255, 200))
class PlayerBulletSprite(pygame.sprite.Sprite):
    speed = -10
    def __init__(self, pos):
        pygame.sprite.Sprite.__init__(self)
        self.image = pbull
        self.rect = self.image.get_rect()
        self.rect.midbottom = pos
    def update(self, dt, screen, pgroup):
        x,y = self.rect.midbottom
        y += self.speed
        self.rect.midbottom = (x,y)
        if y < 0 or y > screen.get_rect().height:
            # off-screen
            pgroup.remove(self)
class EnemyBulletSprite(PlayerBulletSprite):
    speed = 10
    def __init__(self, pos):
        pygame.sprite.Sprite.__init__(self)
        self.image = pbull
        self.rect = self.image.get_rect()
        self.rect.midtop = pos

class World:
    def __init__(self, surface):
        self.surface = surface
        self.stack = []

    def render_lines(self, lines, colour, width=1):
        for function, param in self.stack[::-1]:
            lines = function(lines, param)
        return pygame.draw.lines(self.surface, colour, 1, lines, width)

    def render_poly(self, lines, colour, width=0):
        for function, param in self.stack[::-1]:
            lines = function(lines, param)
        return pygame.draw.polygon(self.surface, colour, lines, width)

class WorldSpriteGroup(pygame.sprite.RenderClear):
    def draw(self, world):
        """draw(surface)
           draw all sprites onto the surface

           Draws all the sprites onto the given surface."""
        sprites = self.sprites()
        for spr in sprites:
            self.spritedict[spr] = spr.draw(world)
        self.lostsprites = []

def S(a, t):
    return 1/(1 + math.exp(-a * t))

def smooth_step(frames):
    step = 20./frames
    t = -10
    l = []
    while t < 13:
        l.append(S(.5, t))
        t += step
    return l

ST_MOVING = 1
ST_SUCKING = 2
ST_ATTACHED = 3
class WorldSprite(pygame.sprite.Sprite):
    MOVE_SPEED = 5
    ROT_SPEED = math.pi / 40
    def __init__(self, pos, rot, points, colour, line=None):
        pygame.sprite.Sprite.__init__(self)
        self.pos = self.epos = pos
        self.rot = rot
        self.points = points
        self.colour = colour
        self.line = line
        self.steps = []
        self.rect = pygame.Rect(0,0,max([x for x,y in points]),
            max([y for x,y in points]))
        self.state = ST_MOVING

    def set_destination(self, pos, rot, frames):
        '''Move to the destination in # frames '''
        self.steps = smooth_step(frames)
        self.steps.reverse()
        self.spos = self.pos
        self.epos = pos
        self.srot = self.rot
        self.erot = rot
        x, y = self.pos

    def update(self, dt, game):
        if self.state not in (ST_MOVING, ST_ATTACHED): return
        if self.steps:
            #print self.__class__.__name__, 'moving', map(int, self.pos), map(int, self.epos)
            step = self.steps.pop()
            x, y = self.spos; ex, ey = self.epos
            dx, dy = ex-x, ey-y
            self.pos = x + dx*step, y + dy*step
            diff = self.erot - self.srot
            self.rot = self.srot + diff*step
        else:
            self.pos = self.epos
            self.rot = self.erot

    def draw(self, world):
        world.stack.append((translate, self.pos))
        if self.rot:
            world.stack.append((rotate, self.rot))
        if self.line is None:
            r = world.render_poly(self.points, self.colour)
        else:
            r = world.render_lines(self.points, self.colour, width=self.line)
        self.rect = r
        world.stack.pop()
        if self.rot:
            world.stack.pop()
        return r

class EnemySprite(WorldSprite):
    on_screen = False
    def __init__(self, pos, rot, colour, line=None):
        WorldSprite.__init__(self, pos, rot, self.POINTS, colour, line)
        self.health = len(self.points)
        self.fired = 1

    def update(self, dt, game, slave=False):
        WorldSprite.update(self, dt, game)

        if slave:
            return

        if not self.steps and self.state == ST_MOVING:
            self.on_screen = True
            self.random_destination(game.screen)

        self.handle_fire(game)

    def handle_fire(self, game):
        self.fired -= 1
        if self.fired: return
        bullet = EnemyBulletSprite(self.pos)
        game.egroup.add(bullet)
        self.fired = FPS + random.randint(1, FPS)

    def intended_rect(self):
        minx = None
        for x,y in rotate(self.points, self.erot):
            if minx is None:
                minx = maxx = x
                miny = maxy = y
            else:
                minx = min(minx, x)
                maxx = max(maxx, x)
                miny = min(miny, y)
                maxy = max(maxy, y)
        return pygame.Rect((minx, miny, abs(maxx-minx), abs(maxy-miny)))

    def random_destination(self, screen, x=None, y=None, rot=None):
        w = self.rect.width
        sw = screen.get_rect().width
        px, py = self.epos
        if y is not None:
            py = y
        hsw = sw/4
        if px > sw/2:
            px = max(w, hsw * random.random())
        else:
            px = min(sw-w, 3*hsw + hsw * random.random())
        frames = 40 + random.random()*40
        if rot is None:
            rot = self.rot
        self.set_destination((px, py), rot, frames)
        return frames

class ComboSprite(EnemySprite):
    def __init__(self, attracting, pos, rot, colour, line=None):
        WorldSprite.__init__(self, pos, rot, [(0,0)], colour, line)
        self.health = sum([len(obj[2].points) for obj in attracting])
        self.fired = 1
        self.attracting = attracting
        self.attached = []

    def update(self, dt, game):
        WorldSprite.update(self, dt, game)

        # update attached sprites
        for offset, rot, spr in self.attracting + self.attached:
            spr.update(dt, game, slave=True)

        if self.state == ST_SUCKING:
            for obj in list(self.attracting):
                if not obj[2].steps:
                    self.attached.append(obj)
                    self.attracting.remove(obj)
                    obj[2].colour = self.colour
            if not self.attracting:
                self.steps = []
                self.state = ST_MOVING

        if not self.steps and self.state == ST_MOVING:
            print 'NEW MOVE'
            self.rect = self.intended_rect()
            self.random_destination(game.screen)

        self.handle_fire(game)

    def set_destination(self, pos, rot, frames):
        EnemySprite.set_destination(self, pos, rot, frames)
        x, y = pos
        for offset, rot, spr in self.attracting + self.attached:
            xoff, yoff = offset
            spr.set_destination((x+SCALE*xoff, y+SCALE*yoff), rot, frames)

    def intended_rect(self):
        rect = None
        for o,r,s in self.attracting + self.attached:
            this = s.intended_rect()
            if rect is None:
                rect = this
            else:
                rect = rect.union(this)
        return rect

    def draw(self, world):
#        world.stack.append((translate, self.pos))
#        if self.rot:
#            world.stack.append((rotate, self.rot))
        rect = None
        for o,r,spr in self.attracting + self.attached:
            this = spr.draw(world)
            if rect is None:
                rect = this
            else:
                rect = rect.union(this)
        self.rect = rect
#        world.stack.pop()
#        if self.rot:
#            world.stack.pop()
        return rect

# BASIC SHAPES FOR ENEMIES
SCALE = 50
ROOT2 = math.sqrt(2)
class LittleTriEnemy(EnemySprite):
    COLOUR = (150, 50, 50)
    ROT = math.pi
    POINTS = [(x*SCALE, y*SCALE) for x,y in (0,0), (-1,-1), (1,-1)]
class MedTriEnemy(EnemySprite):
    COLOUR = (180, 80, 80)
    ROT = -math.pi/4
    POINTS = [(x*SCALE, y*SCALE) for x,y in (0,0), (0,2), (-2,0)]
class DiamondEnemy(EnemySprite):
    COLOUR = (80, 180, 80)
    ROT = 0
    POINTS = [(x*SCALE, y*SCALE) for x,y in (0,2), (1,1), (0,0), (-1,1)]
class QuadEnemy(EnemySprite):
    COLOUR = (50, 150, 50)
    ROT = math.pi/2
    POINTS = [(x*SCALE, y*SCALE) for x,y in (0,0), (1,1), (1,3), (0,2)]
class BigTriEnemy(EnemySprite):
    COLOUR = (50, 50, 150)
    ROT = 0
    POINTS = [(x*SCALE, y*SCALE) for x,y in (0,0), (2,2), (-2,2)]

# Composite shapes are defined around a mid-point which is the "origin
# point" of the first shape in the list. Generally that component is the
# primary or center shape.
BIG_BOX = [
    (LittleTriEnemy, (-1,-1), 0, (255, 0, 0)),
    (LittleTriEnemy, (0,0), math.pi/2, (255, 255, 0)),
    (MedTriEnemy, (2,-2), 0, (0, 255, 0)),
    (DiamondEnemy, (0,-2), 0, (0, 255, 255)),
    (QuadEnemy, (1,-1), 0, (0, 0, 255)),
    (BigTriEnemy, (0,0), math.pi/2, (255, 255, 255)),
    (BigTriEnemy, (0,0), 0, (255, 0, 255))
]

MED_PLUS_LITTLE = [
    (MedTriEnemy, (0,0), -math.pi/4, (0, 255, 0)),
    (LittleTriEnemy, (0,1+ROOT2), 0, (255, 255, 0)),
]

BIG_PLUS_LITTLIES = [
    (BigTriEnemy, (0,0), 0, (255, 255, 255)),
    (LittleTriEnemy, (-1,3), 0, (255, 0, 0)),
    (LittleTriEnemy, (1,3), 0, (255, 255, 0)),
]

DIAMOND_PUTTER = [
    (DiamondEnemy, (0,-1), 0, (0, 255, 255)),
    (QuadEnemy, (-3,0), -math.pi/2, (0, 0, 255)),
]

BEASTIE = [
    (QuadEnemy, (-2,-2), 0, (0, 0, 255)),
    (LittleTriEnemy, (0,0), -math.pi/2, (255, 0, 0)),
    (LittleTriEnemy, (1,1), 0, (255, 255, 0)),
    (MedTriEnemy, (2,0), math.pi/2, (0, 255, 0)),
    (DiamondEnemy, (0,-2), 0, (0, 255, 255)),
    (BigTriEnemy, (-4,0), -math.pi/2, (255, 255, 255)),
    (BigTriEnemy, (4,0), math.pi/2, (255, 0, 255))
]

COMBOS = [
    BEASTIE, BIG_PLUS_LITTLIES, MED_PLUS_LITTLE, DIAMOND_PUTTER,
]

# time in seconds until appearance
# class to spawn
INCOMING = (
    (0, LittleTriEnemy),
    (1, LittleTriEnemy),
    (2, LittleTriEnemy),
    (12, MedTriEnemy),
    (20, QuadEnemy),
    (20, DiamondEnemy),
    (30, BigTriEnemy),
    (30, BigTriEnemy),
)

R1 = math.atan(0.5)
R2 = math.pi/2
R3 = R2 - R1
SQRT5 = math.sqrt(5)
class PinWheel:
    line_colour = (200,200,200)
    fill_colours = ((190,200,160), (200,190,160))
    def rcolour(self):
        return random.choice(self.fill_colours)

    def render(self, screen, LOD):
        sw, sh = screen.get_rect().size
        self.surf = pygame.Surface((sw, sh), 1, screen)
        self.LOD = LOD
        for lines in range(2):
            self.draw_tri((0,0), (1024,512), 0, lines)
            self.draw_tri((1024,512), (1024,512), math.pi, lines)
            self.draw_tri((0,512), (1024,512), 0, lines)
            self.draw_tri((1024,1024), (1024,512), math.pi, lines)
        return self.surf

    def draw_tri(self, tl, dim, rot, lines=False, colour=None, r=1):
        x,y = tl
        dx, dy = dim
        points = rotateAboutFirst([tl, (x, y+r*dy), (x+dx, y+r*dy)], rot)
        if lines: pygame.draw.aalines(self.surf, self.line_colour, 1, points)
        else: pygame.draw.polygon(self.surf, colour or self.rcolour(), points)
        if dx < self.LOD: return
        tl = midpoint(points[1], points[2])
        self.draw_tri(tl, (dx/SQRT5, dy/SQRT5), rot+r*R1, lines,
            colour or self.rcolour(), r*-1)
        self.draw_tri(tl, (dx/SQRT5, dy/SQRT5), rot+r*(math.pi+R1), lines,
            colour or self.rcolour(), r)
        tl = midpoint(points[0], points[2], 1, 5)
        self.draw_tri(tl, (dx/SQRT5, dy/SQRT5), rot+r*R1, lines,
            colour or self.rcolour(), r)
        self.draw_tri(points[1], (dx/SQRT5, dy/SQRT5), rot+r*R1, lines,
            colour or self.rcolour(), r*-1)
        self.draw_tri(points[0], (dx/SQRT5, dy/SQRT5), rot+r*(R2+R1), lines,
            colour or self.rcolour(), r*-1)

sounds = { }

class Game:
    def main(self):
#        pygame.mixer.pre_init(44100,-16,2, 1024 * 3)
        pygame.init()
        pygame.mouse.set_visible(False)
#        pygame.mixer.init()

        self.screen = pygame.display.set_mode((1024, 768))

        font = None
        try:
            pygame.font.Font(font, 24)
        except IOError:
            font = 'VeraMono.ttf'

        self.font = pygame.font.Font(font, 24)
        self.big_font = pygame.font.Font(font, 64)
        self.world = World(self.screen)
        self.background = PinWheel().render(self.screen, 50)
        #self.background = draw_background(self.screen)

        self.score = 0
        self.run_intro()
        #self.run_game()

    def run_intro(self):
        sw, sh = self.screen.get_rect().size
        wgroup = WorldSpriteGroup()
        def reset_wgroup():
            wgroup.empty()
            draw = [(k, (x*SCALE, y*SCALE), r, c) for k,(x,y),r,c in BIG_BOX]
            for klass, pos, rot, colour in draw:
                rrot = math.pi - random.random()*math.pi*2
                spr = WorldSprite(self.random_startpos(), rrot, klass.POINTS,
                     colour)
                x, y = pos
                spr.set_destination((x+sw/2, y+sh/2), rot, 40)
                wgroup.add(spr)
        reset_wgroup()

        self.screen.blit(self.background, (0,0))

        clock = pygame.time.Clock()
        title = self.big_font.render("TANVADERS!!!!!!!!", 1, (0, 0, 0))
        message = None
        desc = self.font.render("Press any key to continue", 1, (0, 0, 0))
        while 1:
            dt = clock.tick(FPS)
            for e in pygame.event.get():
                if e.type == QUIT: return
                if e.type == KEYDOWN:
                    if e.key == K_ESCAPE: return
                    self.score = 0
                    try:
                        self.run_game()
                    except LevelOver:
                        message = self.big_font.render("You Won!", 1,
                            (0, 0, 0))
                    except PlayerDead:
                        message = self.big_font.render("You Died!", 1,
                            (0, 0, 0))
                        self.background = PinWheel().render(self.screen, 50)
                        self.screen.blit(self.background, (0,0))
                    reset_wgroup()

            wgroup.update(dt, self)
            wgroup.clear(self.screen, self.background)
            self.world.stack = []
            wgroup.draw(self.world)

            w=title.get_rect().width
            self.screen.blit(title, (sw/2 - w/2, sh-200))

            if message:
                w=message.get_rect().width
                self.screen.blit(message, (sw/2 - w/2, sh-130))

            w=desc.get_rect().width
            self.screen.blit(desc, (sw/2 - w/2, sh-50))

            pygame.display.flip()

    def run_game(self):
        self.screen.blit(self.background, (0,0))

        # wgroup holds our baddies
        self.wgroup = wgroup = WorldSpriteGroup()
        sw, sh = self.screen.get_rect().size
        def add_baddie(n, klass):
            rrot = math.pi - random.random()*math.pi*2
            spr = klass(self.random_startpos(), rrot, klass.COLOUR)
            spr.erot = klass.ROT # need for intended_rect()
            spr.random_destination(self.screen,
                y=self.figure_height(spr), rot=klass.ROT)
            #spr.erot = rot
            wgroup.add(spr)
            #set_heights(self.screen, wgroup)

        # add player sprites
        pgroup = pygame.sprite.RenderClear()
        x, y = self.screen.get_rect().size
        player = PlayerSprite((x/2, y))
        pgroup.add(player)

        # interface sprites
        igroup = pygame.sprite.RenderClear()
        fps = pygame.sprite.Sprite()
        igroup.add(fps)
        score = pygame.sprite.Sprite()
        igroup.add(score)
        health = pygame.sprite.Sprite()
        igroup.add(health)

        # enemy sprites (bullets)
        self.egroup = egroup = pygame.sprite.RenderClear()

        rot = 0
        shoot = False
        clock = pygame.time.Clock()
        k_left = k_right = False

        # incoming and currently "active" baddies
        incoming = list(INCOMING)
        incoming.reverse()
        active = []
        reinstate = []

        elapsed = 0

        while 1:
            dt = clock.tick(FPS)
            elapsed += dt
            seconds = elapsed/1000
            for e in pygame.event.get():
                if e.type == QUIT: sys.exit(0)
                if e.type == KEYDOWN:
                    if e.key == K_ESCAPE:
                        igroup.clear(self.screen, self.background)
                        egroup.clear(self.screen, self.background)
                        pgroup.clear(self.screen, self.background)
                        wgroup.clear(self.screen, self.background)
                        return
                    if e.key == K_LEFT: k_left = True
                    if e.key == K_RIGHT: k_right = True
                    if e.key == K_SPACE: shoot = True
                if e.type == KEYUP:
                    if e.key == K_LEFT: k_left = False
                    if e.key == K_RIGHT: k_right = False
                    if e.key == K_SPACE: shoot = False

            # player actions
            player.move = 0
            if k_left: player.move -= 10
            if k_right: player.move += 10
            if shoot and not player.fired:
                pgroup.add(PlayerBulletSprite(player.rect.midtop))
                player.fired = FPS /2
            if player.fired:
                player.fired -= 1

            # add a bad guy?
            if reinstate:
                if seconds >= reinstate[-1][0]:
                    add_baddie(*reinstate.pop())
                    seconds -= 1
            elif incoming:
                if seconds >= incoming[-1][0]:
                    add_baddie(*incoming.pop())

            # UPDATE
            wgroup.update(dt, self)
            pgroup.update(dt, self.screen, pgroup)
            egroup.update(dt, self.screen, egroup)

            # COMBO!!!!1
            combo = self.find_combo()
            if combo is not None:
                self.activate_combo(combo)

            # CLEAR
            igroup.clear(self.screen, self.background)
            pgroup.clear(self.screen, self.background)
            wgroup.clear(self.screen, self.background)
            egroup.clear(self.screen, self.background)

            # hit player with enemy bullets
            hits = pygame.sprite.spritecollide(player, egroup, True)
            if hits:
                player.health -= 1
                if not player.health:
                    raise PlayerDead

            # hit enemy with player bullets
            hits = pygame.sprite.groupcollide(wgroup, pgroup, False, True)
            for hit in hits:
                hit.health -= 1
                if not hit.health:
                    wgroup.remove(hit)
                    if isinstance(hit, ComboSprite):
                        for x, x, spr in hit.attached:
                            reinstate.insert(0, (seconds + 5, spr.__class__))
                            self.score += 1
                    else:
                        reinstate.insert(0, (seconds + 5, hit.__class__))
                    self.score += 1
#                    if not wgroup:
#                        raise LevelOver

            # render FPS, score
            fps.image = self.font.render("FPS: %d"%clock.get_fps(), 1,
                (255, 255, 255))
            fps.rect = fps.image.get_rect()
            score.image = self.font.render("Score: %d"%self.score, 1,
                (255, 255, 255))
            score.rect = score.image.get_rect()
            score.rect.bottomright = (sw, sh)
            health.image = self.font.render("Health: %d"%player.health, 1,
                (255, 255, 255))
            health.rect = health.image.get_rect()
            health.rect.bottomleft = (0, sh)

            # DRAW
            self.world.stack = []
            egroup.draw(self.screen)
            wgroup.draw(self.world)
            pgroup.draw(self.screen)
            igroup.draw(self.screen)

            pygame.display.flip()

    def random_startpos(self):
        sw, sh = self.screen.get_rect().size
        side = random.randint(1, 3)
        rrot = random.random() * (math.pi - (math.pi*2))
        if side == 1: return (-200, random.randint(SCALE, sh-200))
        elif side == 2: return (random.randint(-200, 200+sw), -100)
        return (sw+200, random.randint(SCALE, sh-200))

    def figure_height(self, new):
        sh = self.screen.get_rect().height
        #print '>>>>>>>>> FITTING', new.intended_rect()
        height = [(0,sh,False)]
        for spr in self.wgroup:
            r = spr.intended_rect()
            spry = int(spr.epos[1])
            sprh = int(r.height) + 10
            #print 'ADDING', (spry, sprh)
            for i in range(len(height)):
                if i == len(height)-1:
                    break
                if height[i][2]: continue   # occupied
                if height[i][0] <= spry <= height[i+1][0]:
                    break
            #print (height, i)
            epos, eheight, x = height[i]
            if epos == spry and eheight == sprh:
                height[i] = (epos, eheight, True)
            else:
                n = []
                if epos != spry:
                    n.append((epos, spry-epos, False))
                n.append((epos+spry, sprh, True))
                if (spry-epos)+sprh < eheight:
                    n.append((spry+sprh, eheight-sprh, False))
                height[i:i+1] = n
            #print '->', height
        #print 'w', height
        newr = new.intended_rect()
        for epos, eheight, occupied in height:
            if occupied: continue
            #print '>>>>>>>>> DONE', (epos, eheight, newr.height, newr.height < eheight)
            if newr.height < eheight:
                break
        return epos

    def find_combo(self):
        active = sets.Set()
        for spr in self.wgroup:
            if not spr.on_screen: continue
            active.add(spr.__class__)
        for combo in COMBOS:
            if sets.Set([c[0] for c in combo]) <= active:
                return combo
        return None

    def activate_combo(self, combo):
        sprites = []
        for n, (klass, offset, rot, colour) in enumerate(combo):
            for spr in self.wgroup:
                if spr.__class__ == klass:
                    if n == 0:
                        px, py = spr.pos
                        ox, oy = offset
                        px += SCALE*ox
                        py += SCALE*oy
                        pos = (px, py)
                    sprites.append((offset, rot, spr))
                    self.wgroup.remove(spr)
                    break

        parent = ComboSprite(sprites, pos, 0, combo[0][3])
        parent.pos = pos
        parent.random_destination(self.screen,
            y=self.figure_height(parent), rot=rot)
        parent.state = ST_SUCKING
        self.wgroup.add(parent)


if __name__ == '__main__':
    game = Game()
    game.main()

