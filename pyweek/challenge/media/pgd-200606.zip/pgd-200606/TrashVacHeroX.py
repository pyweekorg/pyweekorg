#! /usr/bin/env python
"""
-----
pyweek.64k Challenge Entry - Sunday, 25 June 2006 09:55 (UTC-4)
------
TrashVac Hero X
------
Blake Livingston (blake.a.livingston@gmail.com)
Donal Heidenblad (dheidenblad@sourceforge.net)    
-----
To control your ship, you have been provided a pretty
standard keyboard map.
Up      = [w]
Down    = [s]
Left    = [a]
Right   = [d]
Shoot   = [,]
Throw   = [.]
Bomb    = [/]

Fullscreen = [ESC] (and to go back to windowed mode)

The direction keys and shoot shouldn't need explination.
Throw takes that field of debris that is swirling about
your ship and pushes it away in a very predictable manner.
Bomb causes a wave of destruction to sweep through your
current screen, eliminating everything in its way.

License:
--------
The source code is provided under the GNU GPL license version 2.
--------
"""
from pygame import *
import pygame
from math import *
import time
import math
import random

#to configure key binding set to either wasd or  arrows"""
binding="wasd"

#game globals
trashAttractRad=220
trashLimit=100
playerTrashLimit=100
playerActor=None
trashGroup=None
playerTrashGroup=None
playerGroup=None
enemyGroup=None
bulletGroup=None
overlayGroup=None
underlayGroup=None
enemyBulletGroup=None
backgroundGroup=None
screen=None
gameMode=None
playerControlGrabDistance=100
tick=0
g=.5
gravExp=0
score=0
sprites={}
keyBinding=None
minGravDist=16
dampVel=7
damp=.98
scrollVel=0.5
terrainInstance=None
lives=4
respawn=0
fullscreen=False
secpi=math.pi/60
curLevel=None

class controls:
    Up=False
    Down=False
    Left=False
    Right=False
    Shoot=False
    JustShot=False
    Throw1=False
    JustThrow1=False
    Throw2=False
    JustThrow2=False

"""
class Vector:
    def __init__(self,val=(0,0)):
        self.value=list(val)
    
    def __add__(self,other):
        return Vector((self.value[0]+other[0],self.value[1]+other[1]))
    
    def __sub__(self,other):
        return Vector((self.value[0]-other[0],self.value[1]-other[1]))
        
    def normalize(self):
        mag=math.hypot(self.value[0],self.value[1])
        return Vector((self.value[0]/mag,self.value[1]/mag))
    def magnitude(self):
        return math.hypot(self.value[0],self.value[1])
    def __getitem__(self,idx):
        return self.value[idx]
    def __mul__(self,other):
        return Vector((self.value[0]*other,self.value[1]*other))
    def __setitem__(self,idx,val):
        self.value[idx]=val
        
    def toTuple(self):
        return self.value
"""
def randz():
    return 2*(random.random()-.5)
def rand():
    return random.random()

def addv(a,b):
    x,y=a
    xx,yy=b
    return(x+xx,y+yy)

def subv(a,b):
    """a-b"""
    x,y=a
    xx,yy=b
    return(x-xx,y-yy)
def mulv(a,b):
    x,y=a
    return (x*b,y*b)

def magv(a):
    x,y=a
    return hypot(x,y)

def normv(a):
    x,y=a
    m=hypot(x,y)
    return (x/m,y/m)

def distv(a,b):
    return magv(subv(a,b))

def dirv(a,b):
    """unit direction vector from a-b"""
    xa,ya=a
    xb,yb=b
    xd=xb-xa
    yd=yb-ya
    mag=1/hypot(xd,yd)
    return(xd*mag,yd*mag)
    
def initStuff():
    global playerGroup
    global enemyGroup
    global bulletGroup
    global overlayGroup
    global backgroundGroup
    global trashGroup
    global playerTrashGroup
    
    global underlayGroup
    global enemyBulletGroup
    global lives
    global tick
    tick=0
    lives=3
    underlayGroup=Group()
    playerGroup=Group()
    enemyGroup=Group()
    enemyBulletGroup=Group()
    trashGroup=Group()
    bulletGroup=Group()
    overlayGroup=Group()
    backgroundGroup=Group()
    playerTrashGroup=Group()
def initEngine():
    global keyBindings
    global screen
    pygame.init()
    screen=pygame.display.set_mode((640,480))
    keyBindings = {}
    keyBindings = keyBinding("wasd")
    global sprites
    sprites["player"]=playerSprite()
    sprites["boom"]=boomSprite()
    sprites["junk"]=junkSprite()
    sprites["borb"]=orbSprite((255,200,180),64)
    sprites["rorb"]=orbSprite((255,78,100),64)
    sprites["gorb"]=orbSprite((78,220,89),32)
    sprites["florb"]=blocspr((255,255,255),8)
    sprites['cannon']=cannonspr()
    
def keyBinding(binding):
    k={}
    k["wasd"]={}
    k["wasd"]["up"]=K_w
    k["wasd"]["down"]=K_s
    k["wasd"]["left"]=K_a
    k["wasd"]["right"]=K_d
    k["wasd"]["shoot"]=K_COMMA
    k["wasd"]["throw1"]=K_PERIOD
    k["wasd"]["throw2"]=K_SLASH
    k["arrows"]={}
    k["arrows"]["up"]=K_UP
    k["arrows"]["down"]=K_DOWN
    k["arrows"]["left"]=K_LEFT
    k["arrows"]["right"]=K_RIGHT
    k["arrows"]["shoot"]=K_a
    k["arrows"]["throw1"]=K_s
    k["arrows"]["throw2"]=K_d
    return k[binding]    
    
def processEvent(ev):
    if ev.type == KEYDOWN:
        if ev.key == keyBindings["up"]:
            controls.Up=True
            
        elif ev.key == keyBindings["down"]:
            controls.Down=True
        elif ev.key == keyBindings["left"]:
            controls.Left=True
        elif ev.key == keyBindings["right"]:
            controls.Right=True
        elif ev.key == keyBindings["shoot"]:
            controls.Shoot=True
            controls.JustShot=True
        elif ev.key == keyBindings["throw1"]:
            controls.Throw1=True
            controls.JustThrow1=True
        elif ev.key == keyBindings["throw2"]:
            controls.Throw2=True
            controls.JustThrow2=True
    elif ev.type == KEYUP:
        if ev.key == keyBindings["up"]:
            controls.Up=False
        elif ev.key == keyBindings["down"]:
            controls.Down=False
        elif ev.key == keyBindings["left"]:
            controls.Left=False
        elif ev.key == keyBindings["right"]:
            controls.Right=False
        elif ev.key == keyBindings["shoot"]:
            controls.Shoot=False
        elif ev.key == keyBindings["throw1"]:
            controls.Throw1=False
        elif ev.key ==  keyBindings["throw2"]:
            controls.Throw2=False
            
class Group:
    def __init__(self):
        self.actors=[]
        
    def add(self,actr):
        self.actors.append(actr)
        actr.groups.append(self)
    
    def remove(self,actr):
        self.actors.remove(actr)
        actr.groups.remove(self)
    
    def clear(self):
        self.actors.clear()
        
    def collide(self,other):
        """checks for collisions between this group and the other. 
        onCollide is called on objects that collide between the two groups"""
        if len(self.actors)<len(other.actors):
            a=self.actors
            b=other.actors
        else:
            b=self.actors
            a=other.actors
        for act in a:
            collvec=act.screenbounds.collidelistall([arg.screenbounds for arg in b])
            hitters=[b[idx] for idx in collvec]
            [(act.onCollide(h),h.onCollide(act)) for h in hitters]
            
class Actor:
    def __init__(self):
        self.bounds=pygame.Rect(0,0,10,10)
        self.groups=[] #do not touch.
        self.position=(320,240)
        self.screenbounds=None
        self.image=None
        self.isBullet=False
        self.isEnemy=False
        self.isAlive=True
        self.isTrash=False
        self.isBomb=False
        self.tick=0
        self.damage=30
    def think(self):
        self.screenbounds=self.bounds.move(self.position)
        
    def draw(self,surface):
        try:
            img,offset=self.image
            surface.blit(img,subv(self.screenbounds.center,offset))
        except:
            self.drawBounds(surface)
            
    def drawBounds(self,surface):
        pygame.draw.rect(surface,(200,0,0),self.bounds.move(self.position),1)
            
    def kill(self):
        for g in self.groups:
            g.remove(self)
        self.isAlive=False
        
    def onCollide(self,other):
        pass

    def isOffScreen(self):
        x,y=self.position
        if x>640 or x<0: return True
        elif y>480 or y<0: return True
        else: return False
        
def max(a,b):
    if a>b:
        return a
    else: return b
    
class smallExplode(Actor):
    def __init__(self,pos,rad):
        Actor.__init__(self)
        self.ticks=0
        self.position=pos
        self.rad=rad
        
    def think(self):
        self.ticks+=1
        if self.ticks ==20:
            self.kill()
    def draw(self,surf):
        if tick%3 ==0:return
        rad=max(0,self.rad-self.ticks)
        if rad>0:
            pygame.draw.circle(surf,(255,255,255),self.position,int(rad))
        
class medExplode(Actor):
    def __init__(self,pos):
        Actor.__init__(self)
        self.ticks=0
        self.position=pos
        self.image=sprites["boom"]
        self.life=10
    def think(self):
        self.ticks+=1
        if self.ticks ==self.life:
            self.kill()
    def draw(self,surf):
        if tick%2 ==0:
            i=pygame.transform.scale(self.image[0],(70-self.ticks*7,70-self.ticks*7))
            surf.blit(i,subv(self.position,(35-self.ticks*3.5,35-self.ticks*3.5)))
class BigExpl(medExplode):
    def __init__(self,pos):
        medExplode.__init__(self,pos)
        self.life=23
    def draw(self,surf):
        if tick%2 ==0:
            i=pygame.transform.scale(self.image[0],(160-self.ticks*6,160-self.ticks*6))
            surf.blit(i,subv(self.position,(60-self.ticks*3.5,60-self.ticks*3.5)))
class ShipActor(Actor):
    def __init__(self):
        Actor.__init__(self)
        self.bounds=pygame.Rect((-16,-8,32,16))
        self.width=16
        self.height=8
        self.vel=5
        self.lives=lives
        self.nextBomb=1200
        self.image=sprites["player"]
        self.maxBombs=2
        self.reset()
        
    def reset(self):
        """reset things(after 'death')"""
        self.bombs=2
        self.nextShot=0
        self.gun=self.basicGun
        self.missile=self.noMissile
        self.isAlive=True
        self.bounds=pygame.Rect((-16,-8,32,16))
        self.position=(95,260)
        self.invincible=True
        self.invincibleTimeout=self.tick+120
        
    def think(self):
        if not self.isAlive:
            if self.tick >=self.respawnTime and self.lives>0:
                self.reset()
            return
        if self.invincibleTimeout == self.tick:
            self.invincible=False
            
        self.move()
        self.gun()
        self.missile()
        Actor.think(self)
        if self.tick==self.nextBomb and self.bombs<self.maxBombs:
            self.bombs+=1
            self.nextBomb=self.tick+1200
        if controls.JustThrow1:
            self.agitate()
        if controls.JustThrow2 and self.bombs>0:
            self.bombs-=1
            self.nextBomb=self.tick+1200
            playerTrashGroup.add(TheBomb())
        
    def agitate(self):
        for t in playerTrashGroup.actors:
            t.vel=addv(t.vel,mulv(dirv(self.position,t.position),5))
    def noMissile(self):
        pass
    def basicGun(self):
        if controls.JustShot:
            if self.tick>self.nextShot:
                self.nextShot=self.tick+5
                bulletGroup.add(PlayerBullet(self.position))
                
    def draw(self,surface):
        if not self.isAlive:return
        #self.drawBounds(surface)
        if self.invincible:
            if tick%2:return
        try:
            img,offset=self.image
            surface.blit(img,subv(self.position,offset))
        except:
            pass
    def onCollide(self,other):
        if not self.invincible and self.isAlive:
            if other.isEnemy or other.isBullet:
                self.lives-=1
                self.isAlive=False
                overlayGroup.add(BigExpl(self.position))
                self.position=(0,0)
                self.respawnTime=self.tick+45
                if self.lives ==0:
                    gameMode.scheduleNextLevel(GameOver)
            
    def move(self): 
        if controls.Left:
            self.position=addv(self.position,(-self.vel,0))
        if controls.Right:
            self.position=addv(self.position,(+self.vel,0))
        if controls.Up:
            self.position=addv(self.position,(0,-self.vel))
        if controls.Down:
            self.position=addv(self.position,(0,self.vel))
        x,y=self.position
        if x<self.width: x=self.width
        if x>(640-self.width): x=(640-self.width)
        if y<self.height: y=self.height
        if y>(480-self.height): y=(480-self.height)
        self.position=(x,y)

class TrashActor(Actor):
    def __init__(self,pos,size,mass,**kw):
        Actor.__init__(self)
        self.size=size
        self.mass=mass
        self.position=pos
        self.bounds=pygame.Rect((-size[0]/2,-size[1]/2,size[0],size[1]))
        self.vel=(0,0)
        self.trashboundx=100
        self.trashboundy=100
        self.isTrash=True
        self.playerControlled=False
        self.__dict__.update(kw)
        s=sprites['junk']
        self.image=s
    def think(self):
        if playerActor.isAlive:
            dir=subv(playerActor.position,self.position)
            dist=magv(dir)
            if dist <minGravDist: dist = minGravDist
            if self.playerControlled:
                if dist < trashAttractRad:
                    attraction = g/(math.pow(dist,gravExp)) 
                    self.vel=addv(self.vel,mulv(normv(dir), attraction))
                if magv(self.vel)>dampVel:
                    self.vel=mulv(self.vel,damp)
            else:
                attraction = 90/(pow(dist,1.5)) 
                self.vel=addv(self.vel,mulv(normv(dir), attraction))
                if dist<playerControlGrabDistance and len(playerTrashGroup.actors)<playerTrashLimit:
                    self.playerControlled=True
                    playerTrashGroup.add(self)
                    trashGroup.remove(self)
                
        self.position=addv(self.position,self.vel)
        x,y=self.position
        
        if x>640+self.trashboundx or x<-self.trashboundx: return self.kill()
        elif y>480+self.trashboundy or y<-self.trashboundy: return self.kill()
        Actor.think(self)
    
    def onCollide(self,other):
        if other.isEnemy:
            overlayGroup.add(smallExplode(self.position,10))
            self.kill()
        pass
        
    def __del__(self):
        #print 'trashdie!'
        pass

        
class BulletActor(Actor):
    def __init__(self,bounds,pos,vel,**args):
        Actor.__init__(self)
        self.position=pos
        self.vel=vel
        self.damage=20
        self.health=1
        self.bounds=pygame.Rect(bounds)
        self.screenbounds=self.bounds.move(pos)
        self.isBullet=True
        self.img="borb"    
        self.__dict__.update(args)
        i=sprites[self.img][0]
        i=pygame.transform.scale(i,(self.bounds.width,self.bounds.height))
        self.image=(i,i.get_rect().center)
    def think(self):
        Actor.think(self)
        self.position=addv(self.position,self.vel)
        if self.isOffScreen(): self.kill()
    def onCollide(self,other):
        self.health-=other.damage
        if self.health<0:
            overlayGroup.add(smallExplode(self.position,10))
            self.kill()
    
class PlayerBullet(BulletActor):
    def __init__(self,pos):
        BulletActor.__init__(self,(0,0,8,4),pos,(9,0))

class FlackActor(Actor):
    def __init__(self, fuse):
        self.fuse = fuse
        self.eol = self.tick + self.fuse
        speed=1.5
        self.flackVects=[(0,speed),(-speed,speed),(-speed,0),(-speed,-speed),(0,-speed),(speed,-speed),(speed,0),(speed,speed)]
    def detonate(self):
        for v in self.flackVects:
            enemyBulletGroup.add(BulletActor((0,0,5,5),self.position, v,img='florb'))

class FlackBullet(BulletActor, FlackActor):
    def __init__(self,pos,vel,fuse):
        BulletActor.__init__(self, (0,0,6,8), pos, vel,img='florb')
        FlackActor.__init__(self, fuse)
    def think(self):
        BulletActor.think(self)
        if self.tick != self.eol:
            self.vel=(-scrollVel,self.vel[1])
            self.position=addv(self.position,self.vel)
        else:
            overlayGroup.add(smallExplode(self.position,20))
            self.detonate()
            self.kill()

class MissileActor(Actor):
    def __init__(self):
        self.initVel=self.vel
    def draw(self,surf):
        pygame.draw.line(surf,(255,255,0),self.screenbounds.center,addv(self.screenbounds.center,mulv(
        dirv(self.screenbounds.center,playerActor.position),8)))
    def think(self):
        if playerActor.isAlive:
            dir=dirv(self.position,addv(playerActor.position,(randz()*20,randz()*20)))
            self.vel=addv(self.vel, mulv(dir,.15))

class SeekerMissile(BulletActor, MissileActor):
    def __init__(self, pos):
        BulletActor.__init__(self, (0,0,8,6), pos, (0,0))
        MissileActor.__init__(self)
    def think(self):
        MissileActor.think(self)
        BulletActor.think(self)
            
class FlackMissile(BulletActor, MissileActor, FlackActor):
    def __init__(self,pos,fuse):
        BulletActor.__init__(self, (0,0,8,6), pos, (-3,0))
        FlackActor.__init__(self, fuse)
        MissileActor.__init__(self)
    def think(self):  
        if self.tick != self.eol:
            MissileActor.think(self)
            BulletActor.think(self)
        else:
            overlayGroup.add(smallExplode(self.position,20))
            self.detonate()
            self.kill()
            
class EnemyActor(Actor):
    def __init__(self, posY=240, size=(30,30), pointValue=1, debrisValue=4,**args):
        Actor.__init__(self)
        self.size=size
        self.bounds=pygame.Rect((-size[0]/2,-size[1]/2,size[0],size[1]))
        self.vel=1
        self.pointValue=pointValue
        self.debrisValue=debrisValue
        self.position=(screen.get_width()+15, posY)
        self.health=1
        self.shootMax=4
        self.pauseTime=200
        self.nextVolley=self.tick+self.pauseTime
        self.nextShot=self.nextVolley
        self.vShotsLeft=self.shootMax
        self.isEnemy=True
        self.image=sprites['gorb']
        self.__dict__.update(args)
    def setDropItem(self):
        #for powerups
        pass
    def think(self):
        Actor.think(self)
        self.position=addv(self.position,(-self.vel, 0))
        if self.position[0]<-10:self.kill()
    def volley(self):
        if self.tick == self.nextVolley:
            self.vShotsLeft=self.shootMax
            self.nextShot = self.tick
        if self.tick == self.nextShot:
            if self.vShotsLeft > 0:
                self.shoot()
                self.vShotsLeft -= 1
                self.nextShot = self.tick+50
            else:
                self.nextVolley = self.tick+self.pauseTime
    def spawnTrash(self):
        for x in xrange(self.debrisValue):
            trashGroup.add(TrashActor(self.position,(10,10),5+rand()*10,
            vel=(3*randz(),3*randz())))
    def onCollide(self, other):
        if other.isBullet:
            self.health-=other.damage
        if other.isTrash:
            self.health-=other.mass * magv(other.vel) * .34
        if self.health<0:        
            global score
            score+=self.pointValue
            overlayGroup.add(medExplode(self.position))
            self.spawnTrash()
            self.kill()
    def weakAim(self):
        if self.tick>self.nextShot:
            dir=dirv(self.position,addv(playerActor.position,(randz()*20,randz()*20)))
            enemyBulletGroup.add(BulletActor((0,0,10,10),self.position,mulv(dir,1.4)))
            self.nextShot=self.tick+self.shotfreq+randz()*40        

class Drone(EnemyActor):
    def __init__(self,ystart,**args):
        EnemyActor.__init__(self)
        self.position=(650,ystart)
        self.y=ystart
        self.pointValue=50
        self.move=Drone.sinmove
        self.shots=Drone.weakAim
        self.health=30
        self.shotfreq=180+40*randz()
        self.vel=(-2,0)
        self.amplitude=7
        self.rate=3
        self.jukevel=(2,-1.2)
        self.__dict__.update(args)
    def noShot(self):
        pass
    def sinmove(self):
        self.position=addv(self.position,self.vel)
        self.position=(self.position[0],self.y+self.amplitude*sin(self.tick/(secpi*self.rate)))
    def juke(self):
        if self.tick>200 and self.tick<300:
            self.position=addv(self.position,self.jukevel)
        else:
            self.position=addv(self.position,self.vel)
    
            
    def think(self):
        Actor.think(self)
        self.move(self)
        self.shots(self)
        
class Berserker(EnemyActor):
    def __init__(self,**args):
        EnemyActor.__init__(self)
        self.health=2000
        self.damage=40
        self.bounds=pygame.Rect(0,0,64,64)
        self.pointValue=1000
        self.debrisValue=100
        self.image=orbSprite((244,244,120),78)
        self.speed=1
        self.__dict__.update(args)
        
    def think(self):
        Actor.think(self)
        if playerActor.isAlive:
            if self.tick>70:
                self.isEnemy=True
                self.position=addv(self.position,mulv(dirv(self.position,playerActor.position),self.speed))
            else:
                self.isEnemy=False
    def draw(self,surf):
        if self.tick<70:
            if self.tick%2:
                Actor.draw(self,surf)
        else:
            Actor.draw(self,surf)

class Guardian(EnemyActor):
    def __init__(self,**args):
        EnemyActor.__init__(self)
        self.health=2000
        self.damage=40
        self.bounds=pygame.Rect(0,0,64,64)
        self.pointValue=1000
        self.debrisValue=20
        self.isBoss=True
        self.image=orbSprite((255,78,100),80)
        self.__dict__.update(args)
    def think(self):
        Actor.think(self)
        if self.tick==51:
            self.vel=(0,5)
        if self.tick>50:
            if self.tick%40 ==0:
                self.shoot()
            if self.position[1]<30:
                self.vel=(0,5)
            if self.position[1]>430:
                self.vel=(0,-5)
            if self.tick%300==0 or self.tick%310==0 or self.tick%320==0:
                enemyGroup.add(Drone(rand()*480,vel=(-2,0),health=1,debrisValue=20,amplitude=20))
            if self.tick%1000==0:
                enemyGroup.add(Berserker(position=(640*rand(),480*rand()),health=800,debrisValue=60))
                enemyGroup.add(Berserker(position=(640*rand(),480*rand()),health=800,debrisValue=60))
        else:
            self.vel=(-2,0)
        self.position=addv(self.position,self.vel)

    def onCollide(self,other):
        if not other.isBomb:
            EnemyActor.onCollide(self,other)
    def kill(self):
        if self.isBoss:
           
            gameMode.scheduleNextLevel(GameLevel2)
            global enemyGroup
            global enemyBulletGroup
            enemyGroup=Group()
            enemyBulletGroup=Group()
        EnemyActor.kill(self)
    def shoot(self):
        enemyBulletGroup.add(BulletActor((0,0,30,60),self.screenbounds.center,(-9,0)))
    def draw(self,surf):
        if self.tick<70:
            if self.tick%2:
                Actor.draw(self,surf)
        else:
            Actor.draw(self,surf)
            
class VoidStar(EnemyActor):
    def __init__(self,**args):
        EnemyActor.__init__(self)
        self.health=3000
        self.damage=40
        self.bounds=pygame.Rect(0,0,140,140)
        self.pointValue=10000
        self.debrisValue=20
        self.image=orbSprite((60,60,60),160)
        self.isInvuln=True
        self.position=(-80,170)
        self.gspawned=False
        self.__dict__.update(args)
        
    def think(self):
        Actor.think(self)
        if self.tick<490:
            self.position=addv(self.position,(1,0))
        if self.tick==490:
            self.isInvuln=False
            self.shoot()
        if self.tick>550 and self.tick<650 and self.tick%20==0:
            enemyGroup.add(Berserker(position=self.position,health=300,speed=3))
        if self.tick>550 and self.tick%90==0:
            self.shoot()
        if self.tick==760:
            self.vel=(3,0)
        if self.tick>760:
            self.position=addv(self.position,self.vel)
            if self.screenbounds.left <0 or self.screenbounds.right>640:
                self.vel=mulv(self.vel,-1)
                self.position=addv(self.position,self.vel)
                self.position=addv(self.position,self.vel)
                self.position=addv(self.position,self.vel)
        if self.tick>880 and self.tick%300==0:
            enemyBulletGroup.add(FlackMissileShip(rand()*400,(25,25),1000,50))
        if self.health<1200:
            if not self.gspawned:
                enemyGroup.add(Guardian(health=800,isBoss=False))
                self.gspawned=True
                
    def onCollide(self,other):
        if self.isInvuln==True:
            return
        if not other.isBomb:
            EnemyActor.onCollide(self,other)
            
    def kill(self):
        gameMode.scheduleNextLevel(GameWIN)
        global enemyGroup
        global enemyBulletGroup
        enemyGroup=Group()
        enemyBulletGroup=Group()
        EnemyActor.kill(self)
    def shoot(self):
        enemyBulletGroup.add(BulletActor((0,0,30,60),self.screenbounds.center,(-9,0),health=500))
        enemyBulletGroup.add(BulletActor((0,0,30,60),self.screenbounds.center,(-9,-3),health=500))
        enemyBulletGroup.add(BulletActor((0,0,30,60),self.screenbounds.center,(-9,3),health=500))
    def draw(self,surf):
        if self.isInvuln:
            if self.tick%2:
                Actor.draw(self,surf)
        else:
            Actor.draw(self,surf)
class FlackMissileShip(EnemyActor, FlackActor):
    def __init__(self, posY, size=(25,25), pointValue=1, debrisValue=10):
        EnemyActor.__init__(self, posY, size=(15,15), pointValue=1, debrisValue=10)
    def think(self):
        EnemyActor.think(self)
        EnemyActor.volley(self)
    def shoot(self):
        enemyBulletGroup.add(FlackMissile(self.position,60+int(randz()*35)))

#Base for all fixed point cannon-type shooters
class FixedGun(EnemyActor):
    def __init__(self, onBottom):
        Actor.__init__(self)
        self.image=sprites['cannon']
        self.size=(25,15)
        self.bounds=pygame.Rect((-self.size[0]/2,-self.size[1]/2,self.size[0],self.size[1]))
        self.pointValue=1
        self.debrisValue=2
        self.position=(screen.get_width()+5,8)
        self.onBottom=onBottom
        if self.onBottom:
            self.bulletVel = (0,-3)
        else:
            self.bulletVel = (0,3)
        self.health=1
        self.shootMax=5
        self.pauseTime=100
        self.nextVolley=self.tick+self.pauseTime
        self.nextShot=self.nextVolley
        self.vShotsLeft=self.shootMax
        self.vel=scrollVel
        self.isEnemy=True
        
    def think(self):
        if self.tick == 0 and self.onBottom == True:
            self.position=(self.position[0],terrainInstance.getHeight(self.position[0]+self.size[0]/2))
        EnemyActor.think(self)
        if self.tick == self.nextVolley:
            self.vShotsLeft=self.shootMax
            self.nextShot = self.tick
        if self.tick == self.nextShot:
            if self.vShotsLeft > 0:
                self.shoot()
                self.vShotsLeft -= 1
                self.nextShot = self.tick+10
            else:
                self.nextVolley = self.tick+self.pauseTime

class FlackCannon(FixedGun):
    def __init__(self, onBottom):
        FixedGun.__init__(self, onBottom)
    def shoot(self):
        enemyBulletGroup.add(FlackBullet(self.position,self.bulletVel,60+int(randz()*35)))

class BulletCannon(FixedGun):
    def __init__(self,onBottom):
        FixedGun.__init__(self,onBottom)
    def shoot(self):
        enemyBulletGroup.add(BulletActor((0,0,10,10),self.position, mulv(dirv(self.position,playerActor.position),5)))

class MissileLauncher(FixedGun):
    def __init__(self,onBottom):
        FixedGun.__init__(self,onBottom)
    def shoot(self):
        enemyBulletGroup.add(SeekerMissile(self.position))

class Obstacle(EnemyActor):
    def __init__(self,bounds):
        Actor.__init__(self)
        self.isEnemy=True
        self.bounds=pygame.Rect(*bounds)
        self.width=bounds[3]
    def think(self):
        self.screenbounds=self.bounds.move((-scrollVel*self.tick,0))
        if self.screenbounds.right<-self.width:
            Actor.kill(self)

    def onCollide(self,other):
        pass
class Stars(Actor):
    def __init__(self):
        Actor.__init__(self)
        self.stars=[(rand()*640,rand()*480) for x in range(100)]
        r=rand()
        self.starvel=[(-(rand()*rand()*20),0) for x in range(100)]
    def think(self):
        Actor.think(self)
        sv=self.starvel
        ss=self.stars
        for x in xrange(100):
            s=ss[x]
            ss[x]=addv(s,sv[x])
            if s[0]<0:ss[x]=(640,rand()*480)
    def draw(self,surf):
        for s in self.stars:
            surf.set_at(s,(255,255,255))
class Terrain(Actor):
    level=430
    def __init__(self,**args):
        Actor.__init__(self)
        self.crag=30
        self.detail=30      
        self.color=(255,255,0)
        self.overdraw=4
        
        self.__dict__.update(args)
        self.npts=int(640/self.detail)+self.overdraw
        self.genTerrain()
        self.updated=0
        self.scroll=0
        global terrainInstance
        terrainInstance=self
        
    def genTerrain(self):
        #print self.npts
        self.terrain=[]
        for x in range(self.npts):
            lev=self.level+self.crag*randz()
            self.terrain+=[lev]
            enemyGroup.add(Obstacle(((x-1.5)*self.detail,lev,self.detail,480)))
            
    def getHeight(self,x):
        return self.terrain[int((x-self.scroll)/self.detail)+1]

    def think(self):
        self.updated=0
        if self.tick!=0:
            if self.tick%(int(self.detail/scrollVel)) == 0:
                lev=self.level+self.crag*randz()
                self.terrain=self.terrain[1:]+[lev]
                enemyGroup.add(Obstacle(((self.npts-2.5)*self.detail,lev,self.detail,480)))
                self.updated=self.detail
                self.scroll+=self.detail
        self.scroll-=scrollVel
    def draw(self,surf):
        wid=640/self.npts
        det=self.detail
        pts=[((x-1)*det+self.scroll,self.terrain[x]) for x in xrange(len(self.terrain))]
        pygame.draw.lines(surf,self.color,False,pts,1)

class GameModeBase:
    def __init__(self):
        pass
    def go(self):
        pass

class GameLevel(GameModeBase):
    def __init__(self):
        GameModeBase.__init__(self)
        global playerActor
        if not playerActor:
            playerActor = ShipActor()
            playerGroup.add(playerActor)
        self.bgcolor=(0,0,0)
        self.updategroups=[underlayGroup,trashGroup,playerTrashGroup,bulletGroup,enemyGroup,enemyBulletGroup,playerGroup,overlayGroup]
        self.leveltick=0
        #the timeline is a map of tick:(tuple of functions or [group,actor,..]lists)
        self.timeline={}
        self.levelOver=False
        self.nextLevelTime=-1
    def limitTrash(self):
        if len(trashGroup.actors) >trashLimit:
            trashGroup.actors=trashGroup.actors[0:trashLimit]
        #if len(playerTrashGroup.actors) >playerTrashLimit:
         #   playerTrashGroup.actors=playerTrashGroup.actors[0:playerTrashLimit]
        
    def timeAdd(self,time,stuff):
        if not self.timeline.get(time):
            self.timeline[time]=stuff
        else:
            self.timeline[time]+=stuff
            
    def go(self):
        screen.fill(self.bgcolor)
        #print self.timeline
        todoThisTick=self.timeline.get(self.leveltick)
        #print todoThisTick,self.leveltick
        if todoThisTick:
            for fn in todoThisTick:
                fn()
        for g in self.updategroups:
            for act in g.actors:
                act.think()
                act.tick+=1
                act.draw(screen)
                #act.drawBounds(screen)
        #do collision detection
        bulletGroup.collide(enemyGroup)
        playerGroup.collide(enemyGroup)
        playerTrashGroup.collide(enemyGroup)
        enemyBulletGroup.collide(playerGroup)
        enemyBulletGroup.collide(playerTrashGroup)
        self.leveltick+=1
        self.limitTrash()
        #times=textsprite(str(self.leveltick),45,(200,200,0))
        scoreBoard=textsprite(str(score),45,(200,200,0))
        screen.blit(scoreBoard,(0,0))
        lives=lifeSprite()
        livesSprite, liveOffset = lives
        for c in range(playerActor.lives):
            screen.blit(livesSprite, (75+50*c,15))
        pygame.display.flip()
        if self.leveltick==self.nextLevelTime:
            global gameMode
            for g in self.updategroups:
                if g != playerGroup and g!=playerTrashGroup:
                    g.actors=[]
            gameMode=self.nextLevel()
        
    def spawnLine(self,starttime,tinterval,thing):
        for x in range(len(thing)):
            #print starttime+tinterval*x
            self.timeAdd(starttime+tinterval*x,[thing[x]])
    
    def scheduleNextLevel(self,level,delay=180):
        self.nextLevel=level
        self.levelOver=True
        self.nextLevelTime=self.leveltick+delay
        
        enemyGroup=Group()
        enemyBulletGroup=Group()
        
            
class GameOver(GameLevel):
    def __init__(self,message="GAME OVER!"):
        GameLevel.__init__(self)
        initStuff()
        global playerTrashGroup
        playerTrashGroup=Group()
        global playerActor
        playerActor=None
        self.gameo=textsprite(message,90,(255,255,100))
        global score
        score = 0
        self.scheduleNextLevel(GameLevel1,100)
        self.gr=self.gameo.get_rect()
    def go(self):
        screen.fill(self.bgcolor)
        self.leveltick+=1
        if self.leveltick==self.nextLevelTime:
            global gameMode
            gameMode=self.nextLevel()
        screen.blit(self.gameo,(320-self.gr.width*.5,240-self.gr.height*.5))
        pygame.display.flip()
        
class GameWIN(GameOver):
    def __init__(self):
        GameOver.__init__(self,"YOU WIN!")

class GameLevel1(GameLevel):
    def __init__(self):
        GameLevel.__init__(self)
        #self.leveltick=3099
        self.timeAdd(0,[spawn(underlayGroup,Stars())])
        self.spawnLine(10,20,[spawn(enemyGroup,Drone(100,vel=(-2,0),amplitude=20)) for x in range(5)])
        self.spawnLine(210,20,[spawn(enemyGroup,Drone(280,vel=(-2,0),amplitude=20)) for x in range(5)])
        self.spawnLine(300,20,[spawn(enemyGroup,Drone(100,vel=(-2,0),amplitude=20)) for x in range(5)])
        self.spawnLine(400,20,[spawn(enemyGroup,Drone(280,vel=(-2,0),amplitude=20)) for x in range(5)])
        self.spawnLine(800,13,[spawn(enemyGroup,Drone(180,vel=(-2,0),health=100,move=Drone.juke)) for x in range(8)])
        self.spawnLine(800,13,[spawn(enemyGroup,Drone(230,shots=Drone.noShot,vel=(-2,0),health=100,jukevel=(2,2),move=Drone.juke)) for x in range(8)])
        self.timeAdd(1000,[spawn(enemyGroup,Drone(x*640/8)) for x in range(8)])
        for z in range(5):
            self.timeAdd(1300+z*60,[spawn(enemyGroup,Drone(x*640/8,amplitude=40,rate=3)) for x in range(8)])
        self.timeAdd(550,[spawn(enemyGroup,FlackMissileShip(160),FlackMissileShip(350))])
        self.timeAdd(1900,[spawn(enemyGroup,Berserker(position=(580,240)))])
        self.spawnLine(2600,20,[spawn(enemyGroup,Drone(100,vel=(-2,0),amplitude=20)) for x in range(10)])
        self.timeAdd(2700,[spawn(enemyGroup,FlackMissileShip(160),FlackMissileShip(350))])
        self.timeAdd(3100,[spawn(enemyGroup,Guardian())])
        """#self.timeAdd(10,[spawn(enemyGroup,Drone(240))])
        self.timeAdd(60,[spawn(trashGroup,TrashActor((10,10),(10,10),10))])
        self.timeAdd(80,[spawn(enemyGroup,BulletCannon(False))])
        for x in range(6):
            self.timeAdd(121+x*30,[spawn(enemyGroup,EnemyActor(x*25))])
        self.timeAdd(200,[spawn(enemyGroup,FlackCannon(True))])
        self.timeAdd(200,[spawn(enemyGroup,FlackCannon(False))])"""

        """for x in range(200):
            trash=TrashActor((rand()*640,rand()*480),(8,8),10)
            trashGroup.add(trash)"""

class GameLevel2(GameLevel):
    def __init__(self):
        GameLevel.__init__(self)
        #0000
        #self.leveltick=5300
        self.timeAdd(0,[spawn(underlayGroup,Terrain(crag=30,level=390,detail=30))])
        self.spawnLine(125, 25, [spawn(enemyGroup, EnemyActor(25+x*25)) for x in range(5)])
        self.spawnLine(125, 25, [spawn(enemyGroup, EnemyActor(screen.get_height()-(125+x*25))) for x in range(5)])
        self.spawnLine(225, 25, [spawn(enemyGroup, Drone(180, vel=(-3,0), amplitude=35)) for x in range(5)])
        self.timeAdd(350,[spawn(enemyGroup,MissileLauncher(False))])
        self.timeAdd(500,[spawn(enemyGroup,FlackCannon(True))])
        self.timeAdd(750, [spawn(enemyGroup,BulletCannon(True))])
        self.timeAdd(775, [spawn(enemyGroup,Drone(200, vel=(-2,0),health=20)) for x in range(4)])
        self.timeAdd(800, [spawn(enemyGroup,FlackMissileShip(190))])
        self.spawnLine(925,15,[spawn(enemyGroup, EnemyActor(100)) for x in range(5)])
        self.spawnLine(925,15,[spawn(enemyGroup, EnemyActor(300)) for x in range(5)])
        #1000
        self.timeAdd(1000,[spawn(enemyGroup,BulletCannon(True))])
        self.timeAdd(1000,[spawn(enemyGroup,BulletCannon(False))])
        self.spawnLine(1125,25,[spawn(enemyGroup,Drone(180,vel=(-2,0),health=50,move=Drone.juke)) for x in range(6)])
        self.spawnLine(1125,25,[spawn(enemyGroup,Drone(230,vel=(-2,0),health=50,jukevel=(2,2),move=Drone.juke)) for x in range(6)])
        self.spawnLine(1500,100,[spawn(enemyGroup,FlackMissileShip(25+x*50)) for x in range(3)])
        self.spawnLine(1500,100,[spawn(enemyGroup,FlackMissileShip(screen.get_height()-(125+x*50))) for x in range(3)])               
        self.timeAdd(1900,[spawn(enemyGroup,Berserker(position=(580,240)))])
        #2000
        self.spawnLine(2300,25,[spawn(enemyGroup,Drone(180,vel=(-2,0),health=35)) for x in range(8)])
        self.spawnLine(2300,25,[spawn(enemyGroup,Drone(230,vel=(-2,0),health=35)) for x in range(8)])
        self.spawnLine(2500, 15, [spawn(enemyGroup, EnemyActor(125+x*25)) for x in range(5)])
        self.spawnLine(2500, 15, [spawn(enemyGroup, EnemyActor(screen.get_height()-(225+x*25))) for x in range(5)])
        for z in range(3):
            self.timeAdd(2750+z*60,[spawn(enemyGroup,Drone(x*640/8,amplitude=40,rate=3)) for x in range(5)])
        self.spawnLine(2800,15,[spawn(enemyGroup,Drone(180,vel=(-2,0),health=100,move=Drone.juke)) for x in range(4)])
        self.spawnLine(2800,15,[spawn(enemyGroup,Drone(230,vel=(-2,0),health=100,jukevel=(2,2),move=Drone.juke)) for x in range(4)])
        #3000
        self.timeAdd(3000,[spawn(enemyGroup,FlackMissileShip(160),FlackMissileShip(350))])
        self.timeAdd(3000,[spawn(enemyGroup,BulletCannon(True))])
        self.spawnLine(3125, 15, [spawn(enemyGroup, Drone(180, vel=(-3,0), amplitude=35)) for x in range(5)])
        self.timeAdd(3250,[spawn(enemyGroup,BulletCannon(False))])
        self.timeAdd(3250,[spawn(enemyGroup,FlackCannon(True))])
        self.timeAdd(3750,[spawn(enemyGroup,BulletCannon(False))])
        self.timeAdd(3750,[spawn(enemyGroup,FlackCannon(True))])
        #4000
        self.spawnLine(4000,50,[spawn(enemyGroup,EnemyActor(25+x*25)) for x in range(8)])
        self.spawnLine(4000,50,[spawn(enemyGroup,EnemyActor(screen.get_height()-125+x*25)) for x in range(8)])
        self.timeAdd(4500,[spawn(enemyGroup,FlackCannon(False))])
        self.timeAdd(4500,[spawn(enemyGroup,BulletCannon(True))])
        #5000
        self.spawnLine(5000,50,[spawn(enemyGroup,FlackMissileShip(25+x*50)) for x in range(8)])
        self.timeAdd(5300,[spawn(enemyGroup,VoidStar())])
        #6000
        
            
def doMain():
    initEngine()
    initStuff()
    global gameMode
    global tick
    running=True
    #gameMode=GameOver()
    gameMode=GameLevel1()
    #gameMode=GameLevel2()
    clock=pygame.time.Clock()
    while running:
        controls.JustShot=False
        controls.JustThrow1=False
        controls.JustThrow2=False
        for ev in pygame.event.get():
            if ev.type == QUIT:
                running= False
            if ev.type==KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    global screen
                    if not fullscreen:
                        screen=pygame.display.set_mode((640,480),pygame.FULLSCREEN)
                        global fullscreen
                        fullscreen=True
                        pygame.mouse.set_visible(False)
                    else:
                        pygame.mouse.set_visible(True)
                        screen=pygame.display.set_mode((640,480))
                        global fullscreen
                        fullscreen=False
            processEvent(ev)
        #for k in controls.__dict__:
        #   print k,':',controls.__dict__[k]
        gameMode.go()
        tick+=1
        clock.tick(60)
    print clock
    pygame.quit()
    
def textsprite(stri,lheight,color):
    #print pygame.font.get_fonts()
    font=pygame.font.SysFont(None,lheight)
    linesurf=[]
    height=0
    wid=0
    for line in stri.split('\n'):
        linsp=font.render(line,False,color)
        linesurf.append(linsp)
        r=linsp.get_rect()
        if r.width>wid:wid=r.width
        height+=r.height
        #print r.height
    if len(stri.split('\n'))==1:
        return linesurf[0]
    spr=pygame.Surface((wid,height))
    spr.set_colorkey((0,0,0))
    y=0
    for line in linesurf:
        spr.blit(line,(0,y))
        y+=lheight/2
    return spr

def boomSprite():
    s=pygame.Surface((64,64))
    for x in range(32):
        pygame.draw.circle(s,(max(0,180-x*6),max(0,180-x*6),255-x*2),(32,32),32-x,0)
    s.set_colorkey((0,0,0))
    return (s,s.get_rect().center)

def orbSprite(color,size):
    s=pygame.Surface((size,size))
    s.set_colorkey((0,0,0))
    for x in range(size/2):
        bright=1-x/(size/2.0)
        bright=pow(bright,6)
        bright=bright*.8+.2
        c=(min(255,color[0]*bright),min(255,color[1]*bright),min(255,color[2]*bright))
        pygame.draw.circle(s,c,(size/2,size/2),size/2-x,0)
    pygame.draw.circle(s,map(lambda x:x*.3,color),addv((size/4,-size/4),(size/2,size/2)),size/10)
    pygame.draw.circle(s,(255,255,255),addv((size/4,-size/4),(size/2,size/2)),size/12)
    pygame.draw.circle(s,color,addv((-size/4,size/4),(size/2,size/2)),size/12)
    return (s,s.get_rect().center)

def junkSprite():
    s=textsprite('*',70,(78,78,99))
    return (s,subv(s.get_rect().center,(0,12)))
def cannonspr():
    s=pygame.Surface((32,26))
    s.set_colorkey((0,0,0))
    for x in range(32):
        pygame.draw.line(s,(80+4*x,0,0),(16,0),(x,26))
    return (s,s.get_rect().center)
def blocspr(c,sz):
    s=pygame.Surface((sz,sz))
    s.fill(c)
    return (s,s.get_rect().center)

def playerSprite():
    s=textsprite("""     ## |\\ 
####:00==>
    ## ---/""",20,(0,0,255))
    return (s,(30,20))

def lifeSprite():
    s=textsprite("""      # |\
##:=>
         #--/""",15,(0,0,255))
    return (s,(30,20))

class TheBomb(BulletActor):
    def __init__(self):
        BulletActor.__init__(self,(0,0,40,480),(0,0),(12,0))
        self.damage=70
        self.isBomb=True
    def think(self):
        BulletActor.think(self)
        for n in range(5):
            overlayGroup.add(smallExplode((self.tick*12+rand()*20,480*rand()),10+rand()*30))
    def onCollide(self,oth):
        pass
    def draw(self,scr):
        pass

def spawn(*args):
    def spawner():
        #print "spawned"
        grp=args[0]
        for act in args[1:]:
            grp.add(act)
    return spawner
        
if __name__=="__main__":
    doMain()
""" 
    import hotshot,hotshot.stats
    prof = hotshot.Profile("game.prof")
    benchtime= prof.runcall(doMain)

    stats = hotshot.stats.load("game.prof")
    stats.strip_dirs()
    stats.sort_stats('time', 'calls')
    stats.print_stats(20)
"""
