import yourgameshortname.main
if __name__ == "__main__":
    yourgameshortname.main.main()
