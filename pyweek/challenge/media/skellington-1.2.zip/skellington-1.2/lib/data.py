'''Simple data loader module.

Loads data files from the "data" directory shipped with a game.

Enhancing this to handle caching etc. is left as an exercise for the reader.
'''

import os

dirname = os.path.abspath(os.path.dirname(__file__))

def load(filename):
    return open(os.path.join(dirname, '..', 'data', filename), 'rb')

