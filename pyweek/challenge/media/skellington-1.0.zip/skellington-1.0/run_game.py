#! /usr/bin/env python

import sys
sys.path.insert(0, 'lib')

import main
main.main()
